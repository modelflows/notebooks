# In[0]: IMPORT PACKAGES

import DMDd
import os
import numpy as np
import scipy as sp
import matplotlib.pyplot as plt
from math import floor
os.environ['KMP_DUPLICATE_LIB_OK']='True'
import scipy.io
import mat73
import gdown
import time
import warnings
timestr = time.strftime("%Y-%m-%d_%H.%M.%S")

# Detect current working directory:
path0 = os.getcwd()

print('\nHODMD Algorithm')
print('\n-----------------------------')


# In[1]: CLONE TEST CASE DATA

# Here we clone the test case available in our databases of a flow past a 2d cylinder
# Comment following line if it is not the first run or you have your own database
gdown.download_folder("https://drive.google.com/drive/folders/1eaL945MC46rwhsft72LE_GtSCl15ugB4", output="./")


# In[2]: LOAD DATA
print('\nLoading the dataset...')
mat = mat73.loadmat('./Tensor.mat') #Linea cambiada
Tensor = mat["Tensor"]
print('\nDataset loaded!')

TimePos = Tensor.ndim  # Here the position of the temporal dimension is introduced


# In[3]: PROCESS DATA

SNAP = int(Tensor.shape[-1])  # Change SNAP to reduce number of snapshots

Tensor = Tensor[..., 0:SNAP]


# In[4]: CALIBRATION

d = 25              # Number of HODMD windows
varepsilon1 = 1e-3  # Tolerance to truncate the number of SVD modes retained
varepsilon  = 1e-3  # Tolerance to truncate the number of DMD modes retained
deltaT = 1          # Time step of the database


# In[5]: SUMMARY

print('\n-----------------------------')
print('HODMD summary:')
print('\n' + f'Number of snapshots set at: {SNAP}')
print(f'd Parameter set at: {d}')
print(f'Tolerances set at {varepsilon1} for SVD and {varepsilon} for HODMD')
print(f'Time gradient set at deltaT: {deltaT}')
print('\n-----------------------------')

# In[6]: PERFORM HODMD

Time = np.linspace(0,SNAP-1,num=SNAP)*deltaT

dims = Tensor.ndim
shape = Tensor.shape

Tensor0 = Tensor
if dims > 2:
	dims_prod = np.prod(shape[:-1])
	Tensor = np.reshape(Tensor, (dims_prod, shape[-1]))

if d==1:
	print('Performing DMD. Please wait...\n')
	[u,Amplitude,Eigval,GrowthRate,Frequency,DMDmode] = DMDd.dmd1(Tensor, Time, varepsilon1, varepsilon)
	print('\nDMD complete!')
	dt=Time[1]-Time[0]
	icomp=complex(0,1)
	mu=np.zeros(np.size(GrowthRate),dtype=np.complex128)
	for iii in range(0,np.size(GrowthRate)):
		mu[iii] = np.exp(np.dot(dt,GrowthRate[iii]+np.dot(icomp,Frequency[iii])))
	Reconst=DMDd.remake(u,Time,mu)
else:
	print('Performing HODMD. Please wait...\n')
	[u,Amplitude,Eigval,GrowthRate,Frequency,DMDmode] = DMDd.hodmd(Tensor, d, Time, varepsilon1, varepsilon)
	print('\nHODMD complete!')
	dt=Time[1]-Time[0]
	icomp=complex(0,1)
	mu=np.zeros(np.size(GrowthRate),dtype=np.complex128)
	for iii in range(0,np.size(GrowthRate)):
		mu[iii] = np.exp(np.dot(dt,GrowthRate[iii]+np.dot(icomp,Frequency[iii])))
	Reconst=DMDd.remake(u,Time,mu)

DMDmode = np.reshape(DMDmode, shape[:-1] + (len(Frequency),))
GrowthrateFrequencyAmplitude = np.array([GrowthRate, Frequency, Amplitude])
TT = np.real(np.reshape(Reconst, shape))

RRMSE = np.linalg.norm(Tensor0 - TT) / np.linalg.norm(Tensor) 
print(f'Relative mean square error made in the calculations: {np.round(RRMSE*100, 3)}%\n')


# In[7]: PLOTS

##### Plot amplitude and growth rate vs frequencies spectrum #####
fig_spec, axes = plt.subplots(1, 2, figsize=(12, 5))

axes[0].plot(Frequency, Amplitude / np.max(Amplitude), marker='o', color='b', linestyle='', markersize=6)
axes[0].set_yscale("log")
axes[0].set_xlabel("Frequency", fontsize=14)
axes[0].set_ylabel("Amplitude", fontsize=14)
axes[0].grid(True, which="both", linestyle="--", alpha=0.6)
axes[0].spines["top"].set_visible(True)
axes[0].spines["right"].set_visible(True)

# Growth Rate vs Frequency
axes[1].plot(Frequency, GrowthRate, marker='o', color='r', linestyle='', markersize=6)
axes[1].set_yscale("log")
axes[1].set_xlabel("Frequency", fontsize=14)
axes[1].set_ylabel("Growth Rate", fontsize=14)
axes[1].grid(True, which="both", linestyle="--", alpha=0.6)
axes[1].spines["top"].set_visible(True)
axes[1].spines["right"].set_visible(True)

plt.tight_layout()
plt.show()


##### Plot original vs reconstruction #####
mat = mat73.loadmat('./X.mat')
X = mat["X"]
mat = mat73.loadmat('./Y.mat')
Y = mat["Y"]

component = 0  # First component
original_slice = Tensor0[component, :, :, SNAP-1]
reconstructed_slice = TT[component, :, :, SNAP-1]

vmin, vmax = min(original_slice.min(), reconstructed_slice.min()), max(original_slice.max(), reconstructed_slice.max())

fig_rec, axes_rec = plt.subplots(1, 2, figsize=(12, 5))

# Plot original tensor
im1 = axes_rec[0].pcolor(X,Y,original_slice, cmap="viridis", shading="auto", vmin=vmin, vmax=vmax)
axes_rec[0].set_title("Original Tensor", fontsize=14)
axes_rec[0].set_xlabel("X", fontsize=14)
axes_rec[0].set_ylabel("Y", fontsize=14)

# Plot reconstructed tensor
im2 = axes_rec[1].pcolor(X,Y,reconstructed_slice, cmap="viridis", shading="auto", vmin=vmin, vmax=vmax)
axes_rec[1].set_title("Reconstructed Tensor", fontsize=14)
axes_rec[1].set_xlabel("X", fontsize=14)
axes_rec[1].set_ylabel("Y", fontsize=14)

plt.tight_layout()
plt.show()


##### Plot original vs reconstruction #####
# Find desired frequencies
freq = np.array([0, 0.8, 1.6])
tolerance = 0.1  # Allowed deviation
indices = [np.argmin(np.abs(Frequency - f)) if np.any(np.abs(Frequency - f) < tolerance) else None for f in freq]

if None in indices:
    warnings.warn("Some frequencies have no match within tolerance. Skipping those modes.")

indices = [idx for idx in indices if idx is not None]

if not indices:
    raise ValueError("No frequencies matched within tolerance. Check your input data.")

# Extract corresponding modes
component = 0
modes = [np.real(DMDmode[component,:, :, idx]) for idx in indices]

# Compute vmin and vmax for consistent color scaling
vmin = min(mode.min() for mode in modes)
vmax = max(mode.max() for mode in modes)

# Create subplots
fig_modes, axes_modes = plt.subplots(1, len(modes), figsize=(15, 5))

for i, (ax, mode, f) in enumerate(zip(axes_modes, modes, freq)):
	vmin = min(mode.min() for mode in modes[i])
	vmax = max(mode.max() for mode in modes[i])

	im = ax.pcolor(X, Y, mode, cmap="viridis", shading="auto", vmin=vmin, vmax=vmax)
	ax.set_title(f"$\omega$ = {f:.2f}", fontsize=14)
	ax.set_xlabel("X", fontsize=14)
	ax.set_ylabel("Y", fontsize=14)


plt.tight_layout()
plt.show()

# In[7]: SAVE FILES

filen = f'{timestr}_HODMD_solution_d{d}_tolSVD{varepsilon1}_tolDMD{varepsilon}'

if not os.path.exists(f'{path0}/{filen}'):
    os.mkdir(f"{path0}/{filen}")

print(f'Saving files and plots...')

mdic = {"DMDmode": DMDmode}
file_mat = str(f'{path0}/{filen}/DMDmode.mat')
sp.io.savemat(file_mat, mdic, appendmat=True, format='5')
mdic = {"GrowthrateFrequencyAmplitude": GrowthrateFrequencyAmplitude}
file_mat = str(f'{path0}/{filen}/GrowthrateFrequencyAmplitude.mat')
sp.io.savemat(file_mat, mdic, appendmat=True, format='5')
mdic = {"Tensor_Reconst": TT}
file_mat = str(f'{path0}/{filen}/Tensor_Reconst.mat')
sp.io.savemat(file_mat, mdic, appendmat=True, format='5')

fig_spec.savefig(f"{path0}/{filen}/plot_spectrum.png", dpi=300, bbox_inches="tight")
fig_rec.savefig(f"{path0}/{filen}/plot_reconstruction.png", dpi=300, bbox_inches="tight")
fig_modes.savefig(f"{path0}/{filen}/plot_modes.png", dpi=300, bbox_inches="tight")

print(f'Files saved in {filen}')


