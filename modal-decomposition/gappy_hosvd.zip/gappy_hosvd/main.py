# In[0]: IMPORT PACKAGES

import hosvd
import os
import numpy as np
import matplotlib.pyplot as plt
from math import floor
os.environ['KMP_DUPLICATE_LIB_OK']='True'
import scipy.io
from scipy.interpolate import griddata
import hdf5storage
import gdown
import time
import warnings
timestr = time.strftime("%Y-%m-%d_%H.%M.%S")

# Detect current working directory:
path0 = os.getcwd()

print('\nHODMD Algorithm')
print('\n-----------------------------')


# In[1]: CLONE TEST CASE DATA

# Here we clone the test case available in our databases of a flow past a 2d cylinder
# Comment following line if it is not the first run or you have your own database
gdown.download_folder("https://drive.google.com/drive/folders/1eaL945MC46rwhsft72LE_GtSCl15ugB4", output="./")


# In[2]: LOAD DATA
print('\nLoading the dataset...')
mat = hdf5storage.loadmat('./Test Case/Tensor.mat')
Tensor = mat["Tensor"]
print('\nDataset loaded!')

# In[3]: CREATE RANDOM GAPS

# Here we create a tensor with random NaN values. This is a toy model, so we can compare with the original
# The algorithm is meant to be applied directly to databases with NaN values

A_gappy = Tensor

# Create a random mask with a 10% probability of being NaN
mask = np.random.rand(*np.shape(Tensor)) < 0.2  # 10% of values will be NaN
A_gappy[mask] = np.nan

gap_percentage = (np.sum(np.isnan(A_gappy))/A_gappy.size) * 100  # % of gaps
print(f"Percentage of gaps: {gap_percentage:.2f}%")


# In[4]: CALIBRATION

method = 'hosvd'               # SVD for matrices, HOSVD for Tensor
m = 10                       # Number of modes to retain on the reconstruction
decision_1 = 'zeros'         # IMPLEMENTED: 'zeros', 'mean' (both can be used for any type of array), 
                             #              'interp_1d' (suitable for arrays),
                             #              'interp_2d' (suitable for matrices, method = 'nearest'),
                             #              'Tensor_interp' (suitable for tensors)
# In[5]: SUMMARY

print('\n-----------------------------')
print('Database repairing summary:')
print(f'The method used is: {method}')
print(f'The initial reconstruction is fill the gaps using: {decision_1}')
print(f'The number of svd modes retained in each dimension is: {m}')
print('\n-----------------------------')

# In[6]: INITIAL RECONSTRUCTION

N = sum(np.isnan(A_gappy.flatten()))

# Initial reconstruction
print('\nCompleting data. Please wait...')
if decision_1 == 'zeros':
    A0_1 = np.nan_to_num(A_gappy, nan = 0)

elif decision_1 == 'mean':
    A0_1 = np.nan_to_num(A_gappy, nan = 0)
    A0_1 = np.nan_to_num(A_gappy,nan=sum(A0_1.flatten())/(A0_1.size-N))

elif decision_1 == 'interp_1d':
    A0_1 = np.zeros(A_gappy.shape)
    y = np.linspace(0, 1, A_gappy.shape[1])
    for j in range(np.size(A_gappy,1)):   
        A_gappycolumn = A_gappy[:,j]
        A0_1[:,j] = np.interp(y, y[np.isfinite(A_gappy[:,j])], A_gappycolumn[np.isfinite(A_gappy[:,j])])

elif decision_1 == 'interp_2d':
    if A_gappy.ndim == 2:
        x = np.linspace(0, 1, A_gappy.shape[0])
        y = np.linspace(0, 1, A_gappy.shape[1])
        xv, yv = np.meshgrid(x, y)
        xnumber = xv[np.isfinite(A_gappy)]
        ynumber = yv[np.isfinite(A_gappy)]
        A0_1 = griddata(np.transpose(np.array([xnumber, ynumber])), A_gappy[np.isfinite(A_gappy)] , (xv, yv), method='linear')

elif decision_1 == 'tensor_interp':

    if A_gappy.ndim == 4:
        shape = A_gappy.shape
        A_gappy_re = np.reshape(A_gappy, (A_gappy.shape[0], A_gappy.shape[1] * A_gappy.shape[2], A_gappy.shape[3]))
        for i in range(A_gappy_re.shape[0]):
            for j in range(A_gappy_re.shape[-1]):
                velocity_values = A_gappy_re[i, :, j]
                nan_mask = np.isnan(velocity_values)
                
                non_nan_indices = np.where(~nan_mask)[0]
                
                interpolated_values = griddata(non_nan_indices, velocity_values[~nan_mask], np.arange(A_gappy_re.shape[1]), method='linear')
                
                A_gappy_re[i, nan_mask, j] = interpolated_values[nan_mask]

        A0_1 = np.reshape(A_gappy_re, shape)

print('Initial reconstruction complete!')        
# In[7]: ITERATIVELY PERFORM HOSVD, UPDATING THE VALUE OF THE GAPS


A_s = A0_1.copy()
MSE_gaps = np.zeros(500)

for ii in range(500):
    print(f'\nIteration number: {ii+1}')

    if method == 'svd':
        print('\nPerforming SVD. Please wait...')
        [U,S,V]=np.linalg.svd(A_s)
        print('SVD complete!')
        S = np.diag(S)
        A_reconst = U[:,0:m] @ S[0:m,0:m] @ V[0:m,:]
    elif method == 'hosvd':
        n = m*np.ones(np.shape(A_s.shape))
        print('\nPerforming HOSVD. Please wait...')
        A_reconst = hosvd.HOSVD_function(A_s,n)[0]
        print('HOSVD complete!')
            
        MSE_gaps[ii] = np.linalg.norm(A_reconst[np.isnan(A_gappy)]-A_s[np.isnan(A_gappy)])/N
        
    if (ii>3 and MSE_gaps[ii]>=MSE_gaps[ii-1]) or MSE_gaps[ii]<1e-9:
        break
    else:
        A_s[np.isnan(A_gappy)] = A_reconst[np.isnan(A_gappy)]


# In[8]: PLOTS

##### Plot singular values #####
markers = ['o', 's', 'D', '^', 'v', 'p', '*', 'h', 'x', '+']  
colors = ['b', 'g', 'r', 'c', 'm', 'y', 'k', 'orange', 'purple', 'brown']  

num_dims = Tensor.ndim  # Number of dimensions

fig_sv = plt.figure(figsize=(8, 6))  # Set figure size

print('\nPlotting singular values decay')

if method =='svd':
    print('\nPerforming SVD. Please wait...')
    [U0,S0,V0]=np.linalg.svd(A0_1)
    [U,S,V]=np.linalg.svd(A_s)
    print('SVD complete!\n')
    plt.plot(S0/S0[0],'kx', label="Initial")
    plt.plot(S/S[0],'rx', label="Reconstructed")

elif method == 'hosvd':
    print('\nPerforming HOSVD. Please wait...')
    sv0 = hosvd.HOSVD_function(A0_1,np.array(A0_1.shape))[3]
    sv = hosvd.HOSVD_function(A_s,np.array(A_s.shape))[3]
    print('HOSVD complete!\n')
    cmap = plt.cm.get_cmap('jet')
    rgba = cmap(np.linspace(0,1,num_dims))
    for i in range(num_dims):
        s = sv[0,i]
        s = s/np.max(s)
        s1 = sv0[0,i]
        s1 = s1/np.max(s1)
        plt.plot(
		range(1, len(s) + 1), s1,  # Singular values of each dimension
		marker=markers[i % len(markers)], color=colors[i % len(colors)],
		linestyle='-', linewidth=1.5, markersize=6, label=f"Initial dim{i+1}"
		)
        
        plt.plot(range(1, len(s) + 1), s,marker=markers[i % len(markers)], color=colors[i % len(colors)],
		linestyle=':', linewidth=1.5, markersize=6, label=f"Reconstructed dim{i+1}")

plt.xlabel("Singular Value Index", fontsize=14)
plt.ylabel("Singular Value", fontsize=14)
plt.legend(fontsize=12)
plt.grid(True, which="both", linestyle="--", alpha=0.6)
plt.xscale("log")  # Log scale for index
plt.yscale("log")  # Log scale for singular values
plt.gca().spines["top"].set_visible(True)
plt.gca().spines["right"].set_visible(True)

plt.show()

##### Plot original vs enhanced reconstruction #####
mat = hdf5storage.loadmat('./Test Case/X.mat')
X = mat["X"]
mat = hdf5storage.loadmat('./Test Case/Y.mat')
Y = mat["Y"]

component = 0  # First component
original_slice = A0_1[component, :, :, -1]
reconstructed_slice = A_s[component, :, :,-1]

vmin, vmax = min(original_slice.min(), reconstructed_slice.min()), max(original_slice.max(), reconstructed_slice.max())

fig_rec, axes_rec = plt.subplots(1, 2, figsize=(12, 5))

# Plot original tensor
im1 = axes_rec[0].pcolor(X,Y,original_slice, cmap="viridis", shading="auto", vmin=vmin, vmax=vmax)
axes_rec[0].set_title("Gappy Tensor", fontsize=14)
axes_rec[0].set_xlabel("X", fontsize=14)
axes_rec[0].set_ylabel("Y", fontsize=14)

# Plot reconstructed tensor
im2 = axes_rec[1].pcolor(X,Y,reconstructed_slice, cmap="viridis", shading="auto", vmin=vmin, vmax=vmax)
axes_rec[1].set_title("Reconstructed Tensor", fontsize=14)
axes_rec[1].set_xlabel("X", fontsize=14)
axes_rec[1].set_ylabel("Y", fontsize=14)

plt.tight_layout()
plt.show()


# In[7]: SAVE FILES

filen = f'{timestr}_GappyHOSVD_solution_factor{2**n}'

if not os.path.exists(f'{path0}/{filen}'):
    os.mkdir(f"{path0}/{filen}")

print('Saving files and plots...')

mdic = {"Tensor_Reconst": A_s}
file_mat = str(f'{path0}/{filen}/Tensor_Reconst.mat')
hdf5storage.savemat(file_mat, mdic, appendmat=True, format='7.3')


fig_sv.savefig(f"{path0}/{filen}/plot_singular_values.png", dpi=300, bbox_inches="tight")
fig_rec.savefig(f"{path0}/{filen}/plot_reconstruction.png", dpi=300, bbox_inches="tight")

print(f'Files saved in {filen}')


