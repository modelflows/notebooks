# In[0]: IMPORT PACKAGES

import hosvd
import os
import numpy as np
import matplotlib.pyplot as plt
os.environ['KMP_DUPLICATE_LIB_OK']='True'
from scipy.ndimage import zoom
import hdf5storage
import gdown
import time
import warnings
timestr = time.strftime("%Y-%m-%d_%H.%M.%S")

# Detect current working directory:
path0 = os.getcwd()

print('\nHODMD Algorithm')
print('\n-----------------------------')


# In[1]: CLONE TEST CASE DATA

# Here we clone the test case available in our databases of a flow past a 2d cylinder
# Comment following line if it is not the first run or you have your own database
gdown.download_folder("https://drive.google.com/drive/folders/1eaL945MC46rwhsft72LE_GtSCl15ugB4", output="./")


# In[2]: LOAD DATA
print('\nLoading the dataset...')
mat = hdf5storage.loadmat('./Test Case/Tensor.mat')
Tensor = mat["Tensor"]
print('\nDataset loaded!')


# In[4]: CALIBRATION

n = 1              # Introduce the enhancement factor (2**n)
m = [1,2]          # Introduce the spatial dimensions
# In[5]: SUMMARY

print('\n-----------------------------')
print('Supperresolution using HOSVD summary:')
print(f'The spatial dimensions are going to be enhanced by a factor of: {2**n}')
print(f'The spatial dimensions are located in dimensions: {m}')
print('\n-----------------------------')


# In[6]: PERFORM HOSVD N TIMES, UPSCALING EACH TIME THE RESOLUTION BY A FACTOR OF 2

nn0 = np.array(Tensor.shape)
Tensor_high_res = Tensor


for ii in range(n):

    print('Performing HOSVD. Please wait...\n')
    _ , S, U, _ , _ = hosvd.HOSVD_function(Tensor_high_res, nn0)
    print('\nHOSVD complete!\n')

    Udens = U  
    for dim in m:
        x = np.linspace(0, 1, U[0][dim].shape[0]*2)
        U_dens = np.zeros((x.shape[0],S.shape[dim]))
        for j in range(S.shape[dim]):
            Udenscolumn = U[0][dim][:,j]
            U_dens[:,j] = np.interp(x, x[0:x.shape[0]:2], Udenscolumn) 
        Udens[0][dim] = U_dens
                
    print('Performing HOSVD. Please wait...')  
    A_d = hosvd.tprod(S, Udens)
    Tensor_high_res = hosvd.HOSVD_function(A_d,n)[0]
    print('HOSVD complete!\n')



# In[7]: PLOTS


##### Plot original vs enhanced reconstruction #####
mat = hdf5storage.loadmat('./Test Case/X.mat')
X = mat["X"]
mat = hdf5storage.loadmat('./Test Case/Y.mat')
Y = mat["Y"]

X_high_res = zoom(X, 2**n, order=1)  # Factor 2^n
Y_high_res = zoom(Y, 2**n, order=1)

component = 0  # First component
original_slice = Tensor[component, :, :, -1]
enhanced_slice = Tensor_high_res[component, :, :,-1]

vmin, vmax = min(original_slice.min(), enhanced_slice.min()), max(original_slice.max(), enhanced_slice.max())

fig_rec, axes_rec = plt.subplots(1, 2, figsize=(12, 5))

# Plot original tensor
im1 = axes_rec[0].pcolor(X,Y,original_slice, cmap="viridis", shading="auto", vmin=vmin, vmax=vmax)
axes_rec[0].set_title("Original Tensor", fontsize=14)
axes_rec[0].set_xlabel("X", fontsize=14)
axes_rec[0].set_ylabel("Y", fontsize=14)

# Plot reconstructed tensor
im2 = axes_rec[1].pcolor(X_high_res,Y_high_res,enhanced_slice, cmap="viridis", shading="auto", vmin=vmin, vmax=vmax)
axes_rec[1].set_title("Enhanced Tensor", fontsize=14)
axes_rec[1].set_xlabel("X", fontsize=14)
axes_rec[1].set_ylabel("Y", fontsize=14)

plt.tight_layout()
plt.show()


# In[7]: SAVE FILES

filen = f'{timestr}_SRHOSVD_solution_factor{2**n}'

if not os.path.exists(f'{path0}/{filen}'):
    os.mkdir(f"{path0}/{filen}")

print(f'Saving files and plots...')

mdic = {"Tensor_high_res": Tensor_high_res}
file_mat = str(f'{path0}/{filen}/Tensor_high_res.mat')
hdf5storage.savemat(file_mat, mdic, appendmat=True, format='7.3')
mdic = {"X_high_res": X_high_res}
file_mat = str(f'{path0}/{filen}/X_high_res.mat')
hdf5storage.savemat(file_mat, mdic, appendmat=True, format='7.3')
mdic = {"Y_high_res": Y_high_res}
file_mat = str(f'{path0}/{filen}/Y_high_res.mat')
hdf5storage.savemat(file_mat, mdic, appendmat=True, format='7.3')

fig_rec.savefig(f"{path0}/{filen}/plot_reconstruction.png", dpi=300, bbox_inches="tight")

print(f'Files saved in {filen}')


