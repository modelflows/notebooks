# In[0]: IMPORT PACKAGES

import hosvd
import os
import numpy as np
import scipy as sp
import matplotlib.pyplot as plt
os.environ['KMP_DUPLICATE_LIB_OK']='True'
import mat73
import gdown
import time
timestr = time.strftime("%Y-%m-%d_%H.%M.%S")

# Detect current working directory:
path0 = os.getcwd()

print('\nHOSVD Algorithm')
print('\n-----------------------------')

# In[1]: CLONE TEST CASE DATA

# Here we clone the test case available in our databases of a flow past a 2d cylinder
# Comment following line if it is not the first run or you have your own database
gdown.download_folder("https://drive.google.com/drive/folders/1eaL945MC46rwhsft72LE_GtSCl15ugB4", output="./")

# In[2]: LOAD DATA
print('\nLoading the dataset...')
mat = mat73.loadmat('./Tensor.mat')
Tensor = mat["Tensor"]
print('\nDataset loaded!')

TimePos = Tensor.ndim  # Here the position of the temporal dimension is introduced


# In[3]: PROCESS DATA

SNAP = int(Tensor.shape[-1])  # Change SNAP to reduce number of snapshots

Tensor = Tensor[..., 0:SNAP]


# In[4]: CALIBRATION

varepsilon1 = 1e-3  # Tolerance to truncate the number of modes retained


# In[5]: SUMMARY

print('\n-----------------------------')
print('HOSVD summary:')
print('\n' + f'Number of snapshots set at: {SNAP}')
print(f'Tolerance set at {varepsilon1} for SVD')
print('\n-----------------------------')

# In[6]: PERFORM HOSVD
nn0 = np.array(Tensor.shape)
nn = np.array(nn0)
nn[1:np.size(nn)] = 0 

print('Performing HOSVD. Please wait...\n')
hatT, U, S, sv, nn1, n, TT = hosvd.HOSVD(Tensor, varepsilon1, nn, nn0, TimePos)
print('\nHOSVD complete!\n')

RRMSE = np.linalg.norm(Tensor - TT) / np.linalg.norm(Tensor)  # Relative root mean square error
print(f'Relative mean square error made in the calculations: {np.round(RRMSE*100, 3)}%\n')


# In[7]: PLOTS

##### Plot singular values #####
markers = ['o', 's', 'D', '^', 'v', 'p', '*', 'h', 'x', '+']  
colors = ['b', 'g', 'r', 'c', 'm', 'y', 'k', 'orange', 'purple', 'brown']  

num_dims = len(sv[0,:])  # Number of dimensions

fig_sv = plt.figure(figsize=(8, 6))  # Set figure size

for i in range(num_dims):
	s = sv[0,i]
	s = s/np.max(s)
	plt.plot(
		range(1, len(s) + 1), s,  # Singular values of each dimension
		marker=markers[i % len(markers)], color=colors[i % len(colors)],
		linestyle='-', linewidth=1.5, markersize=6, label=f"dim{i+1}"
		)

plt.xlabel("Singular Value Index", fontsize=14)
plt.ylabel("Singular Value", fontsize=14)
plt.title("Singular Value Decay (HOSVD)", fontsize=14)
plt.legend(fontsize=12)
plt.grid(True, which="both", linestyle="--", alpha=0.6)
plt.xscale("log")  # Log scale for index
plt.yscale("log")  # Log scale for singular values
plt.gca().spines["top"].set_visible(True)
plt.gca().spines["right"].set_visible(True)

plt.show()


##### Plot original vs reconstruction #####
mat = mat73.loadmat('./X.mat')
X = mat["X"]
mat = mat73.loadmat('./Y.mat')
Y = mat["Y"]

component = 0  # First component
original_slice = Tensor[component, :, :, SNAP-1]
reconstructed_slice = TT[component, :, :, SNAP-1]

vmin, vmax = min(original_slice.min(), reconstructed_slice.min()), max(original_slice.max(), reconstructed_slice.max())

fig_rec, axes = plt.subplots(1, 2, figsize=(12, 5))

# Plot original tensor
im1 = axes[0].pcolor(X,Y,original_slice, cmap="viridis", shading="auto", vmin=vmin, vmax=vmax)
axes[0].set_title("Original Tensor", fontsize=14)
axes[0].set_xlabel("X", fontsize=14)
axes[0].set_ylabel("Y", fontsize=14)

# Plot reconstructed tensor
im2 = axes[1].pcolor(X,Y,reconstructed_slice, cmap="viridis", shading="auto", vmin=vmin, vmax=vmax)
axes[1].set_title("Reconstructed Tensor", fontsize=14)
axes[1].set_xlabel("X", fontsize=14)
axes[1].set_ylabel("Y", fontsize=14)

plt.tight_layout()
plt.show()


# In[7]: SAVE FILES

filen = f'{timestr}_HOSVD_solution_tol_{varepsilon1}'

if not os.path.exists(f'{path0}/{filen}'):
    os.mkdir(f"{path0}/{filen}")

print(f'Saving files and plots...')

mdic = {"U": U}
file_mat = str(f'{path0}/{filen}/U.mat')
sp.io.savemat(file_mat, mdic, appendmat=True, format='5')
mdic = {"S": S}
file_mat = str(f'{path0}/{filen}/S.mat')
sp.io.savemat(file_mat, mdic, appendmat=True, format='5')
mdic = {"sv": sv}
file_mat = str(f'{path0}/{filen}/sv.mat')
sp.io.savemat(file_mat, mdic, appendmat=True, format='5')
mdic = {"Tensor_reconst": TT}
file_mat = str(f'{path0}/{filen}/Tensor_Reconst.mat')
sp.io.savemat(file_mat, mdic, appendmat=True, format='5')

fig_sv.savefig(f"{path0}/{filen}/plot_singular_values.png", dpi=300, bbox_inches="tight")
fig_rec.savefig(f"{path0}/{filen}/plot_reconstruction.png", dpi=300, bbox_inches="tight")

print(f'Files saved in {filen}')


