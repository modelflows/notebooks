%% INITIAL SETUP

clc;
clear;
close all;

disp(' ');
disp('HODMD Algorithm for Flow Control');
disp('-----------------------------');
disp(' ');
disp('The HODMD algorithm for flow control needs a prior calibration of HODMD.');

% Detect current working directory
path0 = pwd;

% Create timestamp (not mandatory, shown for completeness)
timestr = datestr(now, 'yyyy-mm-dd_HH.MM.SS');

%% LOAD DATA
data_struct = load('Tensor.mat');
Tensor = data_struct.Tensor;
disp('Dataset loaded!');

TimePos = ndims(Tensor);  % Temporal dimension index

% Load mesh
X_struct = load('X.mat');
X = X_struct.X;
Y_struct = load('Y.mat');
Y = Y_struct.Y;


%% PROCESS DATA

SNAP = size(Tensor, ndims(Tensor));  % Number of snapshots (last dimension)
Tensor = Tensor(:, :, :, 1:SNAP);  % Truncate snapshots
shape = size(Tensor);

%% CALIBRATION

d = 50;              % Number of HODMD windows
varepsilon1 = 1e-3;  % Tolerance for SVD truncation
varepsilon = 1e-4;   % Tolerance for DMD truncation
deltaT = 1;          % Time step of the database

Time = linspace(0, SNAP - 1, SNAP) * deltaT;

%% SUMMARY

disp(' ');
disp('-----------------------------');
disp('HODMD summary:');
disp(['Number of snapshots set at: ', num2str(SNAP)]);
disp(['d Parameter set at: ', num2str(d)]);
disp(['Tolerances set at ', num2str(varepsilon1), ' for SVD and ', num2str(varepsilon), ' for HODMD']);
disp(['Time gradient set at deltaT: ', num2str(deltaT)]);
disp('-----------------------------');

%% FIRST STEP: CLEAN THE DATA (default: keep mean and two most energetic modes)

nn0 = size(Tensor);
nn = nn0;
nn(2:end) = 0;  % Mantiene la primera dimensión, el resto a cero

disp('Performing HOSVD. Please wait...');
[hatT, U, S, sv, nn] = hosvd_function(Tensor, varepsilon1, nn, nn0, TimePos);
disp('HOSVD complete!');

disp('Performing HODMD. Please wait...');
[GrowthRate,Frequency,Amplitude,hatMode] = DMDd(hatT, d, Time, varepsilon1, varepsilon);
disp('HODMD complete!');

% Reconstruct the original Tensor using the DMD expansion
TensorReconst = DMDreconst(GrowthRate(1:3),Frequency(1:3),hatMode(:,1:3),Time,U,S,sv,nn,TimePos);

N = size(hatT, 1);
% CALCULATE DMD MODES
('Calculating DMD modes...')
[N,~]=size(hatT);
hatMode_m=zeros(N,length(Amplitude));
for ii=1:length(Amplitude)
    hatMode_m(:,ii)=hatMode(:,ii)/Amplitude(ii);
end

% Temporal DMD modes in reduced dimension
Modes = U;
Modes{TimePos} = hatMode_m';
% Reconstruction of the temporal DMD modes
DMDmode0=tprod(S,Modes);

GrowthrateFrequencyAmplitude0 = [GrowthRate; Frequency; Amplitude];
TT0 = real(TensorReconst);

RRMSE = norm(reshape(Tensor - TT0, [], 1), 2) / norm(reshape(Tensor, [], 1), 2);
fprintf('Relative mean square error for HODMD: %.3f%%\n\n', RRMSE * 100)

%% SECOND STEP: DIRECT HODMD

disp('Performing HOSVD. Please wait...');
[hatT, U, S, sv, nn1] = hosvd_function(TT0, varepsilon1, nn, nn0, TimePos);
disp('HOSVD complete!');

disp('Performing HODMD. Please wait...');
[GrowthRate,Frequency,Amplitude,hatMode] = DMDd(hatT, d, Time, varepsilon1, varepsilon);
disp('HODMD complete!');

TensorReconst = DMDreconst(GrowthRate,Frequency,hatMode,Time,U,S,sv,nn1,TimePos);

N = size(hatT, 1);
% CALCULATE DMD MODES
('Calculating DMD modes...')
[N,~]=size(hatT);
hatMode_m=zeros(N,length(Amplitude));
for ii=1:length(Amplitude)
    hatMode_m(:,ii)=hatMode(:,ii)/Amplitude(ii);
end

% Temporal DMD modes in reduced dimension
Modes = U;
Modes{TimePos} = hatMode_m';
% Reconstruction of the temporal DMD modes
DMDmodeDIR=tprod(S,Modes);

GrowthrateFrequencyAmplitudeDIR = [GrowthRate; Frequency; Amplitude];
TTDIR = real(TensorReconst);

%% THIRD STEP: ADJOINT HODMD

Media = mean(TT0, TimePos);  % Promedio a lo largo de la dimensión temporal
TensorR = zeros(size(TT0));

for nsnap = 1:SNAP
    idx = SNAP - nsnap + 1;  % Inversión temporal
    TensorR(:,:,:,nsnap) = TT0(:,:,:,idx) - Media;  % Ajusta según las dimensiones
end

disp('Performing HOSVD. Please wait...');
[hatT, U, S, sv, nn1] = hosvd_function(TensorR, varepsilon1, nn, nn0, TimePos);
disp('HOSVD complete!');

disp('Performing HODMD. Please wait...');
[GrowthRate,Frequency,Amplitude,hatMode] = DMDd(hatT, d, Time, varepsilon1, varepsilon);
disp('HODMD complete!');

TensorReconst = DMDreconst(GrowthRate,Frequency,hatMode,Time,U,S,sv,nn1,TimePos);
nn10 = nn1;

N = size(hatT, 1);
% CALCULATE DMD MODES
('Calculating DMD modes...')
[N,~]=size(hatT);
hatMode_m=zeros(N,length(Amplitude));
for ii=1:length(Amplitude)
    hatMode_m(:,ii)=hatMode(:,ii)/Amplitude(ii);
end

% Temporal DMD modes in reduced dimension
Modes = U;
Modes{TimePos} = hatMode_m';
% Reconstruction of the temporal DMD modes
DMDmodeADJ=tprod(S,Modes);

GrowthrateFrequencyAmplitudeADJ = [GrowthRate; Frequency; Amplitude];
TTADJ = real(TensorReconst);

%% FOURTH STEP: NON-LINEAR STRUCTURAL SENSITIVITY

hx = X(1,2)-X(1,1);
hy = Y(2,1)-Y(1,1);

% Mode 0 gradient
u0 = squeeze(DMDmodeDIR(1,:,:,1)); 
v0 = squeeze(DMDmodeDIR(2,:,:,1)); 
[du0x,du0y]=gradient(u0,hx,hy);
[dv0x,dv0y]=gradient(v0,hx,hy);

Mean(1,:,:) = u0.*du0x+u0.*du0y;
Mean(2,:,:) = v0.*dv0x+v0.*dv0y;
ff1 = squeeze(Mean(1,:,:).*Mean(2,:,:));

% Direct mode gradient
ud = squeeze(DMDmodeDIR(1,:,:,2));
vd = squeeze(DMDmodeDIR(2,:,:,2));
[dudx,dudy]=gradient(ud,hx,hy);
[dvdx,dvdy]=gradient(vd,hx,hy);

PartD(1,:,:) =ud.*dudx+vd.*dudy;
PartD(2,:,:) =ud.*dvdx+vd.*dvdy;

% Adjoint mode gradient

ua = squeeze(DMDmodeADJ(1,:,:,1)); 
va = squeeze(DMDmodeADJ(2,:,:,1));
[duax,duay]=gradient(ua,hx,hy);
[dvax,dvay]=gradient(va,hx,hy);

PartA(1,:,:) =ua.*duax+va.*duay;
PartA(2,:,:) =ua.*dvax+va.*dvay;

% Compute nonlinear sensitivity
ff2 = sqrt((abs(PartD(1,:,:)).^2 + abs(PartD(2,:,:)).^2) .* ...
           (abs(PartA(1,:,:)).^2 + abs(PartA(2,:,:)).^2));

% Normalize and combine terms
ff1r = real(ff1);
NLSens = abs(GrowthrateFrequencyAmplitudeADJ(2,2)) * ff1r / max(ff1r(:)) + 2 * squeeze(ff2) / max(ff2(:));

% Locate maximum sensitivity point
[maxval, linearIndex] = max(NLSens(:));
[index1, index2] = ind2sub(size(NLSens), linearIndex);
X_index = X(index1,index2);
Y_index = Y(index1,index2);

fprintf('The maximum value of the sensitivity locates at: X = %.6f, Y = %.6f\n', X_index, Y_index);

%% PLOTS

% Plot 1: Amplitude and Growth Rate vs Frequency

fig_spec = figure;
subplot(1,2,1)
semilogy(Frequency, Amplitude / max(Amplitude), 'ob', 'MarkerSize', 6)
xlabel('Frequency', 'FontSize', 14)
ylabel('Amplitude', 'FontSize', 14)
grid on
title('Amplitude Spectrum')
set(gca, 'Box', 'on')

subplot(1,2,2)
semilogy(Frequency, abs(GrowthRate), 'or', 'MarkerSize', 6)
xlabel('Frequency', 'FontSize', 14)
ylabel('Growth Rate', 'FontSize', 14)
grid on
title('Growth Rate Spectrum')
set(gca, 'Box', 'on')


% Plot 2: Real part of direct mode (first component)
moded = squeeze(DMDmodeDIR(1,:,:,2));
fig_dir = figure;
contourf(X, Y, real(moded), 20, 'LineStyle', 'none')
colorbar
xlabel('X', 'FontSize', 14)
ylabel('Y', 'FontSize', 14)
title('Direct Mode (1st Component)', 'FontSize', 14)


% Plot 3: Real part of adjoint mode (first component)
modea = squeeze(DMDmodeADJ(1,:,:,2));
fig_adj = figure;
contourf(X, Y, real(modea), 20, 'LineStyle', 'none')
colorbar
xlabel('X', 'FontSize', 14)
ylabel('Y', 'FontSize', 14)
title('Adjoint Mode (1st Component)', 'FontSize', 14)


% Plot 4: First nonlinear term ||M|| * ||M||

fig_MM = figure;
contourf(X, Y,  real(ff1) / max(real(ff1(:))), 20, 'LineStyle', 'none')
colorbar
title('||M|| * ||M||')
xlabel('X')
ylabel('Y')


% Plot 5: Second nonlinear term ||N|| * ||N*||

fig_NN = figure;
contourf(X, Y, squeeze(ff2) / max(ff2(:)), 20, 'LineStyle', 'none')
colorbar
title('||N|| * ||N*||')
xlabel('X')
ylabel('Y')


% Plot 6: Nonlinear Structural Sensitivity

fig_NL = figure;
contourf(X, Y, NLSens, 20, 'LineStyle', 'none')
colorbar
title('Nonlinear Structural Sensitivity')
xlabel('X')
ylabel('Y')

%% Saving data and figures

% Set output folder
filen = sprintf('%s_mdHODMD_NL_solution_d%d_tolSVD%.1e_tolDMD%.1e', timestr, d, varepsilon1, varepsilon);
output_folder = fullfile(path0, filen);

if ~exist(output_folder, 'dir')
    mkdir(output_folder);
end
fprintf('Saving files and plots...\n');

% Save Nonlinear Sensitivity (NLSens)
save(fullfile(output_folder, 'NLSens.mat'), 'NLSens');

% === Step 1 ===
step1_folder = fullfile(output_folder, 'Step_1');
if ~exist(step1_folder, 'dir')
    mkdir(step1_folder);
end
save(fullfile(step1_folder, 'DMDmode.mat'), 'DMDmode0');
save(fullfile(step1_folder, 'GrowthrateFrequencyAmplitude.mat'), 'GrowthrateFrequencyAmplitude0');
save(fullfile(step1_folder, 'Tensor_Reconst.mat'), 'TT0');

% === Step 2 ===
step2_folder = fullfile(output_folder, 'Step_2');
if ~exist(step2_folder, 'dir')
    mkdir(step2_folder);
end
save(fullfile(step2_folder, 'DMDmode.mat'), 'DMDmodeDIR');
save(fullfile(step2_folder, 'GrowthrateFrequencyAmplitude.mat'), 'GrowthrateFrequencyAmplitudeDIR');
save(fullfile(step2_folder, 'Tensor_Reconst.mat'), 'TTDIR');

% === Step 3 ===
step3_folder = fullfile(output_folder, 'Step_3');
if ~exist(step3_folder, 'dir')
    mkdir(step3_folder);
end
save(fullfile(step3_folder, 'DMDmode.mat'), 'DMDmodeADJ');
save(fullfile(step3_folder, 'GrowthrateFrequencyAmplitude.mat'), 'GrowthrateFrequencyAmplitudeADJ');
save(fullfile(step3_folder, 'Tensor_Reconst.mat'), 'TTADJ');

% Save plots
saveas(fig_spec, fullfile(output_folder, 'plot_spectrum.png'));
saveas(fig_dir,  fullfile(output_folder, 'plot_dirmode.png'));
saveas(fig_adj,  fullfile(output_folder, 'plot_adjmode.png'));
saveas(fig_MM,   fullfile(output_folder, 'plot_MM.png'));
saveas(fig_NN,   fullfile(output_folder, 'plot_NN.png'));
saveas(fig_NL,   fullfile(output_folder, 'plot_NLSens.png'));

fprintf('Files saved in %s\n', filen);












