%% IMPORT VARIABLES
clear; clc;

disp(' ');
disp('Gappy svd/hosvd Algorithm');
disp('-----------------------------');

% Timestamp
timestr = datestr(now, 'yyyy-mm-dd_HH.MM.SS');

% Working directory
path0 = pwd;

% Load dataset
disp(' ');
disp('Loading the dataset...');
data = load('Tensor.mat');
Tensor = data.Tensor;
disp('Dataset loaded!');

%% CREATE RANDOM GAPS

A_gappy = Tensor;
mask = rand(size(Tensor)) < 0.2;
A_gappy(mask) = NaN;

gap_percentage = sum(isnan(A_gappy), 'all') / numel(A_gappy) * 100;
fprintf('Percentage of gaps: %.2f%%\n', gap_percentage);

%% CALIBRATION

method = 'hosvd';
m = 10;
decision_1 = 'zeros';

fprintf('\n-----------------------------\n');
fprintf('Database repairing summary:\n');
fprintf('The method used is: %s\n', method);
fprintf('Initial reconstruction fills the gaps using: %s\n', decision_1);
fprintf('Number of SVD modes retained: %d\n', m);
fprintf('-----------------------------\n');

%% INITIAL RECONSTRUCTION
A0_1 = A_gappy;
N = sum(isnan(A_gappy(:)));

if strcmp(decision_1, 'zeros')
    A0_1(isnan(A_gappy)) = 0;

elseif strcmp(decision_1, 'mean')
    mean_val = mean(A_gappy(~isnan(A_gappy)), 'all');
    A0_1(isnan(A_gappy)) = mean_val;

elseif strcmp(decision_1, 'tensor_interp')
    sz = size(A_gappy);
    A_gappy_re = reshape(A_gappy, sz(1), sz(2)*sz(3), sz(4));
    for i = 1:sz(1)
        for j = 1:sz(4)
            v = squeeze(A_gappy_re(i, :, j));
            nan_idx = isnan(v);
            x = find(~nan_idx);
            if numel(x) >= 2
                v(nan_idx) = interp1(x, v(x), find(nan_idx), 'linear', 'extrap');
            else
                v(nan_idx) = 0;
            end
            A_gappy_re(i, :, j) = v;
        end
    end
    A0_1 = reshape(A_gappy_re, sz);
end

disp('Initial reconstruction complete!');

%% ITERATIVE HOSVD RECONSTRUCTION

A_s = A0_1;
MSE_gaps = zeros(500,1);

for ii = 1:500
    fprintf('\nIteration number: %d\n', ii);
    if strcmp(method, 'svd')
        fprintf('\nPerforming SVD. Please wait...\n');
        [U, S, V] = svd(A_s, 'econ');
        fprintf('SVD complete!\n');
    
        % Reconstruct the matrix using the first m singular values
        A_reconst = U(:, 1:m) * S(1:m, 1:m) * V(:, 1:m)';
    elseif strcmp(method, 'hosvd')
        n_vec = m * ones(1, ndims(A_s));
        disp('Performing HOSVD. Please wait...');
        [A_reconst, ~, ~, ~, ~] = hosvd(A_s, n_vec);
        disp('HOSVD complete!');
        
        MSE_gaps(ii) = norm(A_reconst(isnan(A_gappy)) - A_s(isnan(A_gappy))) / N;
    end

    if ii > 3 && (MSE_gaps(ii) >= MSE_gaps(ii-1) || MSE_gaps(ii) < 1e-9)
        break;
    else
        A_s(isnan(A_gappy)) = A_reconst(isnan(A_gappy));
    end
end

%% Plots
markers = {'o', 's', 'd', '^', 'v', 'p', '*', 'h', 'x', '+'};
colors = {'b', 'g', 'r', 'c', 'm', 'y', 'k'}; 

num_dims = ndims(Tensor);
figure('Position', [100, 100, 800, 600]);
disp('Plotting singular values decay');

if strcmp(method, 'svd')
    disp('Performing SVD. Please wait...');
    [U0, S0, V0] = svd(A0_1, 'econ');
    [U, S, V] = svd(A_s, 'econ');
    disp('SVD complete!');

    plot(diag(S0)/S0(1,1), 'kx', 'DisplayName', 'Initial'); hold on;
    plot(diag(S)/S(1,1), 'rx', 'DisplayName', 'Reconstructed');

elseif strcmp(method, 'hosvd')
    disp('Performing HOSVD. Please wait...');
    [~, ~, ~, sv0] = hosvd(A0_1, size(A0_1));
    [~, ~, ~, sv] = hosvd(A_s, size(A_s));
    disp('HOSVD complete!');

    for i = 1:num_dims
        s1 = sv0{1,i};
        s1 = s1 / max(s1);
        s = sv{1,i};
        s = s / max(s);
        
        semilogy(1:length(s1), s1, '-', 'Color', colors{i}, 'Marker', markers{i}, ...
            'LineWidth', 1.5, 'MarkerSize', 6, 'DisplayName', ['Initial dim' num2str(i)]); hold on;
        semilogy(1:length(s), s, ':', 'Color', colors{i}, 'Marker', markers{i}, ...
            'LineWidth', 1.5, 'MarkerSize', 6, 'DisplayName', ['Reconstructed dim' num2str(i)]);
    end
end

xlabel('Singular Value Index', 'FontSize', 14);
ylabel('Singular Value', 'FontSize', 14);
legend('FontSize', 12, 'Location', 'best');
grid on;
set(gca, 'XScale', 'log', 'YScale', 'log');
box on;

% Load X and Y from .mat files
X_struct = load('./X.mat');  % Use 'load' if file is version 7 or lower
Y_struct = load('./Y.mat');

X = X_struct.X;
Y = Y_struct.Y;

component = 1;  % MATLAB uses 1-based indexing
original_slice = squeeze(A0_1(component, :, :, end));
reconstructed_slice = squeeze(A_s(component, :, :, end));

vmin = min(min(original_slice(:)), min(reconstructed_slice(:)));
vmax = max(max(original_slice(:)), max(reconstructed_slice(:)));

figure('Position', [100, 100, 1200, 500]);

% Plot original tensor
subplot(1,2,1);
pcolor(X, Y, original_slice);
shading interp;  % Equivalent to Python's "shading='auto'"
caxis([vmin, vmax]);
title('Gappy Tensor', 'FontSize', 14);
xlabel('X', 'FontSize', 14);
ylabel('Y', 'FontSize', 14);
colorbar;

% Plot reconstructed tensor
subplot(1,2,2);
pcolor(X, Y, reconstructed_slice);
shading interp;
caxis([vmin, vmax]);
title('Reconstructed Tensor', 'FontSize', 14);
xlabel('X', 'FontSize', 14);
ylabel('Y', 'FontSize', 14);
colorbar;

%% Saving
filen = sprintf('%s_gappyHOSVD_solution_modes_%d', timestr,m);
output_folder = fullfile(path0, filen);

if ~exist(output_folder, 'dir')
    mkdir(output_folder);
end


disp('Saving files and plots...');
save(fullfile(output_folder, 'Tensor_Reconst.mat'), 'A_s');
saveas(gcf, fullfile(output_folder, 'plot_reconstruction.png'));