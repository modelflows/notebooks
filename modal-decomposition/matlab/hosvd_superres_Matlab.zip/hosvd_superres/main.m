%% Initialization

clc; clear; close all;

disp('Superresolution Algorithm');
disp('-----------------------------');

% Current date and time string
timestr = datestr(now, 'yyyy-mm-dd_HH.MM.SS');

% Get current working directory
path0 = pwd;

% Load tensor data
disp('Loading the dataset...');
data = load('Tensor.mat');  
Tensor = data.Tensor;
disp('Dataset loaded!');

%% Calibration

n = 1;         % Enhancement factor (2^n)
m = [2, 3];    % Spatial dimensions

disp('-----------------------------');
disp('Superresolution using HOSVD summary:');
fprintf('The spatial dimensions will be enhanced by a factor of: %d\n', 2^n);
fprintf('The spatial dimensions are: [%s]\n', num2str(m));
disp('-----------------------------');

%% Iterative HOSVD and Upscaling
Tensor_high_res = Tensor;
nn0 = size(Tensor);

for ii = 1:n
    disp('Performing HOSVD. Please wait...');
    
    [~, S, U, ~, ~] = hosvd(Tensor_high_res, nn0);

    disp('HOSVD complete!');
    
    Udens = U;
    
    for d = m
        x = linspace(0, 1, size(U{d}, 1) * 2);  % Interpolate to twice the points
        U_dens = zeros(length(x), size(S, d));
        for j = 1:size(S, d)
            U_col = U{d}(:, j);
            U_dens(:, j) = interp1(linspace(0,1,length(U_col)), U_col, x, 'spline');
        end
        Udens{d} = U_dens;
    end

    disp('Reconstructing tensor...');
    A_d = tprod(S, Udens);  % Ensure this function is implemented in MATLAB
    [Tensor_high_res,~,~,~] = hosvd(A_d, nn0);
    
    disp('HOSVD complete!');
end

%% Plots

mat = load('X.mat'); X = mat.X;
mat = load('Y.mat'); Y = mat.Y;

X_high_res = imresize(X, 2^n, 'bilinear');
Y_high_res = imresize(Y, 2^n, 'bilinear');

component = 1;  % MATLAB is 1-based
original_slice = squeeze(Tensor(component, :, :, end));
enhanced_slice = squeeze(Tensor_high_res(component, :, :, end));

vmin = min([original_slice(:); enhanced_slice(:)]);
vmax = max([original_slice(:); enhanced_slice(:)]);

figure;
subplot(1,2,1)
pcolor(X, Y, original_slice); shading interp;
title('Original Tensor'); xlabel('X'); ylabel('Y'); caxis([vmin vmax]);

subplot(1,2,2)
pcolor(X_high_res, Y_high_res, enhanced_slice); shading interp; 
title('Enhanced Tensor'); xlabel('X'); ylabel('Y'); caxis([vmin vmax]);


%% Saving

filen = sprintf('%s_SRHOSVD_solution_factor%d', timestr, 2^n);
output_folder = fullfile(path0, filen);

if ~exist(output_folder, 'dir')
    mkdir(output_folder);
end

disp('Saving files and plots...');

save(fullfile(output_folder, 'Tensor_high_res.mat'), 'Tensor_high_res');
save(fullfile(output_folder, 'X_high_res.mat'), 'X_high_res');
save(fullfile(output_folder, 'Y_high_res.mat'), 'Y_high_res');

saveas(gcf, fullfile(output_folder, 'plot_reconstruction.png'));

disp(['Files saved in ' filen]);