function [TensorReconst]=...
    DMDreconst(GrowthRate,Frequency,hatMode,Time,U)

% Initialize variables
K = length(Time);
[N,~] = size(hatMode);
hatTReconst=zeros(N,K);

% Reconstruction using the DMD expansion
for k=1:K
    hatTReconst(:,k)= ContReconst(Time(k),Time(1),hatMode,Time,GrowthRate,Frequency);
end

TensorReconst= U*hatTReconst;

