%% CLEAR
clc, clear all, close all

%% CALIBRATION
d   = 15;   % Number of HODMD windows (Recommendation 0.1-0.4*Nt)
tol = 2e-2; % Tolerance to truncate the number of modes retained

dT  = 1;      % Time step of the database
param = 2*pi; % Parameter to adimensionalize omega to Strouhal number

freq      = [0 0.15 0.30]; % Define the frequencies desired in St
tolerance = 0.1;     % Deviation permitted

ModeRes = 1; % Resolvent mode selected

%% LOAD DATA
% DMD Modes
load(sprintf('Cases/HODMD-RA_solution_d%d_tol%0.1e/DMDmode.mat',d,tol))

ModePos = ndims(DMDmode);
data_shape = size(DMDmode);



% Amplitude, Frequency and Growth Rate
load(sprintf('Cases/HODMD-RA_solution_d%d_tol%0.1e/GrowthrateFrequencyAmplitude.mat',d,tol))

Amplitude  = GrowthRateFrequencyAmplitude(:,3);
Frequency  = GrowthRateFrequencyAmplitude(:,2) / param;
GrowthRate = GrowthRateFrequencyAmplitude(:,1);

Omega = GrowthRate + sqrt(-1)*Frequency; % Spectral exponential

%% PREPROCESS DMD MODES
if ModePos == 4
    [Nv,Nx,Ny,Nm]=size(DMDmode);
    Matrix = reshape(DMDmode,[Nv*Nx*Ny,Nm]);

elseif ModePos == 5
    [Nv,Nx,Ny,Nz,Nm]=size(DMDmode);
    Matrix = reshape(DMDmode,[Nv*Nx*Ny*Nz,Nm]);
    
end

% Normalize
for i=1:size(Matrix,2)
     Matrix(:,i) = Amplitude(i) * Matrix(:,i)/norm(Matrix(:,i),2);
end

%% COMPUTE RESOLVENT WITH Q=I
I      = eye(size(Frequency,1)); % Define identity matrix
Lambda = diag(Omega);

Qhat = Matrix'*Matrix;
Fhat = cholcov(Qhat);

Forcing  = zeros(size(DMDmode));
Response = zeros(size(DMDmode));

for i = 1:length(Omega)
    
    f = Frequency(i);
    H = Fhat * inv(-sqrt(-1) * f * I - Lambda) * pinv(Fhat);

    [Psi S Phi] = svd(H);

    % FORCING MODE
    PhiRes      = Matrix * pinv(Fhat) * Phi;
    if ModePos == 4
        Forcing(:,:,:,i)  = reshape(PhiRes(:,ModeRes),data_shape(1:end-1));
    elseif ModePos == 5
        Forcing(:,:,:,:,i)  = reshape(PhiRes(:,ModeRes),data_shape(1:end-1));
    end

    % RESPONSE
    PsiRes      = Matrix * pinv(Fhat) * Psi;
    if ModePos == 4
        Response(:,:,:,i)  = reshape(PsiRes(:,ModeRes),data_shape(1:end-1));
    elseif ModePos == 5
        Response(:,:,:,:,i)  = reshape(PsiRes(:,ModeRes),data_shape(1:end-1));
    end
    
end

%% PLOT RESOLVENT MODES
% Obtain desired frequencies
indices = NaN(size(freq));
for i = 1:length(freq)
    [min_val, idx] = min(abs(Frequency - freq(i)));
    if min_val < tolerance
        indices(i) = idx;
    end
end

% Filter indices
if length(indices)>length(indices(~isnan(indices)))
    error('Some frequencies don´t match within tolerance. Check your input data.');
end
indices = indices(~isnan(indices));

figure(1)
hold on
plot(Frequency,Amplitude/max(Amplitude),'b+','LineWidth',2)
plot(Frequency(indices),Amplitude(indices)/max(Amplitude),'ro','LineWidth',3,'MarkerSize',15)
xlabel('St'); ylabel('Amplitude')
legend('Modes','Selected modes','Location','northeast')
set(gca,'XMinorGrid','on')
set(gca, 'YScale', 'log', 'FontSize', 14)
hold off

% Plot modes
f2 = figure(2);
nModes = length(freq);
k = 1;
for i = 1:nModes
    if ModePos == 4
        A1 = squeeze(Forcing(:, :, :, indices(i)));
        A1 = abs(sqrt(squeeze(A1(1,:,:)).^2 + squeeze(A1(2,:,:)).^2) .^2);
        A2 = squeeze(Response(:, :, :, indices(i)));
        A2 = abs(sqrt(squeeze(A2(1,:,:)).^2 + squeeze(A2(2,:,:)).^2) .^2);
    elseif ModePos == 5
        A1 = abs(squeeze(Forcing(:, :, :, data_shape(4), indices(i))));
        A1 = sqrt(squeeze(A1(1,:,:)).^2 + squeeze(A1(2,:,:)).^2 + squeeze(A1(3,:,:)).^2) .^2;
        A2 = abs(squeeze(Response(:, :, :, data_shape(4), indices(i))));
        A2 = sqrt(squeeze(A2(1,:,:)).^2 + squeeze(A2(2,:,:)).^2 + squeeze(A2(3,:,:)).^2) .^2;
    end
    A1 = (A1 - min(A1(:))) / (max(A1(:)) - min(A1(:)));
    A2 = (A2 - min(A2(:))) / (max(A2(:)) - min(A2(:)));

    subplot(nModes, 2, k);
    contourf(A1, 50, 'EdgeColor','none');
    title('Forcing', 'FontSize', 14, 'Interpreter','latex');
    subtitle(sprintf('Freq = %.2f', freq(i)), 'FontSize', 14, 'Interpreter','latex');

    subplot(nModes, 2, k+1);
    contourf(A2, 50, 'EdgeColor','none');
    title('Response', 'FontSize', 14, 'Interpreter','latex');
    subtitle(sprintf('Freq = %.2f', freq(i)), 'FontSize', 14, 'Interpreter','latex');
    colorbar

    k = k+2;
end
set(gcf, "Position", [100 100 1000 700])

%% Save 
save(sprintf('Cases/HODMD-RA_solution_d%d_tol%0.1e/Forcing.mat',d,tol),'Forcing','-v7.3')
save(sprintf('Cases/HODMD-RA_solution_d%d_tol%0.1e/Response.mat',d,tol),'Response','-v7.3')

exportgraphics(f2,sprintf('Cases/HODMD-RA_solution_d%d_tol%0.1e/Resolvent_Modes.png',d,tol))