%% CLEAR
clc, clear all, close all

%% LOAD DATABASE
% As a test case you may download the 2D flow past a cylinder database.
% LINK: https://drive.google.com/drive/folders/1eCrFwp8Zfk_Es5bNJI-1b5_rDyQVFx4A?usp=sharing
load ./Tensor.mat       % Original Dataset
Tensor0 = Tensor;
load ./Tensor_forced.mat % Forced Dataset
Tensor1 = Tensor;

[Nv,Nx,Ny,Nt] = size(Tensor0);

%% CALIBRATION
r = 13;         % Number of truncated modes
snaps = 50:125; % Select time span (linear growth rate region)
dt = 1;         % Define time step
Freq = 0.15;    % Select DMD Mode
ModeRes = 1;    % Select Resolvent Mode (1=Most energy, 2=Second, etc.)

t = (0:length(snaps)-1)*dt;

%% ORIGINAL
% Organize data
X = reshape(Tensor0,[Nv*Nx*Ny,Nt]);
X=X(:,snaps);

% Apply DMD
[omega,Phi,X_dmd,P,Psi,D,W,Z]=DMDexact(X,r,t);
omega = omega/(2*pi); % Strouhal Number

% Order DMD modes and frequencies
P=abs(P);
dummy1=[omega P Phi'];
dummy2=sortrows(dummy1,-2);
omega=dummy2(:,1);
P=dummy2(:,2);
Phi=dummy2(:,3:end)';
clear dummy1 dummy2

% Compute resolvent with Q=I
I=eye(size(omega,1),size(omega,1)); % Define Identity Matrix
Lambda=diag(omega);
Qhat=Phi'*Phi;
Fhat=cholcov(Qhat);

% Find Index for Desired DMD Mode
tolerance = 0.02;
[min_val, idx] = min(abs(imag(omega) - Freq));
if min_val < tolerance
    Index = idx;
else
    error('Frequency not found, change value or tolerance')
end

% Construct Resolvent Operator
om=abs(imag(omega(Index)));
H = Fhat*pinv(-sqrt(-1)*om*I-Lambda)*pinv(Fhat);
[Psif, Sf, Phif]=svd(H);

% Calculate Resolvent Modes
PhiRes=Phi*pinv(Fhat)*Phif; % Forcing Mode
PsiRes=Phi*pinv(Fhat)*Psif; % Response Mode

PhiRes = reshape((PhiRes(:,ModeRes)),[Nv,Nx,Ny]);
PsiRes = reshape((PsiRes(:,ModeRes)),[Nv,Nx,Ny]);

%% FORCED
% Organize data
X1 = reshape(Tensor1,[Nv*Nx*Ny,Nt]);
X1 = X1(:,snaps);

% Apply DMD
[omega1,Phi1,X_dmd1,P1,Psi1,D1,W1,Z1]=DMDexact(X1,r,t);
omega1 = omega1/(2*pi); % Strouhal Number

% Order DMD modes and frequencies
P1=abs(P1);
dummy1=[omega1 P1 Phi1'];
dummy2=sortrows(dummy1,-2);
omega1=dummy2(:,1);
P1=dummy2(:,2);
Phi1=dummy2(:,3:end)';
clear dummy1 dummy2

% Compute resolvent with Q=I
I1=eye(size(D1,1),size(D1,2));% Define Identity Matrix
Lambda1=diag(omega1);
Qhat1=Phi1'*Phi1;
Fhat1=chol(Qhat1);

% Find Index for Desired DMD Mode
tolerance = 0.02;
[min_val, idx] = min(abs(imag(omega1) - Freq));
if min_val < tolerance
    Index1 = idx;
else
    error('Frequency not found, change value or tolerance')
end

% Construct Resolvent Operator
om1=abs(imag(omega1(Index1)));
H1 = Fhat1*inv(-sqrt(-1)*om1*I1-Lambda1)*inv(Fhat1);
[Psif1, Sf1, Phif1]=svd(H1);

% Calculate Resolvent Modes
PhiRes1=Phi1*inv(Fhat)*Phif; % Forcing Mode
PsiRes1=Phi1*inv(Fhat)*Psif; % Response Mode

PhiRes1 = reshape((PhiRes1(:,ModeRes)),[Nv,Nx,Ny]);
PsiRes1 = reshape((PsiRes1(:,ModeRes)),[Nv,Nx,Ny]);


%% PLOT
% Plot DMD Spectra
figure(1); hold on
plot(imag(omega),P/max(P),'bo','LineWidth',2,'MarkerSize',10,'DisplayName','Original')
plot(imag(omega1),P1/max(P1),'r+','LineWidth',2,'MarkerSize',10,'DisplayName','Forced')
xlabel('St','Interpreter','latex'); ylabel('$a_m$','Interpreter','latex')
xlim([-0.4 0.4])
legend('Location','northeast')
set(gca,'YScale','log','FontSize',18,'TickLabelInterpreter','latex')
set(gcf,'Position',[100 100 800 500])


% Plot DMD modes
[Nnx, Nmode]=size(Phi);
TensorMode=reshape((Phi(:,:)),[Nv,Nx,Ny,Nmode]);

f_dmd = figure(2); hold on

A = abs(sqrt(squeeze(TensorMode(1,:,:,Index)).^2 + squeeze(TensorMode(2,:,:,Index)).^2));

contourf(A,20,'EdgeColor','none');
contour(squeeze(abs(TensorMode(1,:,:,Index))),1,'EdgeColor','r','LineWidth',1.2)
contour(squeeze(abs(TensorMode(2,:,:,Index))),1,'EdgeColor','w','LineWidth',1.2)
shading interp
xlabel('X','Interpreter','latex'); ylabel('Y','Interpreter','latex')
set(gca,'FontSize',18,'TickLabelInterpreter','latex')
set(gcf,'Position',[200 100 1000 400])
% exportgraphics(f_dmd,sprintf('./Final representations/2D/DMD_%d.png',mm))


% Plot Resolvent Modes
f_res = figure(3);

A = squeeze(abs(sqrt(PhiRes(1,:,:).^2+ PhiRes(2,:,:).^2)));
B = squeeze(abs(sqrt(PsiRes(1,:,:).^2+ PsiRes(2,:,:).^2)));
A1 = squeeze(abs(sqrt(PhiRes1(1,:,:).^2+ PhiRes1(2,:,:).^2)));
B1 = squeeze(abs(sqrt(PsiRes1(1,:,:).^2+ PsiRes1(2,:,:).^2)));

A = 2*(A-min(A(:)))/(max(A(:))-min(A(:)))-1;
B = 2*(B-min(B(:)))/(max(B(:))-min(B(:)))-1;
A1 = 2*(A1-min(A1(:)))/(max(A1(:))-min(A1(:)))-1;
B1 = 2*(B1-min(B1(:)))/(max(B1(:))-min(B1(:)))-1;

sf1=subplot(2,2,1);
contourf(A,20,'edgecolor','none')
shading interp
xlabel('X','Interpreter','latex'); ylabel('Y','Interpreter','latex'); 
clim([-1 1])
set(gca,'FontSize',18,'TickLabelInterpreter','latex')

sf2=subplot(2,2,2);
contourf(B,20,'edgecolor','none')
shading interp
xlabel('X','Interpreter','latex');
clim([-1 1])
colorbar
set(gca,'FontSize',18,'TickLabelInterpreter','latex')

sf3=subplot(2,2,3);
contourf(A1,20,'edgecolor','none')
shading interp
xlabel('X','Interpreter','latex'); ylabel('Y','Interpreter','latex')
clim([-1 1])
set(gca,'FontSize',18,'TickLabelInterpreter','latex')

sf4=subplot(2,2,4);
contourf(B1,20,'edgecolor','none')
shading interp
xlabel('X','Interpreter','latex');
clim([-1 1])
colorbar
set(gca,'FontSize',18,'TickLabelInterpreter','latex')

h1=sf1.Position;
h2=sf2.Position;
h3=sf3.Position;
h4=sf4.Position;

sf1.Position = [h1(1) h1(2) h1(3) h1(4)];
sf2.Position = [h2(1)-0.06 h2(2) h1(3) h1(4)];
sf3.Position = [h3(1) h3(2) h1(3) h1(4)];
sf4.Position = [h4(1)-0.06 h4(2) h1(3) h1(4)];

set(gcf, 'Position', [300 100 1200 600]);

% exportgraphics(f_res,'./Final_representations/2D/Resolvent.png')

