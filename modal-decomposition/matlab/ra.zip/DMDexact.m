function [omega,Phi,X_dmd,b,Psi,D,W,Z]=DMDexact(X,r,t)

%% DMD
X1=X(:,1:end-1);
X2=X(:,2:end);

% Reduce rank
% SVD rank
[U,S,V]=svd(X1,'econ');
Ur = U(:, 1:r); % truncate to rank-r
Sr = S(1:r, 1:r);
Vr = V(:, 1:r);

% Build Atilde and DMD modes
Atilde=Ur'*X2*Vr/Sr;
[W, D, Z] = eig(Atilde);

% Scaling adjoint modes to form an orthogonal basis
for i=1:r
    scale=Z(:,i)'*W(:,i);
    Z(:,i)=Z(:,i)/scale;
end
% ADJOINT MODES
Psi = Ur*Z;

% DMD DIRECT MODES
% Phi = X2*Vr/Sr*W;
Phi = X2*Vr*pinv(Sr)*W*diag(diag(D).^-1);

% NORMALIZE direct & adjoint modes
for i=1:size(Phi,2)
    Phi(:,i)=Phi(:,i)/norm(Phi(:,i),2);
    Psi(:,i)=Psi(:,i)/norm(Psi(:,i),2);
end
% CHEKC direct & adjoint modes form and orthogonal (orthonormal) basis
Id=Psi'*Phi;
Id2=Phi'*Psi;

%% PLOT RITZ spectrum

figure(1000)
theta = (0:1:100)*2*pi/100;
plot(cos(theta),sin(theta),'k--') % plot unit circle
hold on, grid on
scatter(real(diag(D)),imag(diag(D)),'ok')
axis([-1.1 1.1 -1.1 1.1]);
close all
% DMD spectra
dt=t(2)-t(1);
lambda=diag(D);
omega=log(lambda)/dt;

% Reconstruct the solution with DMD
X1=X(:,1); % Initial condition
b=Phi\X1; % This is an inverse regression.
%But we can solve and optimization problem to obtain b: Optimized DMD
time_dynamics=zeros(r,length(t));
for iter=1:length(t)
    time_dynamics(:,iter)=(b.*exp(omega*t(iter)));
end
X_dmd=Phi*time_dynamics;

