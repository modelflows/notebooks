%% CLEAR
clc, clear all, close all

%% LOAD DATABASE
% As a test case you may download the 2D flow past a cylinder database.
% LINK: https://drive.google.com/drive/folders/1eaL945MC46rwhsft72LE_GtSCl15ugB4

load ./../Tensor.mat % Load data tensor
load ./../X.mat           % Load mesh
load ./../Y.mat           % Load mesh

[Ncomp, Nx, Ny, Nt] = size(Tensor); % Extract dimensions of data

%% CALIBRATION
tol_value = 1e-3;        % Tolerance to truncate the number of modes retained
TimePos = ndims(Tensor); % Important to have temporal dimension last

%% PERFORM HOSVD
% We need to remove mean of data
mean0 = mean(Tensor,ndims(Tensor));
T = Tensor - mean0;
% Transform into a matrix concatenate spatial information (Nv, Nx and Nz) and leave temporal dimension alone

% PERFORM HOSVD
[Tensor_Reconst, S, U, sv, n] = hosvd(T,tol_value);

PODmodes = tprod(S,U(1:TimePos-1));

Tensor_Reconst = Tensor_Reconst + mean0;

('Relative mean square error made in the calculations')
RRMSE = norm(Tensor(:)-Tensor_Reconst(:),2)/norm(Tensor(:),2)

%% PLOTS
field = 1; % Streamwise velocity for contours

% Plot singular value decay
figure(1); hold on
for i = 1:TimePos
    plot(sv{i}/max(sv{i}),'o-','DisplayName',sprintf('dim %d',i))
end
xlabel('Singular values number'); ylabel('Amplitude');
set(gca,"FontSize",14,'YScale','log')
box on
legend('Location','northeast')
set(gcf, "Position", [10 200 500 500])
f1 = gcf;

% Plot original vs reconstruction
figure(2)
subplot(2,1,1)
contourf(X,Y,squeeze(Tensor(field,:,:,100)),100,'EdgeColor','none')
shading interp; daspect([1 1 1])
xlabel('X'); ylabel('Y'); title(sprintf('Original',i))
box on
subplot(2,1,2)
contourf(X,Y,squeeze(Tensor_Reconst(field,:,:,100)),100,'EdgeColor','none')
shading interp; daspect([1 1 1])
xlabel('X'); ylabel('Y'); title(sprintf('Reconstruction',i))
box on
set(gcf, "Position", [510 200 500 500])
f2 = gcf;

% Plot POD modes
figure(3)
k = 1;
ind_modes = [1:5];
for i = ind_modes
    subplot(length(ind_modes),1,k)
    contourf(X,Y,squeeze(PODmodes(field,:,:,i)),100,'EdgeColor','none')
    shading interp; daspect([1 1 1])
    xlabel('X'); ylabel('Y'); title(sprintf('POD mode %d',i))
    box on
    
    k=k+1;
end
set(gcf, "Position", [1010 150 500 600])
f3 = gcf;

%% SAVE RESULTS
pathfile = sprintf('./Cases/POD_solution_tol%0.1e',tol_value);
mkdir(pathfile)

save(pathfile + '/sv.mat', "sv")
save(pathfile + '/Tensor_Reconst.mat', "Tensor_Reconst")
save(pathfile + '/PODmodes.mat', "PODmodes")

exportgraphics(f1, pathfile + '/sv_decay.png')
exportgraphics(f2, pathfile + '/reconstruction.png')
exportgraphics(f3, pathfile + '/modes.png')
