%% CLEAR
clc, clear all, close all

%% LOAD DATABASE
% As a test case you may download the 2D flow past a cylinder database.
% LINK: https://drive.google.com/drive/folders/1eaL945MC46rwhsft72LE_GtSCl15ugB4

load ./../Tensor.mat % Load data tensor

%% CALIBRATION
d_value = [25 50 100];   % Number of HODMD windows
tol_value = [1e-3 1e-4]; % Tolerance to truncate the number of modes retained
dT = 1;                  % Time step of the database

%% PARAMETERS AND REDUCTION OF TENSOR

TimePos = ndims(Tensor);

if TimePos == 4
    [Nv,Nx,Ny,Nt]=size(Tensor);
    Matrix = reshape(Tensor,[Nv*Nx*Ny,Nt]);

elseif TimePos == 5
    [Nv,Nx,Ny,Nz,Nt]=size(Tensor);
    Matrix = reshape(Tensor,[Nv*Nx*Ny*Nz,Nt]);
    
end

Time = [1:Nt]*dT;

%% PERFORM HODMD

k = 0;
for tol = tol_value
    k = k+1;
    clear hat* DMD* Mode* ome* del* ampl
    
    varepsilon1=tol % Tolerance for SVD
    varepsilon2=tol % Tolerance for DMD

    % PERFORM lcsvd
    tic
    [U,Sigma,V]=svd(Matrix,'econ');
    PODmodes = length(find(diag(Sigma)/Sigma(1,1)>varepsilon1));
    U = U(:,1:PODmodes);
    Sigma = Sigma(1:PODmodes,1:PODmodes);
    V = V(:,1:PODmodes);
    Timetoc(k) = toc;

    hatT = Sigma*V';
    % hatT: Reduced temporal matrix
    % U:    Temporal SVD modes
    % S:    Singular Values

    for d = d_value
        
        mkdir('DMD_solution')
        system('rm -r DMD_solution');
        mkdir('DMD_solution')
        filename = sprintf('./DMD_solution/DMD_history.txt' );
        diary(filename)

        % PERFORM DMD-d TO THE REDUCED TEMPORAL MATRIX hatT  
        if d>1
            [GrowthRate,Frequency,hatMode,Amplitude] = DMDd(d,hatT,Time,varepsilon1,varepsilon2);
        else
            [GrowthRate,Frequency,hatMode,Amplitude] = DMD1(hatT,Time,varepsilon1,varepsilon2);
        end
        % GrowthRate:   Growth rate of the DMD modes
        % Frequency:    Frequency of the DMD modes
        % hatMode:      Reduced DMD mode
        % Amplitude:    Amplitudes weighting the DMD modes        

        % CALCULATE DMD MODES
        ('Calculating DMD modes...')
        [N,~]=size(hatT);
        hatMode_m=zeros(N,length(Amplitude));
        for ii=1:length(Amplitude)
            hatMode_m(:,ii)=hatMode(:,ii)/Amplitude(ii);
        end
        % Reconstruction of the temporal DMD modes
        DMDmode= U*hatMode_m;

        % Reconstruct the original Tensor using the DMD expansion:
        Tensor_Reconst = DMDreconst(GrowthRate,Frequency,hatMode,Time,U);
        % Don't do this for complex data
        Tensor_Reconst = real(Tensor_Reconst); % Reconstruct database
        
        ('Relative mean square error made in the calculations')
        RRMSE = norm(Tensor(:)-Tensor_Reconst(:),2)/norm(Tensor(:),2)

        ('Growth rate, Frequency, Amplitude')
        GrowthRateFrequencyAmplitude = [GrowthRate',Frequency',Amplitude']
        
        % Convert the matrices to tensors
        if TimePos == 4
            DMDmode = reshape(DMDmode,[Nv,Nx,Ny,length(Amplitude)]);
            Tensor_Reconst = reshape(Tensor_Reconst,[Nv,Nx,Ny,Nt]);
        elseif TimePos == 5
            DMDmode = reshape(DMDmode,[Nv,Nx,Ny,Nz,length(Amplitude)]);
            Tensor_Reconst = reshape(Tensor_Reconst,[Nv,Nx,Ny,Nz,Nt]);
        end

        diary off
        
        % Save reconstruction and mode information
        save ./DMD_solution/Tensor_Reconst.mat Tensor_Reconst -v7.3
        save ./DMD_solution/GrowthrateFrequencyAmplitude.mat GrowthRateFrequencyAmplitude
        
        % Save DMD modes
        save ./DMD_solution/DMDmode.mat DMDmode -v7.3
        
        name_folder=sprintf('Cases/HODMD_solution_d%d_tol%0.1e',d,tol)
        movefile('DMD_solution',name_folder)

    end
end
