# In[0]: IMPORT PACKAGES

import hosvd
import DMDd
import os
import numpy as np
import matplotlib.pyplot as plt
from math import floor
os.environ['KMP_DUPLICATE_LIB_OK']='True'
import scipy.io
import mat73
import gdown
import time
import warnings
timestr = time.strftime("%Y-%m-%d_%H.%M.%S")

# Detect current working directory:
path0 = os.getcwd()

print('\nHODMD Algorithm for Flow Control')
print('\n-----------------------------')

print('''
The HODMD algorithm for flow control needs a prior calibration of HODMD.
    ''')
# In[1]: CLONE TEST CASE DATA

# Here we clone the test case available in our databases of a flow past a 2d cylinder
# Comment following line if it is not the first run or you have your own database
# The necessary files are the both the database and the meshfiles
gdown.download_folder("https://drive.google.com/drive/folders/1eaL945MC46rwhsft72LE_GtSCl15ugB4", output="./")


# In[2]: LOAD DATA
print('\nLoading the dataset...')
f = mat73.loadmat('./Tensor.mat')
Tensor = f['Tensor']
print('\nDataset loaded!')

TimePos = Tensor.ndim  # Here the position of the temporal dimension is introduced

f = mat73.loadmat('./X.mat')  # Load the mesh for the calculation of the structural sensitivity
X = f['X']
f = mat73.loadmat('./Y.mat')
Y = f['Y']

Malla = np.stack((X,Y), axis = 0)
# In[3]: PROCESS DATA

SNAP = int(Tensor.shape[-1])  # Change SNAP to reduce number of snapshots

Tensor = Tensor[..., 0:SNAP]
shape = Tensor.shape

# In[4]: CALIBRATION

d = 50              # Number of HODMD windows
varepsilon1 = 1e-3  # Tolerance to truncate the number of SVD modes retained
varepsilon  = 1e-4  # Tolerance to truncate the number of DMD modes retained
deltaT = 1          # Time step of the database

Time = np.linspace(0,SNAP-1,num=SNAP)*deltaT

# In[5]: SUMMARY

print('\n-----------------------------')
print('HODMD summary:')
print('\n' + f'Number of snapshots set at: {SNAP}')
print(f'd Parameter set at: {d}')
print(f'Tolerances set at {varepsilon1} for SVD and {varepsilon} for HODMD')
print(f'Time gradient set at deltaT: {deltaT}')
print('\n-----------------------------')


# In[6]: PERFORM HOSVD
nn0 = np.array(Tensor.shape)
nn = np.array(nn0)
nn[1:np.size(nn)] = 0 

print('Performing HOSVD. Please wait...\n')
hatT, U, S, sv, nn1, n, TT = hosvd.HOSVD(Tensor, varepsilon1, nn, nn0, TimePos)
print('\nHOSVD complete!\n')

RRMSE = np.linalg.norm(np.reshape(Tensor-TT,newshape=(np.size(Tensor),1)),ord=2)/np.linalg.norm(np.reshape(Tensor,newshape=(np.size(Tensor),1)))
print(f'Relative mean square error for HOSVD: {np.round(RRMSE*100, 3)}%\n')


# In[6]: FIRST STEP: CLEAN THE DATA (default: the mean and the first two modes with the highest amplitude)


## Perform HODMD to the reduced temporal matrix hatT:
print('Performing HODMD. Please wait...\n')
[hatMode,Amplitude,Eigval,GrowthRate,Frequency] = DMDd.hodmd_IT(hatT,d,Time,varepsilon1,varepsilon)
print('\nHODMD complete!\n')

## Reconstruct the original Tensor using the DMD expansion:
TensorReconst = DMDd.reconst_IT(hatMode[:,:3],Time,U,S,sv,nn1,TimePos,GrowthRate[:3],Frequency[:3])
nn10 = nn1

N = np.shape(hatT)[0]
DMDmode0 = DMDd.modes_IT(N,hatMode,Amplitude,U,S,nn1,TimePos)

GrowthrateFrequencyAmplitude0 = np.array([GrowthRate, Frequency, Amplitude])
TT0 = np.real(TensorReconst)

RRMSE = np.linalg.norm(np.reshape(Tensor-TT,newshape=(np.size(Tensor),1)),ord=2)/np.linalg.norm(np.reshape(Tensor,newshape=(np.size(Tensor),1)))
print(f'Relative mean square error for HODMD: {np.round(RRMSE*100, 3)}%\n')

# In[7]: SECOND STEP: DIRECT HODMD

print('Performing HOSVD. Please wait...\n')
hatT, U, S, sv, nn1, n, TT = hosvd.HOSVD(TT0, varepsilon1, nn, nn0, TimePos)
print('\nHOSVD complete!\n')

## Perform HODMD to the reduced temporal matrix hatT:
print('Performing HODMD. Please wait...\n')
[hatMode,Amplitude,Eigval,GrowthRate,Frequency] = DMDd.hodmd_IT(hatT,d,Time,varepsilon1,varepsilon)
print('\nHODMD complete!\n')

## Reconstruct the original Tensor using the DMD expansion:
TensorReconst = DMDd.reconst_IT(hatMode[:,:3],Time,U,S,sv,nn1,TimePos,GrowthRate[:3],Frequency[:3])
nn10 = nn1

N = np.shape(hatT)[0]
DMDmodeDIR = DMDd.modes_IT(N,hatMode,Amplitude,U,S,nn1,TimePos)

GrowthrateFrequencyAmplitudeDIR = np.array([GrowthRate, Frequency, Amplitude])
TTDIR = np.real(TensorReconst)

# In[8]: THIRD STEP: ADJOINT HODMD

Media = np.mean(TT0,axis=TimePos-1)  
TensorR = np.zeros(TT0.shape)

for nsnap in range(SNAP):
    TensorR[...,nsnap] = TT0[...,(SNAP-1)-nsnap] - Media

print('Performing HOSVD. Please wait...\n')
hatT, U, S, sv, nn1, n, TT = hosvd.HOSVD(TensorR, varepsilon1, nn, nn0, TimePos)
print('\nHOSVD complete!\n')

## Perform HODMD to the reduced temporal matrix hatT:
print('Performing HODMD. Please wait...\n')
[hatMode,Amplitude,Eigval,GrowthRate,Frequency] = DMDd.hodmd_IT(hatT,d,Time,varepsilon1,varepsilon)
print('\nHODMD complete!\n')

## Reconstruct the original Tensor using the DMD expansion:
TensorReconst = DMDd.reconst_IT(hatMode[:,:3],Time,U,S,sv,nn1,TimePos,GrowthRate[:3],Frequency[:3])
nn10 = nn1

N = np.shape(hatT)[0]
DMDmodeADJ = DMDd.modes_IT(N,hatMode,Amplitude,U,S,nn1,TimePos)

GrowthrateFrequencyAmplitudeADJ = np.array([GrowthRate, Frequency, Amplitude])
TTADJ = np.real(TensorReconst)

# In[9]: FOURTH STEP: NON-LINEAR STRUCTURAL SENSITIVITY

mode0 = DMDmodeDIR[...,0]
moded = DMDmodeDIR[...,1]
modea = DMDmodeADJ[...,0]

vector_x = Malla[0,0,:]
vector_y = Malla[1,:,0]
if vector_x[0] == vector_x[1]:
    vector_x = Malla[0,:,0]
    vector_y = Malla[1,0,:]
        
grad0 = np.gradient(mode0, vector_y,  vector_x, axis=(1,2))
grad0 = np.array(grad0).transpose((1,0,2,3))

Part1 = np.zeros(Malla.shape,dtype = np.complex128)
Part1[0,:,:] = mode0[0,:,:]*grad0[0,0,:,:]+mode0[1,:,:]*grad0[0,1,:,:]
Part1[1,:,:] = mode0[0,:,:]*grad0[1,0,:,:]+mode0[1,:,:]*grad0[1,1,:,:]

ff1 = np.linalg.norm(Part1,axis = 0)
    
gradd = np.gradient(moded, vector_y, vector_x, axis=(1,2))
gradd = np.array(gradd).transpose((1,0,2,3))

PartD = np.zeros(Malla.shape,dtype = np.complex128)
PartD[0,:,:] = moded[0,:,:]*gradd[0,0,:,:]+moded[1,:,:]*gradd[0,1,:,:]
PartD[1,:,:] = moded[0,:,:]*gradd[1,0,:,:]+moded[1,:,:]*gradd[1,1,:,:]
    
      
grada = np.gradient(modea, vector_y, vector_x, axis=(1,2))
grada = np.array(grada).transpose((1,0,2,3))
            
PartA = np.zeros(Malla.shape,dtype = np.complex128)
PartA[0,:,:] = modea[0,:,:]*grada[0,0,:,:]+modea[1,:,:]*grada[0,1,:,:]
PartA[1,:,:] = modea[0,:,:]*grada[1,0,:,:]+modea[1,:,:]*grada[1,1,:,:]
    
ff2= np.sqrt((abs(PartD[0,:,:])**2+abs(PartD[1,:,:])**2)*(abs(PartA[0,:,:])**2+abs(PartA[1,:,:])**2))
    
NLSens = np.abs(GrowthrateFrequencyAmplitudeADJ[1,1])* np.real(ff1)/np.amax(np.real(ff1)) + 2*ff2/np.amax(ff2)

index = np.argwhere(NLSens == np.amax(NLSens))
X_index = Malla[0,index[0,0],index[0,1]]
Y_index = Malla[1,index[0,0],index[0,1]]
print(f'The maximum value of the sensititvuity locates at: X  = {X_index} Y = {Y_index} ')

# In[10]: PLOTS

##### Plot amplitude and growth rate vs frequencies spectrum #####
fig_spec, axes = plt.subplots(1, 2, figsize=(12, 5))

axes[0].plot(Frequency, Amplitude / np.max(Amplitude), marker='o', color='b', linestyle='', markersize=6)
axes[0].set_yscale("log")
axes[0].set_xlabel("Frequency", fontsize=14)
axes[0].set_ylabel("Amplitude", fontsize=14)
axes[0].grid(True, which="both", linestyle="--", alpha=0.6)
axes[0].spines["top"].set_visible(True)
axes[0].spines["right"].set_visible(True)

# Growth Rate vs Frequency
axes[1].plot(Frequency, np.abs(GrowthRate), marker='o', color='r', linestyle='', markersize=6)
axes[1].set_yscale("log")
axes[1].set_xlabel("Frequency", fontsize=14)
axes[1].set_ylabel("Growth Rate", fontsize=14)
axes[1].grid(True, which="both", linestyle="--", alpha=0.6)
axes[1].spines["top"].set_visible(True)
axes[1].spines["right"].set_visible(True)

plt.tight_layout()
plt.show()


##### Plot direct mode #####
fig_dir, ax = plt.subplots()
im = plt.contourf(X, Y, np.real(moded[0,:,:]), cmap="viridis", shading="auto")
ax.set_title(f"Direct", fontsize=14)
ax.set_xlabel("X", fontsize=14)
ax.set_ylabel("Y", fontsize=14)

plt.tight_layout()
plt.show()

##### Plot adjoint mode #####
fig_adj, ax0 =  plt.subplots()
im = ax0.contourf(X, Y, np.real(modea[0,:,:]), cmap="viridis", shading="auto")
ax0.set_title(f"Adjoint", fontsize=14)
ax0.set_xlabel("X", fontsize=14)
ax0.set_ylabel("Y", fontsize=14)

plt.tight_layout()
plt.show()

##### Plot first term #####
fig_MM,ax = plt.subplots()
plt.contourf(Malla[0,:,:],Malla[1,:,:],np.real(ff1)/np.amax(np.real(ff1)))
plt.title('||M||*||M||')
plt.tight_layout()
plt.show()

##### Plot second term #####         
fig_NN,ax =  plt.subplots()
plt.contourf(Malla[0,:,:],Malla[1,:,:],ff2/np.amax(ff2))
plt.title('||N||*||N*||')
plt.tight_layout()
plt.show()
 
##### Plot non-linear structural sensitivity #####          
fig_NL,ax =  plt.subplots()
plt.contourf(Malla[0,:,:],Malla[1,:,:],NLSens)
plt.tight_layout()
plt.show()
            

# In[7]: SAVE FILES

filen = f'{timestr}_mdHODMD_NL_solution_d{d}_tolSVD{varepsilon1}_tolDMD{varepsilon}'

if not os.path.exists(f'{path0}/{filen}'):
    os.mkdir(f"{path0}/{filen}")

print(f'Saving files and plots...')

mdic = {"NLSens": NLSens}
file_mat = str(f'{path0}/{filen}/NLSens.mat')
scipy.io.savemat(file_mat, mdic, appendmat=True, format='5')

if not os.path.exists(f'{path0}/{filen}/Step_1'):
    os.mkdir(f"{path0}/{filen}/Step_1")
    
mdic = {"DMDmode": DMDmode0}
file_mat = str(f'{path0}/{filen}/Step_1/DMDmode.mat')
scipy.io.savemat(file_mat, mdic, appendmat=True, format='5')
mdic = {"GrowthrateFrequencyAmplitude": GrowthrateFrequencyAmplitude0}
file_mat = str(f'{path0}/{filen}/Step_1/GrowthrateFrequencyAmplitude.mat')
scipy.io.savemat(file_mat, mdic, appendmat=True, format='5')
mdic = {"Tensor_Reconst": TT0}
file_mat = str(f'{path0}/{filen}/Step_1/Tensor_Reconst.mat')
scipy.io.savemat(file_mat, mdic, appendmat=True, format='5')

if not os.path.exists(f'{path0}/{filen}/Step_2'):
    os.mkdir(f"{path0}/{filen}/Step_2")
    
mdic = {"DMDmode": DMDmodeDIR}
file_mat = str(f'{path0}/{filen}/Step_2/DMDmode.mat')
scipy.io.savemat(file_mat, mdic, appendmat=True, format='5')
mdic = {"GrowthrateFrequencyAmplitude": GrowthrateFrequencyAmplitudeDIR}
file_mat = str(f'{path0}/{filen}/Step_2/GrowthrateFrequencyAmplitude.mat')
scipy.io.savemat(file_mat, mdic, appendmat=True, format='5')
mdic = {"Tensor_Reconst": TTDIR}
file_mat = str(f'{path0}/{filen}/Step_2/Tensor_Reconst.mat')
scipy.io.savemat(file_mat, mdic, appendmat=True, format='5')

if not os.path.exists(f'{path0}/{filen}/Step_3'):
    os.mkdir(f"{path0}/{filen}/Step_3")
    
mdic = {"DMDmode": DMDmodeADJ}
file_mat = str(f'{path0}/{filen}/Step_3/DMDmode.mat')
scipy.io.savemat(file_mat, mdic, appendmat=True, format='5')
mdic = {"GrowthrateFrequencyAmplitude": GrowthrateFrequencyAmplitudeADJ}
file_mat = str(f'{path0}/{filen}/Step_3/GrowthrateFrequencyAmplitude.mat')
scipy.io.savemat(file_mat, mdic, appendmat=True, format='5')
mdic = {"Tensor_Reconst": TTADJ}
file_mat = str(f'{path0}/{filen}/Step_3/Tensor_Reconst.mat')
scipy.io.savemat(file_mat, mdic, appendmat=True, format='5')

fig_spec.savefig(f"{path0}/{filen}/plot_spectrum.png", dpi=300, bbox_inches="tight")
fig_dir.savefig(f"{path0}/{filen}/plot_dirmode.png", dpi=300, bbox_inches="tight")
fig_adj.savefig(f"{path0}/{filen}/plot_adjmode.png", dpi=300, bbox_inches="tight")
fig_MM.savefig(f"{path0}/{filen}/plot_MM.png", dpi=300, bbox_inches="tight")
fig_NN.savefig(f"{path0}/{filen}/plot_NN.png", dpi=300, bbox_inches="tight")
fig_NL.savefig(f"{path0}/{filen}/plot_NLSens.png", dpi=300, bbox_inches="tight")

print(f'Files saved in {filen}')


