# In[0]: IMPORT PACKAGES

import hosvd
import DMDd
import os
import numpy as np
import scipy as sp
import matplotlib.pyplot as plt
from math import floor
os.environ['KMP_DUPLICATE_LIB_OK']='True'
import scipy.io
import mat73
import gdown
import time
import warnings
timestr = time.strftime("%Y-%m-%d_%H.%M.%S")

# Detect current working directory:
path0 = os.getcwd()

print('\nHODMD Algorithm')
print('\n-----------------------------')


# In[1]: CLONE TEST CASE DATA

# Here we clone the test case available in our databases of a flow past a 2d cylinder
# Comment following line if it is not the first run or you have your own database
gdown.download_folder("https://drive.google.com/drive/folders/1eaL945MC46rwhsft72LE_GtSCl15ugB4", output="./")

# In[2]: LOAD DATA
print('\nLoading the dataset...')
mat = mat73.loadmat('./Tensor.mat')
Tensor = mat["Tensor"]
print('\nDataset loaded!')

TimePos = Tensor.ndim  # Here the position of the temporal dimension is introduced


# In[3]: PROCESS DATA

SNAP = int(Tensor.shape[-1])  # Change SNAP to reduce number of snapshots

Tensor = Tensor[..., 0:SNAP]

shape = Tensor.shape  # Shape of the tensor
print(f'Tensor shape: {shape}')

# In[4]: CALIBRATION

d = 25                     # Number of HODMD windows
varepsilon1 = 1e-3         # Tolerance to truncate the number of SVD modes retained
varepsilon  = varepsilon1  # Tolerance to truncate the number of DMD modes retained
deltaT = 1                 # Time step of the database
n_iter = 1000       # Change to 1 if non-iterative approach is wanted


# In[5]: SUMMARY

print('\n-----------------------------')
print('HODMD summary:')
print('\n' + f'Number of snapshots set at: {shape[-1]}')
print(f'd Parameter set at: {d}')
print(f'Tolerances set at {varepsilon1} for SVD and {varepsilon} for HODMD')
print(f'Time gradient set at deltaT: {deltaT}')
print('\n-----------------------------')


# In[6]: PERFORM HOSVD
nn0 = np.array(Tensor.shape)
nn = np.array(nn0)
nn[1:np.size(nn)] = 0 

print('Performing HOSVD. Please wait...\n')
hatT, U, S, sv, nn1, n, TT = hosvd.HOSVD(Tensor, varepsilon1, nn, nn0, TimePos)
print('\nHOSVD complete!\n')

RRMSE = np.linalg.norm(Tensor - TT) / np.linalg.norm(Tensor) # Relative root mean square error
print(f'Relative mean square error for HOSVD: {np.round(RRMSE*100, 3)}%\n')


# In[6]: PERFORM HODMD

Time = np.linspace(0,shape[-1]-1,num=shape[-1])*deltaT

dims = Tensor.ndim

## Perform HODMD to the reduced temporal matrix hatT:
print('Performing HODMD. Please wait...\n')
[hatMode,Amplitude,Eigval,GrowthRate,Frequency] = DMDd.hodmd_IT(hatT,d,Time,varepsilon1,varepsilon)
print('\nHODMD complete!\n')

## Reconstruct the original Tensor using the DMD expansion:
TensorReconst = DMDd.reconst_IT(hatMode,Time,U,S,sv,nn1,TimePos,GrowthRate,Frequency)
nn10 = nn1

if n_iter>1:
	for zz in range(0,n_iter):
		print(f'Iteration number: {zz+1}')
		
		TensorIT = TensorReconst
		print(f'\nPerforming HOSVD for tol = {varepsilon1}. Please wait...\n')
		[hatTIT,UIT,SIT,svIT,nn1IT,nIT,TTIT] = hosvd.HOSVD(TensorIT,varepsilon1,nn,nn0,TimePos)
		
		## Perform HODMD to the reduced temporal matrix hatT:
		print('Performing HODMD. Please wait...\n')
		[hatMode,Amplitude,Eigval,GrowthRate,Frequency] = DMDd.hodmd_IT(hatTIT,d,Time,varepsilon1,varepsilon)
		print('\nHODMD complete!\n')
		
		## Reconstruct the original Tensor using the DMD expansion:
		TensorReconst = DMDd.reconst_IT(hatMode,Time,UIT,SIT,svIT,nn1IT,TimePos,GrowthRate,Frequency)
		
		## Break the loop when the number of singular values is the same in two consecutive iterations:
		if nn1IT==nn10:
			break
		nn10 = nn1IT
		print('\n')

if n_iter > 1:
	print(f'Final number of iterations for d = {d} and tol = {varepsilon1}: {zz+2}')
	print('Calculating DMD modes...')
	N = np.shape(hatTIT)[0]
	DMDmode = DMDd.modes_IT(N,hatMode,Amplitude,UIT,SIT,nn10,TimePos)
else:
	N = np.shape(hatT)[0]
	DMDmode = DMDd.modes_IT(N,hatMode,Amplitude,U,S,nn1,TimePos)

GrowthrateFrequencyAmplitude = np.array([GrowthRate, Frequency, Amplitude])
TT = np.real(TensorReconst)

RRMSE = np.linalg.norm(Tensor - TT) / np.linalg.norm(Tensor)
print(f'Relative mean square error for HODMD: {np.round(RRMSE*100, 3)}%\n')


# In[7]: PLOTS

##### Plot amplitude and growth rate vs frequencies spectrum #####
fig_spec, axes = plt.subplots(1, 2, figsize=(12, 5))

axes[0].plot(Frequency, Amplitude / np.max(Amplitude), marker='o', color='b', linestyle='', markersize=6)
axes[0].set_yscale("log")
axes[0].set_xlabel("Frequency", fontsize=14)
axes[0].set_ylabel("Amplitude", fontsize=14)
axes[0].grid(True, which="both", linestyle="--", alpha=0.6)
axes[0].spines["top"].set_visible(True)
axes[0].spines["right"].set_visible(True)

# Growth Rate vs Frequency
axes[1].plot(Frequency, np.abs(GrowthRate), marker='o', color='r', linestyle='', markersize=6)
axes[1].set_yscale("log")
axes[1].set_xlabel("Frequency", fontsize=14)
axes[1].set_ylabel("Growth Rate", fontsize=14)
axes[1].grid(True, which="both", linestyle="--", alpha=0.6)
axes[1].spines["top"].set_visible(True)
axes[1].spines["right"].set_visible(True)

plt.tight_layout()
plt.show()


##### Plot original vs reconstruction #####

component = 0  # First component

if TimePos == 4:
  original_slice = Tensor[component, :, :, shape[-1]-1]
  reconstructed_slice = TT[component, :, :, shape[-1]-1]
elif TimePos == 5:
  original_slice = Tensor[component, :, :, int(shape[3]/2), shape[-1]-1]
  reconstructed_slice = TT[component, :, :, int(shape[3]/2), shape[-1]-1]

vmin, vmax = min(original_slice.min(), reconstructed_slice.min()), max(original_slice.max(), reconstructed_slice.max())

fig_rec, axes_rec = plt.subplots(1, 2, figsize=(12, 5))

# Plot original tensor
im1 = axes_rec[0].pcolor(original_slice, cmap="viridis", shading="auto", vmin=vmin, vmax=vmax)
axes_rec[0].set_title("Original Tensor", fontsize=14)

# Plot reconstructed tensor
im2 = axes_rec[1].pcolor(reconstructed_slice, cmap="viridis", shading="auto", vmin=vmin, vmax=vmax)
axes_rec[1].set_title("Reconstructed Tensor", fontsize=14)

plt.tight_layout()
plt.show()


##### Plot modes #####
# Find desired frequencies
freq = np.array([0, 0.8, 1.6])
tolerance = 0.1  # Allowed deviation
indices = [np.argmin(np.abs(Frequency - f)) if np.any(np.abs(Frequency - f) < tolerance) else None for f in freq]

if None in indices:
    warnings.warn("Some frequencies have no match within tolerance. Skipping those modes.")

indices = [idx for idx in indices if idx is not None]

if not indices:
    raise ValueError("No frequencies matched within tolerance. Check your input data.")

# Extract corresponding modes
component = 0

# Real part of the modes
if TimePos == 4:
  modes = [np.real(DMDmode[component,:, :, idx]) for idx in indices]
elif TimePos == 5:
  modes = [np.real(DMDmode[component,:, :, int(shape[3]/2), idx]) for idx in indices]

# Create subplots
fig_modes_real, axes_modes = plt.subplots(1, len(freq), figsize=(15, 5))

for i, (ax, mode, f) in enumerate(zip(axes_modes, modes, freq)):
    
	vmin = min(mode.min() for mode in modes[i])
	vmax = max(mode.max() for mode in modes[i])
		
	im = ax.pcolor(mode, cmap="viridis", shading="auto", vmin=vmin, vmax=vmax)
	ax.set_title(f"$\omega$ = {f:.2f}", fontsize=14)
	ax.set_ylabel("Real", fontsize=14)
    
plt.tight_layout()
plt.show()

# Plot imaginary part of the modes
if TimePos == 4:
  modes = [np.imag(DMDmode[component,:, :, idx]) for idx in indices]
elif TimePos == 5:
  modes = [np.imag(DMDmode[component,:, :, int(shape[3]/2), idx]) for idx in indices]

# Create subplots
fig_modes_imag, axes_modes = plt.subplots(1, len(freq), figsize=(15, 5))

for i, (ax, mode, f) in enumerate(zip(axes_modes, modes, freq)):
    
	vmin = min(mode.min() for mode in modes[i])
	vmax = max(mode.max() for mode in modes[i])

	im = ax.pcolor(mode, cmap="viridis", shading="auto", vmin=vmin, vmax=vmax)
	ax.set_title(f"$\omega$ = {f:.2f}", fontsize=14)
	ax.set_ylabel("Imaginary", fontsize=14)
    
plt.tight_layout()
plt.show()

# In[7]: SAVE FILES

filen = f'{timestr}_mdHODMDit_solution_d{d}_tolSVD{varepsilon1}_tolDMD{varepsilon}'

if not os.path.exists(f'{path0}/{filen}'):
    os.mkdir(f"{path0}/{filen}")

print(f'Saving files and plots...')

mdic = {"DMDmode": DMDmode}
file_mat = str(f'{path0}/{filen}/DMDmode.mat')
sp.io.savemat(file_mat, mdic, appendmat=True, format='5')
mdic = {"GrowthrateFrequencyAmplitude": GrowthrateFrequencyAmplitude}
file_mat = str(f'{path0}/{filen}/GrowthrateFrequencyAmplitude.mat')
sp.io.savemat(file_mat, mdic, appendmat=True, format='5')
mdic = {"Tensor_Reconst": TT}
file_mat = str(f'{path0}/{filen}/Tensor_Reconst.mat')
sp.io.savemat(file_mat, mdic, appendmat=True, format='5')

fig_spec.savefig(f"{path0}/{filen}/plot_spectrum.png", dpi=300, bbox_inches="tight")
fig_rec.savefig(f"{path0}/{filen}/plot_reconstruction.png", dpi=300, bbox_inches="tight")
fig_modes_real.savefig(f"{path0}/{filen}/plot_modes_real.png", dpi=300, bbox_inches="tight")
fig_modes_imag.savefig(f"{path0}/{filen}/plot_modes_imag.png", dpi=300, bbox_inches="tight")

print(f'Files saved in {filen}')


