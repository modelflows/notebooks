import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import correlate
from scipy.interpolate import interp1d

def normalize_to_minus1_1(signal):
    min_val = np.min(signal)
    max_val = np.max(signal)
    return 2 * (signal - min_val) / (max_val - min_val) - 1

def estimate_period_autocorrelation(signal, min_period=10, max_lag=None):
    signal = signal - np.mean(signal)
    corr = correlate(signal, signal, mode='full')
    corr = corr[corr.size // 2:]
    if max_lag is None:
        max_lag = len(corr) // 2
    corr[:min_period] = 0
    peak_lag = np.argmax(corr[:max_lag])
    return peak_lag

def find_first_zero_upcrossing(signal):
    for i in range(1, len(signal)):
        if signal[i-1] < 0 and signal[i] >= 0:
            return i
    raise ValueError("No zero-upcrossing found.")

def interpolate_by_pod_phase(data, start_idx, period_length, N_snapshots, method='cubic', N_periods=4):
    nvar, nx, ny, nt = data.shape
    end_idx = start_idx + N_periods * period_length
    if end_idx > nt:
        raise ValueError("Selected periods go beyond available time steps.")
    t_original = np.linspace(0, 1, period_length)
    t_interp = np.linspace(0, 1, N_snapshots)
    interpolated = np.zeros((nvar, nx, ny, N_snapshots * N_periods))
    for p in range(N_periods):
        data_period = data[..., start_idx + p * period_length : start_idx + (p + 1) * period_length]
        for i in range(nvar):
            for x in range(nx):
                for y in range(ny):
                    f = interp1d(t_original, data_period[i, x, y, :], kind=method)
                    interpolated[i, x, y, p * N_snapshots : (p + 1) * N_snapshots] = f(t_interp)
    return interpolated

def extract_and_align_period(data, N_snapshots=32, interpolation_method='cubic', min_period=10, N_periods=4):
    nvar, nx, ny, nt = data.shape
    X = data.reshape(nvar * nx * ny, nt)
    U, S, Vh = np.linalg.svd(X, full_matrices=False)
    a1 = Vh[0, :]
    a1_norm = normalize_to_minus1_1(a1)
    period_length = estimate_period_autocorrelation(a1_norm, min_period=min_period)
    start_idx = find_first_zero_upcrossing(a1_norm)
    if start_idx + N_periods * period_length > nt:
        start_idx = nt - N_periods * period_length
    interpolated = interpolate_by_pod_phase(data, start_idx, period_length, N_snapshots, interpolation_method, N_periods)
    x_phase = np.linspace(0, 2 * np.pi, len(a1_norm), endpoint=False)
    plt.figure(figsize=(8, 4))
    plt.plot(x_phase, a1_norm, label='Normalized POD Mode 1')
    plt.axvline(x=x_phase[start_idx], color='green', linestyle='--', label='Start of 1st Period')
    plt.axvline(x=x_phase[start_idx + period_length * N_periods], color='blue', linestyle='--', label='End of Last Period')
    plt.title('Phase-Aligned POD Mode 1 (Start at Zero-Upcrossing)')
    plt.xlabel('Phase [rad]')
    plt.ylabel('Amplitude [-1, 1]')
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.show()
    return interpolated, a1_norm, period_length

def process_simulations(filepaths, N_snapshots=32, interpolation_method='cubic', min_period=10, N_periods=4):
    aligned_snapshots = []
    for path in filepaths:
        print(f"Processing: {path}")
        data = np.load(path)
        if data.shape[1] == 128:
            data = data[:, ::1, ::1, :]
        interpolated, a1_norm, period_length = extract_and_align_period(
            data, N_snapshots, interpolation_method, min_period, N_periods
        )
        aligned_snapshots.append(interpolated)
    aligned_snapshots = np.stack(aligned_snapshots, axis=0)
    return aligned_snapshots

filepaths = [
    # "200_05_complex.npy", "200_10_complex.npy", "200_15_complex.npy",
    # "200_20_complex.npy", "200_25_complex.npy", "200_30_complex.npy",
    # "220_05_complex.npy", "220_10_complex.npy", "220_15_complex.npy",
    # "240_15_complex.npy"
    "200_05_complex.npy"
    # "220_30_complex.npy",
    # "240_5_complex.npy", "240_10_complex.npy", "240_15_complex.npy",
    # "240_20_complex.npy", "240_25_complex.npy", "240_30_complex.npy",
    # "260_5_complex.npy", "260_10_complex.npy", "260_15_complex.npy",
    # "260_20_complex.npy", "260_25_complex.npy", "260_30_complex.npy",
    # "280_5_complex.npy", "280_10_complex.npy", "280_15_complex.npy",
    # "280_20_complex.npy", "280_25_complex.npy", "280_30_complex.npy",
    # "220_05_complex.npy", "230_225_complex.npy"
]

N_phase_snaps = 32
interpolation_method = 'cubic'
N_periods = 10

aligned_snapshots = process_simulations(
    filepaths,
    N_snapshots=N_phase_snaps,
    interpolation_method=interpolation_method,
    min_period=10,
    N_periods=N_periods
)

probe_coords = (48, 32)
plt.figure(figsize=(8, 6))
for i in range(aligned_snapshots.shape[0]):
    plt.plot(
        np.linspace(0, 2 * np.pi * N_periods, N_phase_snaps * N_periods, endpoint=False),
        aligned_snapshots[i, 1, probe_coords[0], probe_coords[1], :],
        label=f'Sim {i}'
    )
plt.xlabel('Phase [rad]')
plt.ylabel('v @ Probe')
plt.title('POD-Aligned Wake Evolution Across Simulations')
plt.legend(ncol=3, fontsize=8)
plt.grid(True)
plt.tight_layout()
plt.show()

# np.save("target240_15.npy", aligned_snapshots)
