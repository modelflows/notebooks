#!/bin/bash

# Suppress all files in the specified folders
rm -rf MDI/*
rm -rf SuperRes/*
rm -rf pointEvoVel/*

# Suppress specific files matching patterns (with parentheses)
rm -f cases_\(*
rm -f coordinates.pckl
rm -f CFD_field_\(*  
rm -f dimensions_and_compression_*  
rm -f error_\(*  
rm -f Tensor_\(* 
rm -f ua*
rm -f ua_rec_cases_\(*  
rm -f w_field_\(*  
rm -f PDF_plot_\(*
rm -f memory_profiler_\(*
rm -f uncertainty_plot*
echo "Cleanup completed successfully!"

