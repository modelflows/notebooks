import numpy as np

def add_noise_to_tensor(tensor, noise_level):
    """
    Adds noise to each element of the tensor.
    
    Parameters:
    tensor (np.ndarray): The input tensor of any shape.
    noise_level (float): The percentage of noise to be added to each element.
    
    Returns:
    np.ndarray: The noisy tensor with the same shape as the input tensor.
    """
    # Calculate the noise to add to each element
    #noise = noise_level * tensor * np.random.randn(*tensor.shape)
    
    # Add noise to the original tensor
    #noisy_tensor = tensor + noise
    
    amplitude_typique = np.std(tensor)
    
    scale_percent = noise_level * amplitude_typique
    
    noisy_tensor = tensor + np.random.normal(scale=scale_percent, size=tensor.shape)
    
    return noisy_tensor

# # Example usage
# # Creating a random tensor of shape (2, 11, 30, 151)
# original_tensor = np.random.rand(2, 11, 30, 151)

# # Adding noise to the tensor
# noisy_tensor = add_noise_to_tensor(original_tensor, noise_level=0.05)

# print("Original tensor shape:", original_tensor.shape)
# print("Noisy tensor shape:", noisy_tensor.shape)
# print("Noisy tensor:\n", noisy_tensor)
