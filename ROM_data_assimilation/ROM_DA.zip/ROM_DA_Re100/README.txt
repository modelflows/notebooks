# ROM DA

This project demonstrates the use of ROM the Ensemble Kalman Filter (EnKF) method for data assimilation in the context of 2D Flow Past Cylinder system. The main program is `main_Flow_Over_Cylinder.py`, which utilizes various functions defined in other scripts to perform data assimilation, downsampling, data reconstruction, and analysis.

## Directory Structure

- `main_Flow_Over_Cylinder.py`: Main script to run the data assimilation process.
- `Reconstructor.py`: Contains the `superresolution` (here lcSVD) function for enhancing the resolution of under-resolved datasets.
- `MultiDimInterpolatorFunction.py`: Contains the `MDI` function for enhancing the resolution of under-resolved datasets.
- `UncertQuant.py`: Contains functions for uncertainty quantification and probability distribution plotting.
- `kalman.py`: Implements the Ensemble Kalman Filter (EnKF) in the `EnKF` function.
- `observation.py`: Defines observation functions `h` and `Dh`, used in kalman.py.
- `hosvd.py`: Contains functions for Higher Order Singular Value Decomposition (HOSVD), used in `Reconstructor.py`.
- `pointEvol.py`: Provides functions to plot the evolution of velocity at specific points.
- `Downsampler.py`: Provides the `downsample_function` to downsample high-resolution datasets.
- `add_noise.py`: Adds noise to tensors using the `add_noise_to_tensor` function.
- `h.py`: Defines the observation function `h` (debug).
- `import sys.py`: Prints the system path for debugging purposes.

## Usage

1. **Run the Main Script**:
   Execute the `main_Flow_Over_Cylinder.py` script to start the data assimilation process.
   ```
   python3 main_Flow_Over_Cylinder.py
   ```

2. **Dependencies**:
   Ensure you have the required Python packages installed:
   ```
   pip install numpy scipy matplotlib hdf5storage pysensors memory_profiler imageio pandas
   ```
   Ensure you have the required dataset (for example Tensor_cylinder_Re100.mat) in the same directory as `main_Flow_Over_Cylinder.py`.

## Example

To run the data assimilation, modify the main parameters in the `main_Flow_Over_Cylinder.py` script:
```
n_points = [(10,22), (20,40)]  # Example downsampling points for u_b
loop_DA = 1  # Number of loops for computational recources analysis 
noise_level = 0.05  # Noise level applied to u_b and w
n_points_W = (10,22)  # Downsampling points for experiments
N = 25  # EnKF ensemble size
```

## Output

The script will generate various outputs, including:
- Reconstructed data saved as `.npy` files.
- Plots of the original, reconstructed, and error data.
- Tracking velocity points.
- Excel files with dimensions, compression factors, and error metrics.

## Contact

More informations in https://modelflows.github.io/modelflowsapp/others/.
For any questions or issues, contact Paul Jeanney (paul.jeanney@arup.com).







