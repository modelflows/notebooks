#!/bin/bash

# Purge existing modules and load required ones
module purge
module load intel
module load Python/3.10.8-GCCcore-12.2.0
module load intelcuda

# Create a virtual environment
python -m venv venv

# Activate the virtual environment
source venv/bin/activate

# Install dependencies from requirements.txt
pip install -r requirements.txt

# Deactivate the virtual environment
deactivate

