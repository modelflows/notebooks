#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Mar 11 16:09:16 2024

@author: paul
"""

import numpy as np

def h(u):
    w = u 
    return w

def Dh(u):
    n = len(u)
    D = np.eye(n)
    return D