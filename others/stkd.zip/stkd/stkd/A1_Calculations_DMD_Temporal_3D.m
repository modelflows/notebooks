
%function  Calculations_DMD_Temporal_ND
  
 %clearvars -except Asnap_uv TensorMode TensorMatrix sv*
 clear all
 close all
 clc
 
load 'C:/Users/praji/Downloads/STKD_organizedFiles/STKD_organizedFiles/Tensor.mat'

%load ./../CANOPY_VERTICAL_MARCO/DeltaT.mat dt
%load ./../CANOPY_VERTICAL_MARCO/time.mat
 
 % load TensorALL.mat
 % Tensor=TensorALL;

% CHECK LINE 44

%load TensorPlane.mat
%Tensor=TensorPlane;

save_modes=1

%%%%%%%%%%%%%%%%%%%%%% SAVE RESULTS IN FOLDER DMD_solution %%%%%%%%%%%%%%%
mkdir('DMD_solution')
system('rm -r DMD_solution');
mkdir('DMD_solution')
filename = sprintf('./DMD_solution/DMD_history.txt' );
diary(filename)

%mkdir('DMD_solution_tensor')
%system('rm -r DMD_solution_tensor');
%mkdir('DMD_solution_tensor')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
format shorte

%%% Input parameters %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set the snapshot number
SNAP=99
%varepsilon1=1e-2
%varepsilon2=1e-2
%d=1
deltaT=1;
% Set the position of the temporal variable. The code is prepared to set
% the temporal evolution in the last component of the tensor, so this
% variable also determines the dimension of the tensor
TimePos=5
tic

%% Tensor dimension - number of snapshots:
Tensor0=Tensor;
numPoints = size(Tensor0, 5);
disp(numPoints)
startIndex = numPoints - SNAP + 1;
clear Tensor
if TimePos==5
    Tensor(:,:,:,:,:)=Tensor0(:,:,:,:,startIndex:numPoints);
elseif TimePos==4
    %indices = [4, 6, 8, 9, 14];
    %Tensor = cat(4, Tensor0(indices, :, :, startIndex:numPoints));
    Tensor(:,:,:,:)=Tensor0(:,:,:,startIndex:numPoints);

end
Time=[1:SNAP]*deltaT;
time=Time
%%% Component velocity, span, stream, normal, time
[L,Nz,Nx,Ny,nt]=size(Tensor)
%%%nt=300 % deltaT=0.1, tomamos 1 de cada 10 snapshots: deltaT=1

DTtimeRed=1

 for i=1:length(time)-1
    dtv(i)=time(i+1)-time(i);
end
dt=(max(dtv)+min(dtv))/2;
deltaT=dt
Tiempos=[0:length(time)-1]*deltaT;


 %% Set type of norm. L2=1 norm L2, else L2=0 norm Inf
 L2=1
 
 %% Set if you want to selec some modes for the reconstruction: If setM=1, ind=[mode1 mode2, ...]
 setM=0
 ind=[1,2,3]
 %% Set CC=1 if you want to obtain real data (mode + conj compl.)
 CC=1
 %%

 
 %% ITERATIVE
 
  %tolit=[1e-5 1e-4]
  tolit=[1e-4 1e-5 1e-7 1e-9]%1e-3 1e-4 1e-5 1e-6]
  if DTtimeRed<5
      ddit=[10 20 30 40]%20 30 35 40 50 60 65 70]
  else
      ddit=[5 8 10 12 15 18 ]
  end
 normit=[0 1]
 
 
 for jd=1:length(tolit)
     for id=1:length(ddit)
         for kd=1:length(normit)
             
             clear hat* DMD* Mode* ome* del* ampl*
             
             mkdir('DMD_solution')
             system('rm -r DMD_solution');
             mkdir('DMD_solution')
             filename = sprintf('./DMD_solution/DMD_history.txt' );
             diary(filename)
             
 
 d=ddit(id)
 
 varepsilon1=tolit(jd)
 varepsilon2=varepsilon1

 L2=normit(kd)
 
 %% END ITERATIVE
 
 
 %%
%  varepsilon1=1e-6 %1e-6
%  varepsilon2=1e-3%1e-3 %% 
%  d=20%
 

 


 tol_svd=varepsilon1

 TiemposClean=Tiempos;
 save ./DMD_solution/dataTiemposClean TiemposClean
 
% 
% load ./DMD_solution_tensor/dataTensorClean TensorClean
% load ./DMD_solution_tensor/dataTiemposClean TiemposClean
% 
%  Tensor=TensorClean;
%  Tiempos=TiemposClean;
%  
 
 

[L,I,J,K,Tm]=size(Tensor)
n=[L,I,J,K,Tm];

nn1=[L,0,0,0,0];


toc
Tensor1=Tensor;
for zz=1:1000
    zz
    if zz~=1
        clear TensorReconst S* U* deltas* omegas* hat* sv*        
        load ./DMD_solution/dataTensorReconst TensorReconst
        load ./DMD_solution/dataTiemposClean TiemposClean
        Tensor1=real(TensorReconst);
        Tiempos=TiemposClean;
        [L,I,J,K,Tm]=size(Tensor1)
        n=[L,I,J,K,Tm];
    end
    
[TT S U sv n] = hosvd(Tensor1, n);
n

h2=figure;
semilogy(1:I,sv{2},'o','linewidth',1,'color','k')
hold on
semilogy(1:J,sv{3},'+','linewidth',1,'color','r')
hold on
semilogy(1:K,sv{4},'o','linewidth',1,'color','b')
hold on
semilogy(1:Tm,sv{5},'o','linewidth',1,'color','b')
%Se elige la truncaci�n

name2 = sprintf('./DMD_solution/SV2' );
saveas(h2,name2,'fig')
close(h2)
 
% return

nn=[L,0,0,0,0];


for i=2:5
    count=0;
    for j=1:size(sv{i},1)
        if sv{i}(j)/sv{i}(1)>=tol_svd
            count=count+1;
        else
            break
        end
    end
    nn(i)=count;
end
    
    nn
    

    
    %if zz==1
%nn=[L,7,7,7]
    %end
[TT S U sv nn] = hosvd(Tensor1, nn);
%return
nn





for pp=1:5
UT{pp}=U{pp}';
end

%DMDreducido TEMPORAL EN T
for kk=1:nn(5)
    hatT(kk,:)=sv{5}(kk)*UT{5}(kk,:);
end

if d>1
    if L2==0
        if setM==1
            [deltas1,omegas1,hatmodos1,hatamplitudes1] =DMDdOptimReduced_M_select(d,hatT,Tiempos,varepsilon1,varepsilon2,setM,ind);
        else
            [deltas1,omegas1,hatmodos1,hatamplitudes1] =DMDdOptimReduced_max(d,hatT,Tiempos,varepsilon1,varepsilon2,zz);
        end
    elseif L2==1
        if setM==1
            [deltas1,omegas1,hatmodos1,hatamplitudes1] =DMDdOptimReduced_select(d,hatT,Tiempos,varepsilon1,varepsilon2,setM,ind);
        else
            [deltas1,omegas1,hatmodos1,hatamplitudes1] =DMDdOptimReduced(d,hatT,Tiempos,varepsilon1,varepsilon2);
        end
    end
else
    if L2==0
        if setM==1
            [deltas1,omegas1,hatmodos1,hatamplitudes1] =DMD1OptimReduced_M_select(hatT,Tiempos,varepsilon1,varepsilon2,setM,ind);
        else
            [deltas1,omegas1,hatmodos1,hatamplitudes1] =DMD1OptimReduced_max(hatT,Tiempos,varepsilon1,varepsilon2,zz);
        end
    elseif L2==1
        if setM==1
            [deltas1,omegas1,hatmodos1,hatamplitudes1] =DMD1OptimReduced_select(hatT,Tiempos,varepsilon1,varepsilon2,setM,ind);
        else
            [deltas1,omegas1,hatmodos1,hatamplitudes1] =DMD1OptimReduced(hatT,Tiempos,varepsilon1,varepsilon2);
        end
    end
end

[N,K]=size(hatT)

hatTReconst=zeros(N,K);


    
    
for k=1:K
  hatTReconst(:,k)= ContReconst(Tiempos(k),Tiempos(1),hatmodos1,Tiempos,deltas1,omegas1);
end
error1=norm(hatT-hatTReconst,2)/norm(hatT,2);
error1

%Reconstruccion TEMPORAL EN T
UNuevo=U;
for kk=1:nn(5)
UTNuevo{5}(kk,:)=hatTReconst(kk,:)/sv{5}(kk);
end
UNuevo{5}=UTNuevo{5}';

TensorReconst=tprod(S, UNuevo);
if setM==0 || CC==1
    TensorReconst=real(TensorReconst);
end
errorRMSTemporal=norm(Tensor(:)-TensorReconst(:),2)/norm(Tensor(:),2);
errorRMSTemporal

[~,MM]=size(hatmodos1);

DeltasOmegAmplTemporal=[(1:MM)',deltas1',omegas1',hatamplitudes1']
DeltasOmegAmplTemporal/2/pi

save ./DMD_solution/dataTensorReconst TensorReconst -v7.3
save ./DMD_solution/dataDeltasOmegasAmplTemporal DeltasOmegAmplTemporal


h=figure;
semilogy(omegas1/2/pi,abs(deltas1),'o','linewidth',2,'color','k');
name1 = sprintf('./DMD_solution/OmegasDeltas_d%03i',d );
saveas(h,name1,'fig')
close(h)

h2=figure;
semilogy(omegas1/2/pi,hatamplitudes1,'o','linewidth',2,'color','k');
name2 = sprintf('./DMD_solution/OmegasAmplitud_d%03i',d );
saveas(h2,name2,'fig')
close(h2)

    num=0
    for i=2:5
        if nn(i)==nn1(i)
         num=num+1;
        end
    end
    if num==4
        %save ./DMD_solution/dataS S -v7.3
        %save ./DMD_solution/datahatmodos1 hatmodos1 -v7.3
        %save ./DMD_solution/dataK K
        %save ./DMD_solution/dataU U -v7.3
        %save ./DMD_solution/datann nn
        %save ./DMD_solution/dataN N      
        save ./DMD_solution/dataTiempos Tiempos          
        %save ./DMD_solution/dataSV sv  
        break
    end

nn1=nn;
end
toc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if save_modes ==1
    
    % SAVE RESULTS IN FOLDER DMD_modes %
%     mkdir('DMD_modes')
%     system('rm -r DMD_modes');
%     mkdir('DMD_modes')

    
    % SAVE DMD MODES
    % SPATIAL MODES DMD: S*u
    
    
    hatTReconst_modes=zeros(N,K);
    hatmodos1_modes=zeros(N,length(hatamplitudes1));
    
    for ii=1:length(hatamplitudes1)
        hatmodos1_modes(:,ii)=hatmodos1(:,ii)/hatamplitudes1(ii);
    end
    
    Modes=U;
    for kk=1:nn(5)
        Modes_rem{5}(kk,:)=hatmodos1_modes(kk,:);
    end
    Modes{5}=Modes_rem{5}';
    DMDmode=tprod(S,Modes);
    
    save ./DMD_solution/DMDmode_tensor DMDmode  -v7.3
       
    
end

diary off

if L2==1
    %if varepsilon1==1e-4
        a=sprintf('DMD_solution_d%0.0i_tol%0.0e_L2_ALL',d,varepsilon1)
%     else
%         a=sprintf('DMD_solution_d%0.0i_L2_1m6',d)
%     end
else
    %if varepsilon1==1e-4
        a=sprintf('DMD_solution_d%0.0i_tol%0.0e_Inf_ALL',d,varepsilon1)
%     else
%         a=sprintf('DMD_solution_d%0.0i_Inf_1m6',d)
%     end
end

movefile('DMD_solution',a)


         end
     end
 end
toc
