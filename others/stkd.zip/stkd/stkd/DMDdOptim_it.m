
function  [Vreconst,deltas,omegas,amplitudes,kk3,modos] =DMDdOptim(d,V,Tiempos,varepsilon1,varepsilon)
                

%Efect�a un DMDd, con d>1, con la notaci�n del paper con Sole
%Entradas:
%V es la matriz de snapshots
%varepsilon1 es el threshold para truncar el primer SVD
%Tiempos es el vector con los tiempos de los snapshots
%Salidas:7
%Vreconst el la matriz de snapshots reconstruida
%deltas y omegas son vectores con los damping rates y las frecuencias
%u es la matriz cuyas columnas son los modos DMD



[J,K]=size(V);

[U,Sigma,T]=svd(V);
sigmas=diag(Sigma);
%sigmas
n=length(sigmas);
%nn=1:n;


aaaaa=norm(sigmas,2);
kk=0;
for k=1:n
    if norm(sigmas(k:n),2)/aaaaa>varepsilon1
        kk=kk+1;
    end
end

U=U(:,1:kk);

kk

hatT=Sigma(1:kk,1:kk)*T(:,1:kk)';

[N,~]=size(hatT);
% N
% K
% hh=d*N;
% hh1=K-d+1;
tildeT=zeros(d*N,K-d+1);
%size(tildeT)
for ppp=1:d
 tildeT((ppp-1)*N+1:ppp*N,:)=hatT(:,ppp:ppp+K-d);   
end
% size(tildeT)
% return
[U1,Sigma1,T1]=svd(tildeT,'econ');
sigmas1=diag(Sigma1);
%sigmas
Deltat=Tiempos(2)-Tiempos(1);
n=length(sigmas1);

aaaaa=norm(sigmas1,2);
kk1=0;
for k=1:n
    RRMSEE(k)=norm(sigmas1(k:n),2)/aaaaa;
        if RRMSEE(k)>varepsilon1
        kk1=kk1+1;
        end
end


kk1
%kk1=8
close(figure(2))
figure(2)
semilogy(1:kk1,sigmas1(1:kk1));


%close(figure(1))
%figure(1)
%semilogy(1:30,RRMSEE(1:30)/RRMSEE(1),'k','linewidth',3);


U1=U1(:,1:kk1);


hatT1=Sigma1(1:kk1,1:kk1)*T1(:,1:kk1)';
% K
% return
[~,K1]=size(hatT1);


[tildeU1,tildeSigma,tildeU2]=svd(hatT1(:,1:K1-1),'econ');

tildeR=hatT1(:,2:K1)*tildeU2*inv(tildeSigma)*tildeU1';
[tildeQ,tildeMM]=eig(tildeR);
autovalores=diag(tildeMM);

% M=length(autovalores);
% for m=1:M
%     cucu=log(autovalores(m));
%     deltas(m)=real(cucu)/Deltat;
%     omegas(m)=imag(cucu)/Deltat;
% end

M=length(autovalores);
cucu=log(autovalores);
deltas=real(cucu)/Deltat;
omegas=imag(cucu)/Deltat;
%omegas
Q=U1*tildeQ;
% size(Q)
% norm(Q(1:N,:)*tildeMM-Q(N+1:2*N,:),2)/norm(Q(1:N,:),2)
% norm(Q(1:N,:)*tildeMM^(d-1)-Q((d-1)*N+1:d*N,:),2)/norm(Q(1:N,:),2)
%return

Q=Q((d-1)*N+1:d*N,:);


%Q=Q(1:N,:);



 [NN,MMM]=size(Q);
 
 for m=1:MMM
    aaaaa=Q(:,m);
   Q(:,m)= Q(:,m)/norm(aaaaa(:),2);
 end
% size(hatT)
% size(tildeMM)
% M
%return

% meme=zeros(NN*K,M);
% bebe=zeros(NN*K,1);
% for k=1:K
%  meme(1+(k-1)*NN:k*NN,:)=Q*(tildeMM^(k-1)); 
%  bebe(1+(k-1)*NN:k*NN,1)=hatT(:,k);
% end

meme=zeros(NN*K,M);
bebe=zeros(NN*K,1);
aa=eye(MMM);
for k=1:K
 meme(1+(k-1)*NN:k*NN,:)=Q*aa; 
 aa=aa*tildeMM;
 bebe(1+(k-1)*NN:k*NN,1)=hatT(:,k);
end

[Ur,Sigmar,Vr]=svd(meme,'econ');
% diag(Sigmar)
% return
% size(Ur)
% size(Sigmar)
% size(Vr)
a=Vr*(Sigmar\(Ur'*bebe));
%return

u=zeros(NN,M);
for m=1:M
    u(:,m)=a(m)*Q(:,m);
end
amplitudes=zeros(M,1);
%modos=zeros(J,M);
for m=1:M
    aca=U*u(:,m);
    amplitudes(m)=norm(aca(:),2)/sqrt(J);    
end


UU=[u;deltas';omegas';amplitudes']';
UU1=sortrows(UU,-(NN+3));

UU=UU1';
u=UU(1:NN,:);
deltas=UU(NN+1,:);
omegas=UU(NN+2,:);
amplitudes=UU(NN+3,:);
kk3=0;
%norma=norm(amplitudes,2)/sqrt(M);
for m=1:M
    if amplitudes(m)/amplitudes(1)>varepsilon
        kk3=kk3+1;
    else
    end
end
amplitudes;
%return
kk3
u=u(:,1:kk3);
deltas=deltas(1:kk3);
omegas=omegas(1:kk3);
amplitudes=amplitudes(1:kk3);
DeltasOmegAmpl=[(1:kk3)',deltas',omegas',amplitudes']



hatTreconst=zeros(N,K);
for k=1:K
  hatTreconst(:,k)= ContReconst(Tiempos(k),Tiempos(1),u,Tiempos,deltas,omegas);
end
error1=norm(hatT-hatTreconst,2)/sqrt(N*K);
error1;
Vreconst=U*hatTreconst;

modos=zeros(J,kk3);
amplitudes0=zeros(kk3,1);
for m=1:kk3
    cuci=norm(U*u(:,m),2)/sqrt(J);
   amplitudes0(m)=cuci;
   modos(:,m)=U*u(:,m)/cuci;
end
%comprobaci�n de las amplitudes, que se acaban de recalcular. pepe tiene que dar cero 
pepe=norm(amplitudes(:,1:kk3)-amplitudes0',2)
%return
%u=U*u;

