clc
clear all
close all

% It is necessary to run: Plot_DMDmodes_freq_ampl.m
% The clusters of frequencies are selected manually and written in freq

freq=[0 0.353 0.625 0.978 1.33 1.67 1.94  2.01  2.29  2.91 2.99]

     
save Freq_Forward_Dt1_tol1m4_1m5_d30_40_50_60.mat freq

% MORE COMPLETE: 1e-4, 1e-5
freq=[0 0.353 0.625 0.978 1.33 1.67 1.94  2.01  2.29  2.91 2.99 ]

save Freq_Forward_Dt1_tol1m4_1m5_d30_40_50_60_ALLMed.mat freq
% 
% freq=[0.24, 1.2, 1.6, 1.88, 2.1, 2.38, 2.64, 2.9, 3.0, 3.32, 3.535,  4.17,...
%     4.45, 4.98, 5.29, 5.62, 6.44, 7.1, 8.35, 9.27, 9.59, 11.37]
% 
% save Freq_Forward_Dt1_tol1m4_1m5_d30_40_50_60_ALL.mat freq
    
%% SHORT VERSION

%    1.0000e+00            0
%    3.0000e+00   2.6000e-01
%    5.0000e+00   9.5000e-01
%    7.0000e+00   1.1800e+00
%    9.0000e+00   1.4400e+00
%    1.1000e+01   1.6100e+00
%    1.3000e+01   1.8500e+00
%    1.5000e+01   4.9600e+00
%    1.7000e+01   5.5000e+00


%% LONG VERSION

%    1.0000e+00            0
%    3.0000e+00   2.6000e-01
%    5.0000e+00   9.5000e-01
%    7.0000e+00   1.1800e+00
%    9.0000e+00   1.4400e+00
%    1.1000e+01   1.6300e+00
%    1.3000e+01   1.8500e+00
%    1.5000e+01   2.1000e+00
%    1.7000e+01   2.3000e+00
%    1.9000e+01   2.5000e+00
%    2.1000e+01   3.1600e+00
%    2.3000e+01   3.4000e+00
%    2.5000e+01   4.9600e+00
%    2.7000e+01   5.5000e+00