
function  [Vreconst,deltas,omegas,amplitudes] =...
    DMDdOptim(d,V,Tiempos,varepsilon1,varepsilon,save_modes)
                

%Efect�a un DMDd, con d>1, con la notaci�n del paper con Sole
%Entradas:
%V es la matriz de snapshots
%varepsilon1 es el threshold para truncar el primer SVD
%Tiempos es el vector con los tiempos de los snapshots
%Salidas:7
%Vreconst el la matriz de snapshots reconstruida
%deltas y omegas son vectores con los damping rates y las frecuencias
%u es la matriz cuyas columnas son los modos DMD



[J,K]=size(V);

%[U,Sigma,T]=svd(V); % ORIGIAL SIAM %%%%% AQUI !!!!!
[U,Sigma,T]=svd(V,'econ');
sigmas=diag(Sigma);
%sigmas
n=length(sigmas);
%nn=1:n;


aaaaa=norm(sigmas,2);
kk=0;
for k=1:n
    if norm(sigmas(k:n),2)/aaaaa>varepsilon1
        kk=kk+1;
    end
end

U=U(:,1:kk);

kk

hatT=Sigma(1:kk,1:kk)*T(:,1:kk)';

[N,~]=size(hatT);

tildeT=zeros(d*N,K-d+1);

for ppp=1:d
 tildeT((ppp-1)*N+1:ppp*N,:)=hatT(:,ppp:ppp+K-d);   
end

%[U1,Sigma1,T1]=svd(tildeT); % ORIGIAL SIAM %%%%% AQUI !!!!!
[U1,Sigma1,T1]=svd(tildeT,'econ');
sigmas1=diag(Sigma1);

Deltat=Tiempos(2)-Tiempos(1);
n=length(sigmas1);


kk1=0;
for k=1:n    
    if sigmas1(k)/sigmas1(1)>varepsilon1
        kk1=kk1+1;
    end
end
kk1

close(figure(2))
figure(2)
semilogy(1:kk1,sigmas1(1:kk1));

close(figure(3))
figure(3)
semilogy(1:n,sigmas1);


U1=U1(:,1:kk1);


hatT1=Sigma1(1:kk1,1:kk1)*T1(:,1:kk1)';
% K
% return
[~,K1]=size(hatT1);


[tildeU1,tildeSigma,tildeU2]=svd(hatT1(:,1:K1-1),'econ');

tildeR=hatT1(:,2:K1)*tildeU2*inv(tildeSigma)*tildeU1';
[tildeQ,tildeMM]=eig(tildeR);
autovalores=diag(tildeMM);



M=length(autovalores);
cucu=log(autovalores);
deltas=real(cucu)/Deltat;
omegas=imag(cucu)/Deltat;

Q=U1*tildeQ;
Q=Q((d-1)*N+1:d*N,:);





 [NN,MMM]=size(Q);
 
 for m=1:MMM
    aaaaa=Q(:,m);
   Q(:,m)= Q(:,m)/norm(aaaaa(:),2);
 end


meme=zeros(NN*K,M);
bebe=zeros(NN*K,1);
aa=eye(MMM);
for k=1:K
 meme(1+(k-1)*NN:k*NN,:)=Q*aa; 
 aa=aa*tildeMM;
 bebe(1+(k-1)*NN:k*NN,1)=hatT(:,k);
end

[Ur,Sigmar,Vr]=svd(meme,'econ');

a=Vr*(Sigmar\(Ur'*bebe));


u=zeros(NN,M);
for m=1:M
    u(:,m)=a(m)*Q(:,m);
end
amplitudes=zeros(M,1);
for m=1:M
    aca=U*u(:,m);
    amplitudes(m)=norm(aca(:),2)/sqrt(J);    
    %amplitudes(m)=norm(u(:,m),'inf');
end

UU=[u;deltas';omegas';amplitudes']';
UU1=sortrows(UU,-(NN+3));

UU=UU1';
u=UU(1:NN,:);
deltas=UU(NN+1,:);
omegas=UU(NN+2,:);
amplitudes=UU(NN+3,:);
kk3=0;
%norma=norm(amplitudes,2)/sqrt(M);
for m=1:M
    if amplitudes(m)/amplitudes(1)>varepsilon
        kk3=kk3+1;
    else
    end
end
amplitudes;

kk3
u=u(:,1:kk3);
deltas=deltas(1:kk3);
omegas=omegas(1:kk3);
amplitudes=amplitudes(1:kk3);
DeltasOmegAmpl=[(1:kk3)',deltas',omegas',amplitudes']; %%% DESCOMENTAR PARA VER POR PANTALLA: SLC



%%%% RECONSTRUCTION OF THE ORIGINAL DATA %%%%%%%%%%

hatTreconst=zeros(N,K);
for k=1:K
  hatTreconst(:,k)= ContReconst(Tiempos(k),Tiempos(1),u,Tiempos,deltas,omegas);
end
error1=norm(hatT-hatTreconst,2)/sqrt(N*K);
error1;
Vreconst=U*hatTreconst;
%u=U*u;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if save_modes ==1
    %% SAVE DMD MODES
    %SPATIAL MODES DMD: U*v
    clear data
    data=zeros(size(U(:,1),1),1);
    data1=zeros(N,1);
    
    DMDmode=zeros(J,kk3);
    amplitudes0=zeros(kk3,1);
    for m=1:kk3
        cuci=norm(U*u(:,m),2)/sqrt(J);
        amplitudes0(m)=cuci;
        DMDmode(:,m)=U*u(:,m)/cuci; %%% DMD MODE
        
%       % POD MODES using DMD-d        
%         hatTpod=hatTreconst';
%         DMDmode(:,m)=V*hatTpod(:,m); %POD MODE
    end
    
    % Test new amplitudes --> pepe has to be zero
    pepe=norm(amplitudes(:,1:kk3)-amplitudes0',2)
    
save ./DMD_solution/DMDmode.mat DMDmode
    
    
    for rr=1:kk3
        filename = sprintf('./DMD_solution/DMDd_mode_RE_n%02i.txt',rr );
        data(:)=real(DMDmode(:,rr));
        save(filename,'data','-ascii')
        

    end
    
    for rr=1:kk3
        filename = sprintf('./DMD_solution/DMDd_mode_IM_n%02i.txt',rr );
        data(:)=imag(DMDmode(:,rr));
        save(filename,'data','-ascii')
        

    end
    
    
    
    for rr=1:kk3
        filename = sprintf('./DMD_solution/DMDd_mode_ABS_n%02i.txt',rr );
        data(:)=abs(DMDmode(:,rr));
        save(filename,'data','-ascii')
        
        
    end
    
    
    
    
    
end


