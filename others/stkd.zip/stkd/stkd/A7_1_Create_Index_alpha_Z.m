clc
clear all
close all

load Freq_Forward_Dt1_tol1m4_1m5_d30_40_50_60.mat
freq=freq';

%% IN CHANNEL FLOWS WE CAN START WITH ALPHA=0 AND HARMONICS, BUT IN CANOPY IT IS NECESSARY TO DEFINE ALPHA IN THE FILE A7_1_0_*
%alpha=0
%alpha_FILE_A7_1_0_*=[1.3 2.7 4 5.3 6.6 9.3 10.5]

%CANOPY NOT ABS or not NF --> alpha=0 does not exist in all frequencies
alpha=6

% YOU CAN INCREASE THE TOLERANCE IN SOME CASES (ej. 0.2,0.3), WHEN THE CODE DOES NOT FIND ANY FREQ.
% IN CANOPY: at least 0.3 in all except in alpha=0
tol=0.1

% IN CANOPY WE REMOVE THE MODE WITH 0 for alpha/=0
if alpha ~= 0
    freq=freq(2:end);
else 
    tol=0.1
end

load IndexOK_test_temporal_compare_Forward_Dt1_tol1m4_d50.mat
IND2=Index2;

% Set 1 every 2 modes for the loop
IND=IND2(1:2:end);




count=1
for i=1:length(freq)
    a=sprintf('DMD_solutionZ_d1_L2_%2.2i/dataDeltasOmegasAmplTemporal.mat',freq(i))
    m=load(a);
    II=find(abs(m.DeltasOmegAmplTemporal(:,3))<alpha+tol & abs(m.DeltasOmegAmplTemporal(:,3))>alpha-tol);
    %     if i==6 & alpha==3
    %         II=II(2:3);
    %     end
    if alpha==0 & length(II)>1
        II=II(1);
    elseif alpha==10.5 & length(II)>1
        II=II(1:2);
    end
    %
    if alpha==0
        Index(count)=II;
        count=count+1;
    else
        Index(count:count+1)=II;
        count=count+2;
    end
end


    
 
if alpha==0
    b=sprintf('Index_ModesZ_beta.mat',alpha)
else
    b=sprintf('Index_ModesZ_beta%2.2i.mat',alpha)
end
save(b,'Index')
           
                          