%% Plot vorticity
close all
%% plane XZ (vort in y)

%load DMD_solution/DMDmode_tensor.mat
load ./../DATA_elastoviscoplastic_Bi0/XZslices/X_10pxz.mat
load ./../DATA_elastoviscoplastic_Bi0/XZslices/Z_10pxz.mat

modN=3

%m_abs1=max(max(abs(DMDmode(1,:,:,modN))));
%m_re1=max(max(abs(real(DMDmode(1,:,:,modN)))));
%m_im1=max(max(abs(imag(DMDmode(1,:,:,modN)))));
m_abs2=max(max(abs(DMDmode(2,:,:,modN))));
m_re2=max(max(abs(real(DMDmode(2,:,:,modN)))));
m_im2=max(max(abs(imag(DMDmode(2,:,:,modN)))));
%m_abs3=max(max(abs(DMDmode(3,:,:,modN))));
%m_re3=max(max(abs(real(DMDmode(3,:,:,modN)))));
%m_im3=max(max(abs(imag(DMDmode(3,:,:,modN)))));


vort_abs=curl(X,Z,squeeze(abs(DMDmode(1,:,:,modN))),squeeze(abs(DMDmode(2,:,:,modN))));
vort_re=curl(X,Z,squeeze(real(DMDmode(1,:,:,modN))),squeeze(real(DMDmode(2,:,:,modN))));
vort_im=curl(X,Z,squeeze(imag(DMDmode(1,:,:,modN))),squeeze(imag(DMDmode(2,:,:,modN))));


figure(1)
contourf(X,Z,vort_abs/max(max(vort_abs)),'LevelStep',0.1)
caxis([-1 1])
colorbar()
title('Vorticity- Z ABS')

figure(2)
contourf(X,Z,vort_re/max(max(vort_re)),'LevelStep',0.1)
caxis([-1 1])
colorbar()
title('Vorticity- Z Re')

figure(3)
contourf(X,Z,vort_im/max(max(vort_im)),'LevelStep',0.1)
caxis([-1 1])
colorbar()
title('Vorticity- Z Im')

figure(4)
contourf(X,Z,squeeze(abs(DMDmode(2,:,:,modN)))/m_abs2)
caxis([-1 1])
colorbar()
title('DMD mode V ABS')

figure(5)
contourf(X,Z,squeeze(real(DMDmode(2,:,:,modN)))/m_re2)
caxis([-1 1])
colorbar()
title('DMD mode V Re')

figure(6)
contourf(X,Z,squeeze(imag(DMDmode(2,:,:,modN)))/m_im2)
caxis([-1 1])
colorbar()
title('DMD mode V Im')