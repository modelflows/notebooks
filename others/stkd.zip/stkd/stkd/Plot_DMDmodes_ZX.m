
clc
clear all
close all

% load DMD_solution_d15_tol1e-05_L2_ALL/dataDeltasOmegasAmplTemporal.mat
load DMD_solutionZ_d1_L2_4.70e-01/dataTensorReconst.mat
 
 freq=[0.017 0.036 0.075 0.085 0.11 0.15 0.34 0.39 0.45 ...
     0.25 0.22 0.47 0.43 0.37 0.31]
 IND=[2 4 10 14 30 34 8 12 32 44 40 20 42 26 6]
 
[L nx ny nz nt]=size(TensorReconst)
%%
deltaX=4*pi/(nx-1)
xx=[0:1:nx-1]*deltaX

deltaY=2/(ny-1)
yy=[0:ny-1]*deltaY

deltaZ=2*pi/(nz-1)
zz=[0:nz-1]*deltaZ

[X Y]=meshgrid(xx,yy);
[XX ZZ]=meshgrid(xx,zz);
[YY Z]=meshgrid(yy,zz);



beta=[2 3 6]
alpha=[0 0.5 5.5]

for k=1:length(alpha)
    for j=1:length(beta)
        for i=1:length(freq)
            i
            freq=[0.017 0.036 0.075 0.085 0.11 0.15 0.34 0.39 0.45 ...
                0.25 0.22 0.47 0.43 0.37 0.31]
            
            a=sprintf('DMD_solutionZX_d1_L2_%2.2i_B%1.1i_L%1.1i/dataTensorReconst.mat',freq(i),beta(j), alpha(k))
            m=load(a);
            
            h2=figure;
            axes1 = axes('Parent',h2);
            hold(axes1,'on');
            box on
            contourf(XX,ZZ,squeeze(abs(m.TensorReconst(1,1:1:end,8,:)))')
            name2 = sprintf('./DMDmodes_planes_ZX/XZ_%2.2i_B%1.1i_L%1.1i_vx_L38',freq(i),beta(j),alpha(k));
            %saveas(h2,name2,'fig')
            xlabel('X')
            ylabel('Z')
            set(axes1,'FontSize',18);
            set(gcf, 'Position', [100, 100, 700, 350])
            saveas(h2,name2,'jpg')
            pause(0.2)
            close(h2)
            
            h2=figure;
            axes1 = axes('Parent',h2);
            hold(axes1,'on');
            box on
            contourf(XX,ZZ,squeeze(abs(m.TensorReconst(1,1:1:end,9,:)))')
            name2 = sprintf('./DMDmodes_planes_ZX/XZ_%2.2i_B%1.1i_L%1.1i_vx_L39',freq(i),beta(j),alpha(k));
            %saveas(h2,name2,'fig')
            xlabel('X')
            ylabel('Z')
            set(axes1,'FontSize',18);
            set(gcf, 'Position', [100, 100, 700, 350])
            saveas(h2,name2,'jpg')
            %pause
            close(h2)
            
            %
            h2=figure;
            axes1 = axes('Parent',h2);
            hold(axes1,'on');
            box on
            contourf(X,Y,squeeze(abs(m.TensorReconst(1,1:1:end,:,45)))')
            name2 = sprintf('./DMDmodes_planes_ZX/XY_%2.2i_B%1.1i_L%1.1i_vx',freq(i),beta(j),alpha(k));
            % saveas(h2,name2,'fig')
            xlabel('X')
            ylabel('Y')
            set(axes1,'FontSize',18);
            set(gcf, 'Position', [100, 100, 700, 350])
            saveas(h2,name2,'jpg')
            %pause
            close(h2)
            
            h2=figure;
            axes1 = axes('Parent',h2);
            hold(axes1,'on');
            box on
            contourf(XX,ZZ,squeeze(abs(m.TensorReconst(1,1:1:end,18,:)))')
            name2 = sprintf('./DMDmodes_planes_ZX/XZbottom_%2.2i_B%1.1i_L%1.1i_vx',freq(i),beta(j),alpha(k));
            %saveas(h2,name2,'fig')
            xlabel('X')
            ylabel('Z')
            set(axes1,'FontSize',18);
            set(gcf, 'Position', [100, 100, 700, 350])
            saveas(h2,name2,'jpg')
            close(h2)
            
            h2=figure;
            axes1 = axes('Parent',h2);
            hold(axes1,'on');
            box on
            contourf(XX,ZZ,squeeze(abs(m.TensorReconst(1,1:1:end,73,:)))')
            name2 = sprintf('./DMDmodes_planes_ZX/XZtop_%2.2i_B%1.1i_L%1.1i_vx',freq(i),beta(j),alpha(k));
            %saveas(h2,name2,'fig')
            xlabel('X')
            ylabel('Z')
            set(axes1,'FontSize',18);
            set(gcf, 'Position', [100, 100, 700, 350])
            saveas(h2,name2,'jpg')
            close(h2)
            
            %
            
            h2=figure;
            axes1 = axes('Parent',h2);
            hold(axes1,'on');
            box on
            contourf(X,Y,squeeze(abs(m.TensorReconst(2,1:1:end,:,45)))')
            name2 = sprintf('./DMDmodes_planes_ZX/XY_%2.2i_B%1.1i_L%1.1i_vy',freq(i),beta(j),alpha(k));
            %saveas(h2,name2,'fig')
            xlabel('X')
            ylabel('Y')
            set(axes1,'FontSize',18);
            set(gcf, 'Position', [100, 100, 700, 350])
            saveas(h2,name2,'jpg')
            close(h2)
            
            h2=figure;
            axes1 = axes('Parent',h2);
            hold(axes1,'on');
            box on
            contourf(XX,ZZ,squeeze(abs(m.TensorReconst(2,1:1:end,18,:)))')
            name2 = sprintf('./DMDmodes_planes_ZX/XZbottom_%2.2i_B%1.1i_L%1.1i_vy',freq(i),beta(j),alpha(k));
            %saveas(h2,name2,'fig')
            xlabel('X')
            ylabel('Z')
            set(axes1,'FontSize',18);
            set(gcf, 'Position', [100, 100, 700, 350])
            saveas(h2,name2,'jpg')
            close(h2)
            
            h2=figure;
            axes1 = axes('Parent',h2);
            hold(axes1,'on');
            box on
            contourf(XX,ZZ,squeeze(abs(m.TensorReconst(2,1:1:end,73,:)))')
            name2 = sprintf('./DMDmodes_planes_ZX/XZtop_%2.2i_B%1.1i_L%1.1i_vy',freq(i),beta(j),alpha(k));
            %saveas(h2,name2,'fig')
            xlabel('X')
            ylabel('Z')
            set(axes1,'FontSize',18);
            set(gcf, 'Position', [100, 100, 700, 350])
            saveas(h2,name2,'jpg')
            close(h2)
            %pause
            
            
        end
    end
end
