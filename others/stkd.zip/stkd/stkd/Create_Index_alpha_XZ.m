clc
clear all
close all



freq=[0.017 0.036 0.075 0.085 0.11 0.15 0.34 0.39 0.45 ...
    0.25 0.22 0.47 0.43 0.37 0.31]
IND=[2 4 10 14 30 34 8 12 32 44 40 20 42 26 6]

tol=0.3%0.01
alpha=1%0%2%

count=1
for i=1:length(freq)
    %a=sprintf('DMD_solutionXZ_d1_L2_%2.2i/dataDeltasOmegasAmplTemporal.mat',freq(i))
    a=sprintf('DMD_solutionXZ_d1_L2_%2.2i_1/dataDeltasOmegasAmplTemporal.mat',freq(i))
    m=load(a);
    II=find(abs(m.DeltasOmegAmplTemporal(:,3))<alpha+tol & abs(m.DeltasOmegAmplTemporal(:,3))>alpha-tol);
    
    if alpha==0
        Index(count)=II;
        count=count+1;
    else
        Index(count:count+1)=II;
        count=count+2;
    end
end

b=sprintf('Index_ModesXZ_alpha%0.0i.mat',alpha)
save(b,'Index')
           
                          