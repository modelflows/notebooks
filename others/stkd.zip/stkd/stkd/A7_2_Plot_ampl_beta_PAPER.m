clear all
close all


load Freq_Forward_Dt1_tol1m4_1m5_d30_40_50_60.mat
freq=freq';


load IndexOK_test_temporal_compare_Forward_Dt1_tol1m4_d50.mat
IND=Index2;


figure1 = figure;

% Create axes
axes1 = axes('Parent',figure1);
hold(axes1,'on');
box on
set(axes1,'FontSize',18,'YMinorTick','on','YScale','log');
for i=1:length(freq)
a=sprintf('DMD_solutionZ_d1_L2_%2.2i/dataDeltasOmegasAmplTemporal.mat',freq(i))
m=load(a);

d=[m.DeltasOmegAmplTemporal(:,3) m.DeltasOmegAmplTemporal(:,4)];
f=sortrows(d,1);
plot(f(:,1),f(:,2),'*')
%plot(m.DeltasOmegAmplTemporal(:,3),m.DeltasOmegAmplTemporal(:,4),'*-')
xlim([0 25])
end


xlabel('\beta_{mn}')
ylabel('a_{mn}')
xlim([1 10])
legend('\omega=0','\omega=0.353','\omega=0.625','\omega=0.978','\omega=1.33','\omega=1.67','\omega=1.94','\omega=2.01','\omega=2.29','\omega=2.91','Orientation','horizontal')
set(axes1,'FontSize',18,'YMinorTick','on','YScale','log');
set(gcf, 'Position', [100, 100, 1000, 300])
