clc
clear all
close all


load DMD_solution_d40_tol1e-07_L2_ALL/dataDeltasOmegasAmplTemporal.mat
AA=DeltasOmegAmplTemporal;
load DMD_solution_d40_tol1e-07_L2_ALL/dataDeltasOmegasAmplTemporal.mat
BB=DeltasOmegAmplTemporal;

% FREQ foward
load Freq_Forward_Dt1_tol1m4_1m5_d30_40_50_60.mat
freq=freq';

tol=0.05
count=1
for i=1:length(freq)
    
    if i>20
         tol=0.08
%     elseif i>10
%          tol=0.1
     end

    IND1=find(abs(AA(:,3))<freq(i)+tol & abs(AA(:,3))>freq(i)-tol);
    if length(IND1)>2
        IND1=IND1(1:2);
    end
    Index1(count:count+1)=IND1;

    if i>20
         tol=0.08
%     elseif i>10
%          tol=0.1
    end
     
    IND2=find(abs(BB(:,3))<freq(i)+tol & abs(BB(:,3))>freq(i)-tol);
    if length(IND2)>2
        IND2=IND2(1:2);
    end
    Index2(count:count+1)=IND2;
    
    count=count+2;    
    
end

save IndexOK_test_temporal_Forward_Dt1_tol1m4_d40.mat Index1
save IndexOK_test_temporal_compare_Forward_Dt1_tol1m4_d50.mat Index2



