clear all
clc

% set up calibrations
ddit   = [10 20 30 40]
tolit  = [1e-4 1e-5 1e-7 1e-9]
normit = [0, 1]

MAC = 0.9 % tunable tolerance over cos(DMD1,DMD2), set 0.8 <= MAC < 1

%%

% load frequency vector of suspected robust DMD modes (go to A3)
mm = load('./Freq_Forward_Dt1_tol1m4_1m5_d30_40_50_60.mat');
mm = mm.freq;
freq = mm'

%%
% compare [dr, varepsilonr, normr] calibration with the others

tol = 0.05 % tunable tolerance over frequencies, set tol <= 0.08

% initialize data matrices
freqrec = ones(length(freq),length(ddit)*length(tolit)*length(normit)+1,length(ddit)*length(tolit)*length(normit));
robrec  = ones(length(freq),length(ddit)*length(tolit)*length(normit)+1,length(ddit)*length(tolit)*length(normit));
macrec  = ones(length(freq),length(ddit)*length(tolit)*length(normit)+1,length(ddit)*length(tolit)*length(normit));

calibr = 0;
for dr = ddit
    
    for varepsilonr = tolit
        
        for normr = normit
            
            calibr = calibr + 1              
            freqrec(:,1,calibr) = freq;
            robrec(:,1,calibr)  = freq;
            macrec(:,1,calibr)  = freq;
            
            dr
            varepsilonr
            normr

            if normr == 1
                a = sprintf('./DMD_solution_d%0.0i_tol%0.0e_L2_ALL/dataDeltasOmegasAmplTemporal.mat',dr,varepsilonr);
                aa = sprintf('./DMD_solution_d%0.0i_tol%0.0e_L2_ALL/DMDmode_tensor.mat',dr,varepsilonr);   
            elseif normr == 0
                a = sprintf('./DMD_solution_d%0.0i_tol%0.0e_Inf_ALL/dataDeltasOmegasAmplTemporal.mat',dr,varepsilonr);
                aa = sprintf('./DMD_solution_d%0.0i_tol%0.0e_Inf_ALL/DMDmode_tensor.mat',dr,varepsilonr);
            end
            
            mm = load(a);
            mm = mm.DeltasOmegAmplTemporal;
            freqr = mm(:,3);

            nn = load(aa);
            DMDmoder = nn.DMDmode;
    
            calibit = 0;
            for i = 1:length(tolit)
    
                for j = 1:length(ddit)
        
                    for k = 1:length(normit)
            
                        calibit = calibit + 1
            
                        varepsilon = tolit(i);
                        d = ddit(j);
                        L2 = normit(k);
                        if d == dr && varepsilon == varepsilonr && L2 == normr
                            % if calib-th is the same as 'r', skips the iteration
                            continue 
                        end            
             
                         if L2 == 1 
                            b = sprintf('./DMD_solution_d%0.0i_tol%0.0e_L2_ALL/dataDeltasOmegasAmplTemporal.mat',d,varepsilon);
                            bb = sprintf('./DMD_solution_d%0.0i_tol%0.0e_L2_ALL/DMDmode_tensor.mat',d,varepsilon);
                        elseif L2 == 0 
                            b = sprintf('./DMD_solution_d%0.0i_tol%0.0e_Inf_ALL/dataDeltasOmegasAmplTemporal.mat',d,varepsilon);
                            bb = sprintf('./DMD_solution_d%0.0i_tol%0.0e_Inf_ALL/DMDmode_tensor.mat',d,varepsilon);
                         end
             
                        pp = load(b);
                        pp = pp.DeltasOmegAmplTemporal;
                        freqit = pp(:,3);
             
                        qq = load(bb);
                        DMDmodeit = qq.DMDmode;
             
                        for ii = 1:length(freq)
                                                
                            INDr = find(abs(freqr)<freq(ii)+tol & abs(freqr)>freq(ii)-tol);
                            if length(INDr) > 2
                                INDr=INDr(1:2);
                            end
                 
                            INDit = find(abs(freqit)<freq(ii)+tol & abs(freqit)>freq(ii)-tol);
                            if length(INDit) > 2
                                INDit = INDit(1:2);
                            end
                 
                            if isempty(INDr) || isempty(INDit)                                      
                     
                                freqrec(ii,calibit+1,calibr) = 0; 
                                robrec(ii,calibit+1,calibr) = NaN; 
                                macrec(ii,calibit+1,calibr) = NaN;
                     
                                continue % if the mode is not common, it's not considered for robust analysis
                            end
                 
                            % check robustness in common modes
                            DMDr = DMDmoder(:,INDr(1));
                            DMDit = DMDmodeit(:,INDit(1));
                 
                            cc = abs(dot(DMDr(:),DMDit(:))/(norm(DMDr(:))*norm(DMDit(:))));
                            macrec(ii,calibit+1,calibr) = cc;
                     
                            if cc >= MAC 
                                robrec(ii,calibit+1,calibr) = 1;
                            else 
                                robrec(ii,calibit+1,calibr) = 0;
                            end                              
                 
                        end
             
                    end
        
                end
    
            end

        end

    end

end


%% 

% compares robustness of modes

tolfreq = 1 % tunable tolerance; mode is considered 'common' if frequency is present in at least (100 * tolfreq)% of calibrations
tolmac = 0.75 % tunable tolerance; mode is considered 'robust' if it fulfills MAC condition in at least (100 * tolmac)% of calibrations

ROB = zeros(2,length(freq),length(ddit)*length(tolit)*length(normit)+1);
ROB(1,:,1) = freq; ROB(2,:,1) = freq;
for i = 1:length(ddit)*length(tolit)*length(normit)
    
    for j = 1:length(freq)
    
        temp1 = freqrec(j,2:end,i);
        countfreq = temp1(temp1==1);
        if length(countfreq)/(length(ddit)*length(tolit)*length(normit)) >= tolfreq
            ROB(1,j,i+1) = 1;
            temp2 = robrec(j,2:end,i);
            countrob = temp2(temp2==1);
            if length(countrob)/(length(ddit)*length(tolit)*length(normit)) >= tolmac
                ROB(2,j,i+1) = 1;
            end
        else
            ROB(1,j,i+1) = 0;
            ROB(2,j,i+1) = 0;
        end
        
    end
    
end

figure()
bw = [0 0 0
      1 1 1];
colormap(bw)
imagesc(squeeze(ROB(1,:,2:end)))
set(gca,'FontSize',10)
set(gca, 'XTick', 1:size(ROB,3)-1) 
xlabel('Calibration','FontSize',10)
set(gca, 'YTick', 1:length(freq)) 
set(gca, 'YTickLabel', round(freq,2))
ylabel('Frequency','FontSize',10)
title('Common analysis for temporal DMD modes')
colorbar
colorbar('Ticks',[0,1],'TickLabels',{'No common','Common'}, 'FontSize',10)

figure()
bw = [0 0 0
      1 1 1];
colormap(bw)
imagesc(squeeze(ROB(2,:,2:end)))
set(gca,'FontSize',10)
set(gca, 'XTick', 1:size(ROB,3)-1) 
xlabel('Calibration','FontSize',10)
set(gca, 'YTick', 1:length(freq)) 
set(gca, 'YTickLabel', round(freq,2))
ylabel('Frequency','FontSize',10)
title('Robust analysis for temporal DMD modes')
colorbar
colorbar('Ticks',[0,1],'TickLabels',{'No robust','Robust'}, 'FontSize',10)

