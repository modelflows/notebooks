

%%

load ./../DATA_elastoviscoplastic_Bi1_4b/XZslices/Tensor_10pXZ.mat

[L,M,N,K]=size(Tensor)

L=3 %ONLY VELOCITY FIELD

Matrix=zeros(L*M*N,K);

for k=1:K
    count=0;
    for l=1:L
        for m=1:M
            for n=1:N
                count=count+1;
                Matrix(count,k)=Tensor(l,m,n,k);
            end
        end
    end
end 

save ./../DATA_elastoviscoplastic_Bi1_4b/XZslices/Matrix_10pXZ.mat Matrix
          
        