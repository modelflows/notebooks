clc
clear all
close all

  tolit=[1e-5 1e-4]
  %tolit=[ 1e-3 1e-4 1e-5 1e-6]
 %ddit=[10 12 15 18 20]% 25 30 35 40 ]
 ddit=[12 15 18 20]
 normit=[0 1]
 
 figure1 = figure;
axes1 = axes('Parent',figure1);
hold(axes1,'on');
box on
 set(axes1,'YMinorTick','on','YScale','log');
 xlim([-0.01 0.7])
 for i=1:length(tolit)
     if i==3
         aaa=4
     else
         aaa=1
     end
     for j=aaa:length(ddit)
         for k=1:length(normit)
             L2=normit(k)
             d=ddit(j)
             varepsilon1=tolit(i)
             
             if L2==1
                 a=sprintf('DMD_solution_d%0.0i_tol%0.0e_L2_ALL/dataDeltasOmegasAmplTemporal.mat',d,varepsilon1)
                 m=load(a);
                 if i==1
                      plot(m.DeltasOmegAmplTemporal(:,3),m.DeltasOmegAmplTemporal(:,4)/(max(m.DeltasOmegAmplTemporal(:,4))),'s')
                 elseif i==2
                     plot(m.DeltasOmegAmplTemporal(:,3),m.DeltasOmegAmplTemporal(:,4)/(max(m.DeltasOmegAmplTemporal(:,4))),'^')
                  else
                     plot(m.DeltasOmegAmplTemporal(:,3),m.DeltasOmegAmplTemporal(:,4)/(max(m.DeltasOmegAmplTemporal(:,4))),'o')
                  end
             else
                 a=sprintf('DMD_solution_d%0.0i_tol%0.0e_Inf_ALL/dataDeltasOmegasAmplTemporal.mat',d,varepsilon1)
                 m=load(a);
                 if i==1
                     plot(m.DeltasOmegAmplTemporal(:,3),m.DeltasOmegAmplTemporal(:,4)/(max(m.DeltasOmegAmplTemporal(:,4))),'x')
                 elseif i==2
                      plot(m.DeltasOmegAmplTemporal(:,3),m.DeltasOmegAmplTemporal(:,4)/(max(m.DeltasOmegAmplTemporal(:,4))),'+')
                 else
                     plot(m.DeltasOmegAmplTemporal(:,3),m.DeltasOmegAmplTemporal(:,4)/(max(m.DeltasOmegAmplTemporal(:,4))),'*')
                 end
             end
         end
     end
 end
 
xlabel('\omega_m')
ylabel('a_{m}')
ylim([1e-5 10])
xlim([-0.01 0.65])
%legend('d12-Inf','d12-L2','d15-Inf','d15-L2','d18-Inf','d18-L2','d20-Inf','d20-L2')
set(axes1,'FontSize',18,'YMinorTick','on','YScale','log');
set(gcf, 'Position', [100, 100, 1000, 300])

%  xlim(axes1,[-0.001 0.06]);
% ylim(axes1,[0.0005 1.5]);
% box(axes1,'on');
% 
% %ylabel('\hat{a}_m');
% ylabel('$$\hat{a}_m$$','Interpreter','Latex')
% xlabel('f_m')
% % Set the remaining axes properties
% set(axes1,'FontSize',18,'XGrid','on','XMinorTick','on','XTick',...
%     [0 0.01 0.02 0.03 0.04 0.05 0.06],'YGrid','on','YMinorTick','on','YScale',...
%     'log', 'YTick',[0.01 1]);
% % set(axes1,'FontSize',18,'XGrid','on','XMinorTick','on','XTick',...
% %     [0 0.015 0.03 0.045 0.06],'YGrid','on','YMinorTick','on','YScale',...
% %     'log', 'YTick',[0.01 1]);
%set(gcf, 'Position', [100, 100, 1000, 200])
% % Create legend
% % legend1 = legend(axes1,'show');
% % legend('d=25-Inf','d=25-L2','d=20-Inf','d=20-L2','d=15-Inf','d=15-L2','d=15-Inf-10^{-4}','d=15-L2-10^{-4}' )
% % set(legend1,'Orientation','horizontal');
% 
% 
% %set(axes1,'XGrid','on','XMinorTick','on','XTick',...
% %    [0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5],'YGrid','on','YMinorTick',...
% %    'on','YScale','log');