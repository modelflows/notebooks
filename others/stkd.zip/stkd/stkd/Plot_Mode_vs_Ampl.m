clc
clear all
close all

%load DMD_solution_d12_tol1e-04_L2_ALL/DMDmode_tensor.mat
freq=[0.017 0.036 0.075 0.085 0.11 0.15 0.34 0.39 0.45 ...
    0.25 0.22 0.47 0.43 0.37 0.31]

IND=[2 4 10 14 30 34 8 12 32 44 40 20 42 26 6]


tol=0.001
alpha=[0 0.48 0.98]

for jj=1:4
    count=1
    for i=1:length(freq)
        a=sprintf('DMD_solutionX_d1_L2_%2.2i/dataDeltasOmegasAmplTemporal.mat',freq(i))
        m=load(a);
        
        if jj<4
            if jj==1
                tol=0.01
            else
                tol=0.05
            end
            II=find(abs(m.DeltasOmegAmplTemporal(:,3))<alpha(jj)+tol & abs(m.DeltasOmegAmplTemporal(:,3))>alpha(jj)-tol);
        else
            tol=0.001
            II=1
            if abs(m.DeltasOmegAmplTemporal(II,3))<tol & abs(m.DeltasOmegAmplTemporal(II,3))>-tol
                II=2
            end
        end
        if jj==1
            Index0(count)=II;
            AA0(count)=m.DeltasOmegAmplTemporal(Index0(count),4);
            Alpha0(count)=m.DeltasOmegAmplTemporal(Index0(count),3);
            count=count+1;
        elseif jj==2
            Index1(count)=II(1);
            AA1(count)=m.DeltasOmegAmplTemporal(Index1(count),4);
            Alpha1(count)=m.DeltasOmegAmplTemporal(Index1(count),3);
            count=count+1;
        elseif jj==3
            Index2(count)=II(1);
            AA2(count)=m.DeltasOmegAmplTemporal(Index2(count),4);
            Alpha2(count)=m.DeltasOmegAmplTemporal(Index2(count),3);
            count=count+1;
        elseif jj==4
            IndexMax(count)=II;
            AAM(count)=m.DeltasOmegAmplTemporal(IndexMax(count),4);
            AlphaM(count)=m.DeltasOmegAmplTemporal(IndexMax(count),3);
            count=count+1;
        end
        
    end
end

figure1 = figure;

% Create axes
axes1 = axes('Parent',figure1);
hold(axes1,'on');
box on

plot(freq,AA0,'k+')
plot(freq,AA1,'bx')
plot(freq,AA2,'r^')
plot(freq,AAM,'mo')
xlabel('\omega_m')
ylabel('a_{n}')
legend('\alpha=0', '\alpha=0.5','\alpha=1','\alpha_{MAX}','Orientation','horizontal')
set(axes1,'FontSize',18,'YMinorTick','on','YScale','log');
ylim([1e-2 100])
set(gcf, 'Position', [100, 100, 1000, 300])
%%
load DMD_solution_d12_tol1e-04_L2_ALL/dataDeltasOmegasAmplTemporal.mat
load DMD_solution_d12_tol1e-04_L2_ALL/DMDmode_tensor.mat
freq=[0.017 0.036 0.075 0.085 0.11 0.15 0.34 0.39 0.45 ...
    0.25 0.22 0.47 0.43 0.37 0.31]

IND=[2 4 10 14 30 34 8 12 32 44 40 20 42 26 6]

for i=1:length(freq)
    Amn0(i)=AA0(i)*DeltasOmegAmplTemporal(IND(i),4);
    Amn1(i)=AA1(i)*DeltasOmegAmplTemporal(IND(i),4);
    Amn2(i)=AA2(i)*DeltasOmegAmplTemporal(IND(i),4);
    AmnM(i)=AAM(i)*DeltasOmegAmplTemporal(IND(i),4);
end

figure2 = figure;

% Create axes
axes1 = axes('Parent',figure2);
hold(axes1,'on');
box on

plot(freq,Amn0,'k+')
plot(freq,Amn1,'bx')
plot(freq,Amn2,'r^')
plot(freq,AmnM,'mo')
xlabel('\omega_m')
ylabel('a_{mn}')
ylim([1e-2 100])
legend('\alpha=0', '\alpha=0.5','\alpha=1','\alpha_{MAX}','Orientation','horizontal')
set(axes1,'FontSize',18,'YMinorTick','on','YScale','log');
set(gcf, 'Position', [100, 100, 1000, 300])
