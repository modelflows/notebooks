%% Plot vorticity
close all
%% plane YZ (vort in x)

%load DMD_solution/DMDmode_tensor.mat
load ./../DATA_elastoviscoplastic_Bi1_4/YZslices/Y_10pyz.mat
load ./../DATA_elastoviscoplastic_Bi1_4/YZslices/Z_10pyz.mat

modN=14

m_abs1=max(max(abs(DMDmode(1,:,:,modN))));
m_re1=max(max(abs(real(DMDmode(1,:,:,modN)))));
m_im1=max(max(abs(imag(DMDmode(1,:,:,modN)))));
m_abs2=max(max(abs(DMDmode(2,:,:,modN))));
m_re2=max(max(abs(real(DMDmode(2,:,:,modN)))));
m_im2=max(max(abs(imag(DMDmode(2,:,:,modN)))));
m_abs3=max(max(abs(DMDmode(3,:,:,modN))));
m_re3=max(max(abs(real(DMDmode(3,:,:,modN)))));
m_im3=max(max(abs(imag(DMDmode(3,:,:,modN)))));


vort_abs=curl(Y,Z,squeeze(abs(DMDmode(2,:,:,modN))),squeeze(abs(DMDmode(3,:,:,modN))));
vort_re=curl(Y,Z,squeeze(real(DMDmode(2,:,:,modN))),squeeze(real(DMDmode(3,:,:,modN))));
vort_im=curl(Y,Z,squeeze(imag(DMDmode(2,:,:,modN))),squeeze(imag(DMDmode(3,:,:,modN))));


figure(1)
contourf(Y,Z,vort_abs/max(max(vort_abs)),'LevelStep',0.1)
caxis([-1 1])
xlabel('Y')
ylabel('Z')
colorbar()
title('Vorticity- X ABS')

figure(2)
contourf(Y,Z,vort_re/max(max(vort_re)),'LevelStep',0.1)
caxis([-1 1])
xlabel('Y')
ylabel('Z')

colorbar()
title('Vorticity- X Re')

figure(3)
contourf(Y,Z,vort_im/max(max(vort_im)),'LevelStep',0.1)
caxis([-1 1])
colorbar()
xlabel('Y')
ylabel('Z')
title('Vorticity- X Im')


%%
figure(4)
contourf(Y,Z,squeeze(abs(DMDmode(2,:,:,modN)))/m_abs2)
caxis([-1 1])
colorbar()
xlabel('Y')
ylabel('Z')
title('DMD mode V ABS')

figure(5)
contourf(Y,Z,squeeze(real(DMDmode(2,:,:,modN)))/m_re2)
caxis([-1 1])
colorbar()
xlabel('Y')
ylabel('Z')
title('DMD mode V Re')

figure(6)
contourf(Y,Z,squeeze(imag(DMDmode(2,:,:,modN)))/m_im2)
caxis([-1 1])
colorbar()
xlabel('Y')
ylabel('Z')
title('DMD mode V Im')
%%
pause
%%
figure(7)
contourf(Y,Z,squeeze(abs(DMDmode(1,:,:,modN)))/m_abs1)
caxis([-1 1])
colorbar()
xlabel('Y')
ylabel('Z')
title('DMD mode U ABS')

figure(8)
contourf(Y,Z,squeeze(real(DMDmode(1,:,:,modN)))/m_re1)
caxis([-1 1])
colorbar()
xlabel('Y')
ylabel('Z')
title('DMD mode U Re')

figure(9)
contourf(Y,Z,squeeze(imag(DMDmode(1,:,:,modN)))/m_im1)
caxis([-1 1])
colorbar()
xlabel('Y')
ylabel('Z')
title('DMD mode U Im')