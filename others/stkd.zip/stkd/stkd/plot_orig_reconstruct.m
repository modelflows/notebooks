% Load necessary data
load('DMD_solution_d40_tol1e-09_L2_ALL/dataDeltasOmegasAmplTemporal.mat');
load('DMD_solution_d40_tol1e-09_L2_ALL/DMDmode_tensor.mat');
load('DMD_solution_d40_tol1e-09_L2_ALL/dataTensorReconst.mat');

AA = DMDmode;
BB = DeltasOmegAmplTemporal;
CC = TensorReconst;

load('Freq_Forward_Dt1_tol1m4_1m5_d30_40_50_60.mat');
freq = freq';

load('IndexOK_test_temporal_Forward_Dt1_tol1m4_d40.mat');
ind = Index1;

% Load additional tensor data
load('C:/Users/praji/Downloads/STKD_organizedFiles/STKD_organizedFiles/Tensor.mat');
DD1 = Tensor;
DD=DD1(:,:,:,:,501:599);

disp(size(CC))
disp(size(DD))

% Compare tensors CC and DD for specific indices
indicesToCompare = [1, 2, 3]; % Adjust this array for the desired indices
modeIndex = 50;              % Index of the mode to visualize
timeSlice = 32;              % Specific time slice for visualization

% Loop through the specified indices and plot
for i = 1:length(indicesToCompare)
    index = indicesToCompare(i);

    % Plot CC tensor
    figure(1);
    subplot(length(indicesToCompare), 1, i);
    contourf(squeeze(CC(index, :, :, timeSlice, modeIndex))'); % Squeeze to handle dimensions
    caxis([-0.7 0.7]);
    colorbar;
    title(sprintf('Reconstructed Tensor (Component: %d)', index), 'FontSize', 12);

    % Plot DD tensor
    figure(2);
    subplot(length(indicesToCompare), 1, i);
    contourf(squeeze(DD(index, :, :, timeSlice, modeIndex))'); % Squeeze to handle dimensions
    caxis([-0.7 0.7]);
    colorbar;
    title(sprintf('Original Tensor (Component: %d)', index), 'FontSize', 12);
end
