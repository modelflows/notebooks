
load  DMD_solution_d40_tol1e-09_L2_ALL/dataDeltasOmegasAmplTemporal.mat
load  DMD_solution_d40_tol1e-09_L2_ALL/DMDmode_tensor.mat
AA=DMDmode;
BB=DeltasOmegAmplTemporal;
%
load Freq_Forward_Dt1_tol1m4_1m5_d30_40_50_60.mat
freq=freq';
%
%load Index_test_temporal_Forward_Dt1_tol1m4_1m5_d30_40_50_60.mat
load IndexOK_test_temporal_Forward_Dt1_tol1m4_d40.mat
ind=Index1;

%%
load  DMD_solution_d40_tol1e-07_L2_ALL/dataDeltasOmegasAmplTemporal.mat
load  DMD_solution_d40_tol1e-07_L2_ALL/DMDmode_tensor.mat
%
%load Index_test_temporal_compare_Forward_Dt1_tol1m4_1m5_d30_40_50_60.mat
load IndexOK_test_temporal_compare_Forward_Dt1_tol1m4_d50.mat
II=Index2;

%%
close all

for i=1:length(ind)
    i
Indmode=ind(i)
Indmode2=II(i)
figure(i)
contourf(squeeze(abs(DMDmode(1,:,:,30,Indmode)))'/max(max(abs(DMDmode(1,:,:,30,Indmode)))))
caxis([-0.7 0.7])
figure(i+1)
contourf(squeeze(abs(AA(1,:,:,30,Indmode2)))'/max(max(abs(AA(1,:,:,30,Indmode2)))))
caxis([-0.7 0.7])

% figure(2)
% contourf(squeeze(imag(DMDmode(1,:,:,20,Indmode)))'/max(max(imag(DMDmode(1,:,:,20,Indmode)))))
% caxis([-0.7 0.7])
% figure(3)
% contourf(squeeze(imag(AA(1,:,:,20,Indmode2)))'/max(max(imag(AA(1,:,:,20,Indmode2)))))
% caxis([-0.7 0.7])
% pause
% 
% figure(3)
% contourf(squeeze(real(DMDmode(1,:,:,45,Indmode)))'/max(max(real(DMDmode(1,:,:,45,Indmode)))))
% caxis([-0.7 0.7])
% figure(4)
% contourf(squeeze(real(AA(1,:,:,45,Indmode2)))'/max(max(real(AA(1,:,:,45,Indmode2)))))
% caxis([-0.7 0.7])
% pause
% 
% figure(4)
% contourf(squeeze(imag(DMDmode(1,:,:,45,Indmode)))'/max(max(imag(DMDmode(1,:,:,45,Indmode)))))
% caxis([-0.7 0.7]) 
% figure(5)
% contourf(squeeze(imag(AA(1,:,:,45,Indmode2)))'/max(max(imag(AA(1,:,:,45,Indmode2)))))
% caxis([-0.7 0.7])
% pause
% 
% figure(5)
% contourf(squeeze(imag(DMDmode(1,:,110,:,Indmode)))'/max(max(imag(DMDmode(1,:,110,:,Indmode)))))
% caxis([-0.7 0.7])
% figure(6)
% contourf(squeeze(imag(AA(1,:,110,:,Indmode2)))'/max(max(imag(AA(1,:,110,:,Indmode2)))))
% caxis([-0.7 0.7])
% pause
% 
% figure(6)
% contourf(squeeze(imag(DMDmode(1,:,80,:,Indmode)))'/max(max(imag(DMDmode(1,:,80,:,Indmode)))))
% caxis([-0.7 0.7])
% figure(7)
% contourf(squeeze(imag(AA(1,:,80,:,Indmode2)))'/max(max(imag(AA(1,:,80,:,Indmode2)))))
% caxis([-0.7 0.7])
% pause
% 
% figure(7)
% contourf(squeeze(imag(DMDmode(1,:,40,:,Indmode)))'/max(max(imag(DMDmode(1,:,40,:,Indmode)))))
% caxis([-0.7 0.7])
% figure(8)
% contourf(squeeze(imag(AA(1,:,40,:,Indmode2)))'/max(max(imag(AA(1,:,40,:,Indmode2)))))
% caxis([-0.7 0.7])

%pause
end
