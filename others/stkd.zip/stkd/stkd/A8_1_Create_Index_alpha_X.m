clc
clear all
close all


load Freq_Forward_Dt1_tol1m4_1m5_d30_40_50_60.mat
freq=freq';

%% IN CHANNEL FLOWS WE CAN START WITH ALPHA=0 AND HARMONICS, BUT IN CANOPY IT IS NECESSARY TO DEFINE ALPHA IN THE FILE A7_1_0_*
%alpha=0
%alpha_FILE_A7_1_0_*=[1 2 3 4]

%CANOPY NOT ABS or not NF --> alpha=0 does not exist in all frequencies
alpha=4

% YOU CAN INCREASE THE TOLERANCE IN SOME CASES (ej. 0.2,0.3), WHEN THE CODE DOES NOT FIND ANY FREQ.
% IN CANOPY: at least 0.3 in all except in alpha=0
tol=0.7

% IN CANOPY WE REMOVE THE MODE WITH 0 for alpha/=0
if alpha ~= 0
    freq=freq(2:end);
else 
    tol=5e-2
end

load IndexOK_test_temporal_compare_Forward_Dt1_tol1m4_d50.mat
IND2=Index2;

% Set 1 every 2 modes for the loop
IND=IND2(1:2:end);

count=1

for i = 1:length(freq)
    a = sprintf('DMD_solutionX_d40_L2_%2.2i/dataDeltasOmegasAmplTemporal.mat', freq(i));
    m = load(a);
    II = find(abs(m.DeltasOmegAmplTemporal(:, 3)) < alpha + tol & abs(m.DeltasOmegAmplTemporal(:, 3)) > alpha - tol);
    
    if alpha == 0
        % Assign all values of II if II is non-empty
        if ~isempty(II)
            Index(count:count + length(II) - 1) = II;
            count = count + length(II);
        end
    else
        % Check if II has two elements or more
        if length(II) >= 2
            Index(count:count + 1) = II(1:2);  % Assign first two elements only
            count = count + 2;
        elseif length(II) == 1
            Index(count) = II;  % Assign single element
            count = count + 1;
        end
    end
end


 
if alpha==0
    b=sprintf('Index_ModesX_alpha.mat',alpha)
else
    b=sprintf('Index_ModesX_alpha%0.0i.mat',alpha)
end
save(b,'Index')

