
clc
clear all

load  DMD_solution_d15_tol1e-05_L2_ALL/dataDeltasOmegasAmplTemporal.mat
load  DMD_solution_d15_tol1e-05_L2_ALL/DMDmode_tensor.mat
AA=DMDmode;
BB=DeltasOmegAmplTemporal;
freq=[0.0325 0.0835 0.295 0.33 0.39 0.425 0.485 0.555 ...
     0.19 0.23 0.368 0.45]
IND2=[2 3 6 7 18 19 4 5 8 9 14 15 12 13 20 21 24 25 22 23 26 27 10 11]

% Set 1 every 2 modes for the loop
II=IND2(1:2:end);


[L nx ny nz nt]=size(DMDmode)
%%
deltaX=4*pi/(nx-1)
xx=[0:1:nx-1]*deltaX

deltaY=2/(ny-1)
yy=[0:ny-1]*deltaY

deltaZ=2*pi/(nz-1)
zz=[0:nz-1]*deltaZ

[X Y]=meshgrid(xx,yy);
[XX ZZ]=meshgrid(xx,zz);
[YY Z]=meshgrid(yy,zz);

close all

for i=1:length(II)
    Indmode=II(i)
        
    
    h2=figure;
    axes1 = axes('Parent',h2);
    hold(axes1,'on');
    box on
    contourf(XX,ZZ,squeeze(abs(DMDmode(1,:,30+8,:,Indmode)))'/max(max(real(DMDmode(1,:,30+8,:,Indmode))))')
    name2 = sprintf('./DMDmodes_planes_T/XZ_%2.2i_L38',freq(i));
    %saveas(h2,name2,'fig')
    xlabel('X')
    ylabel('Z')
    set(axes1,'FontSize',18);
    set(gcf, 'Position', [100, 100, 700, 350])
    saveas(h2,name2,'jpg')
    pause(0.2)
    close(h2)
    
    h2=figure;
    axes1 = axes('Parent',h2);
    hold(axes1,'on');
    box on
    contourf(XX,ZZ,squeeze(abs(DMDmode(1,:,30+8,:,Indmode)))'/max(max(real(DMDmode(1,:,30+9,:,Indmode))))')
    name2 = sprintf('./DMDmodes_planes_T/XZ_%2.2i_L39',freq(i));
    %saveas(h2,name2,'fig')
    xlabel('X')
    ylabel('Z')
    set(axes1,'FontSize',18);
    set(gcf, 'Position', [100, 100, 700, 350])
    saveas(h2,name2,'jpg')
    pause(0.2)
    close(h2)
    
    
    %%
    
    h2=figure;
    axes1 = axes('Parent',h2);
    hold(axes1,'on');
    box on
    contourf(X,Y,squeeze(abs(DMDmode(1,1:1:end,:,45,Indmode)))')
    name2 = sprintf('./DMDmodes_planes_T/XY_%2.2i_vx',freq(i));
        % saveas(h2,name2,'fig')
        xlabel('X')
        ylabel('Y')
        set(axes1,'FontSize',18);
        set(gcf, 'Position', [100, 100, 700, 350])
        saveas(h2,name2,'jpg')
        %pause
        close(h2)
        
        h2=figure;
        axes1 = axes('Parent',h2);
        hold(axes1,'on');
        box on
        contourf(XX,ZZ,squeeze(abs(DMDmode(1,1:1:end,18+30,:,Indmode)))')
        name2 = sprintf('./DMDmodes_planes_T/XZbottom_%2.2i_vx',freq(i));
        %saveas(h2,name2,'fig')
        xlabel('X')
        ylabel('Z')
        set(axes1,'FontSize',18);
        set(gcf, 'Position', [100, 100, 700, 350])
        saveas(h2,name2,'jpg')
        close(h2)
        
        h2=figure;
        axes1 = axes('Parent',h2);
        hold(axes1,'on');
        box on
        contourf(XX,ZZ,squeeze(abs(DMDmode(1,1:1:end,73+30,:,Indmode)))')
        name2 = sprintf('./DMDmodes_planes_T/XZtop_%2.2i_vx',freq(i));
        %saveas(h2,name2,'fig')
        xlabel('X')
        ylabel('Z')
        set(axes1,'FontSize',18);
        set(gcf, 'Position', [100, 100, 700, 350])
        saveas(h2,name2,'jpg')
        close(h2)
        
        %
        
        h2=figure;
        axes1 = axes('Parent',h2);
        hold(axes1,'on');
        box on
        contourf(X,Y,squeeze(abs(DMDmode(2,1:1:end,:,45,Indmode)))')
        name2 = sprintf('./DMDmodes_planes_T/XY_%2.2i_vy',freq(i));
        %saveas(h2,name2,'fig')
        xlabel('X')
        ylabel('Y')
        set(axes1,'FontSize',18);
        set(gcf, 'Position', [100, 100, 700, 350])
        saveas(h2,name2,'jpg')
        close(h2)
        
        h2=figure;
        axes1 = axes('Parent',h2);
        hold(axes1,'on');
        box on
        contourf(XX,ZZ,squeeze(abs(DMDmode(2,1:1:end,18+30,:,Indmode)))')
        name2 = sprintf('./DMDmodes_planes_T/XZbottom_%2.2i_vy',freq(i));
        %saveas(h2,name2,'fig')
        xlabel('X')
        ylabel('Z')
        set(axes1,'FontSize',18);
        set(gcf, 'Position', [100, 100, 700, 350])
        saveas(h2,name2,'jpg')
        close(h2)
        
        h2=figure;
        axes1 = axes('Parent',h2);
        hold(axes1,'on');
        box on
        contourf(XX,ZZ,squeeze(abs(DMDmode(2,1:1:end,73+30,:,Indmode)))')
        name2 = sprintf('./DMDmodes_planes_T/XZtop_%2.2i_vy',freq(i));
        %saveas(h2,name2,'fig')
        xlabel('X')
        ylabel('Z')
        set(axes1,'FontSize',18);
        set(gcf, 'Position', [100, 100, 700, 350])
        saveas(h2,name2,'jpg')
        close(h2)
        %pause
        
        
        


end
