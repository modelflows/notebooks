
clc
clear all
close all

%  freq=[0.017 0.036 0.075 0.085 0.11 0.15 0.34 0.39 0.45 ...
%      0.25 0.22 0.47 0.43 0.37 0.31]
freq=[0.017 0.15 0.25 0.43]
alpha=0.5
for i=1:length(freq)
    i
%  freq=[0.017 0.036 0.075 0.085 0.11 0.15 0.34 0.39 0.45 ...
%      0.25 0.22 0.47 0.43 0.37 0.31]
freq=[0.017 0.15 0.25 0.43]
alpha=0.5
    a=sprintf('DMD_solutionZX_d1_L2_%2.2i_B3_L%1.1i',freq(i),alpha)
    cd(a)
    Convert2Paraview
    cd ..
end

%  freq=[0.017 0.036 0.075 0.085 0.11 0.15 0.34 0.39 0.45 ...
%      0.25 0.22 0.47 0.43 0.37 0.31]
freq=[0.017 0.15 0.25 0.43]

for i=1:length(freq)
    i
%  freq=[0.017 0.036 0.075 0.085 0.11 0.15 0.34 0.39 0.45 ...
%      0.25 0.22 0.47 0.43 0.37 0.31]
freq=[0.017 0.15 0.25 0.43]
alpha=0.5
    a=sprintf('DMD_solutionZX_d1_L2_%2.2i_B0_L%1.1i',freq(i),alpha)
    cd(a)
    Convert2Paraview
    cd ..
end