function [UUrec_modes, a]=DMD_amplitudes_recalculation(DMDmode,Tensor,time,IND_s,DeltasOmegAmplTemporal,deltas)

    %% RE-CALCULATE NEW AMPLITUDES USING SMALLER NUMBER OF MODES AND RECONSTRUCT SOLUTION
    
    % 1) CALCULATE NEW AMPLITUDES
    [L Nx Ny Nz Nc]=size(DMDmode);
    Nt=length(time)
    Tensor=Tensor(:,:,:,:,end-Nt+1:end);
    %Umatrix_time=zeros(L*Nx*Ny*Nz,Nt,length(IND_s));
    DD=DeltasOmegAmplTemporal;
    ii=sqrt(-1);
    
    if deltas==0
        DD(:,2)=zeros(length(DD(:,2)),1);
    end
    
    for i=1:length(IND_s)
        for j=1:Nt
            
            % NORMALIZE WITH EXPONENTIAL TERM
%             if ExpNorm==1
                COEFF=DMDmode(1:3,:,:,:,IND_s(i))*exp((DD(IND_s(i),2) + ii*DD(IND_s(i),3))*(time(j)-time(1)));
                Umatrix_time(:,j,i)=COEFF(:)/norm(COEFF(:),2);
%             else
%                 % NORMALIZE WITHOUT EXPONENTIAL TERM
%                 COEFF2=DMDmode(1:3,:,:,:,IND_s(i));%*exp((DD(IND_s(i),2) + ii*DD(IND_s(i),3))*(time(j)-time(1)));
%                 Umatrix_6_modes_time(:,j,i)=COEFF2(:)/norm(COEFF2(:),2)*exp((DD(IND_s(i),2) + ii*DD(IND_s(i),3))*(time(j)-time(1)));;
%             end
        end
    end
    [J Nt M]=size(Umatrix_time);
    Umatrix_modes=zeros(J*Nt,M);
    for k=1:M
        for i=1:Nt
            Umatrix_modes(1+(i-1)*J:i*J,k)=Umatrix_time(:,i,k);
        end
    end
    
    Umatrix_modes=real(Umatrix_modes);
    
    [UU SS TT]=svd(Umatrix_modes,'econ');
    a=TT*(SS\(UU'*Tensor(:)));
    
    %[L Nx Ny Nz Nc]=size(DMDmode);
    UUrec_modes=zeros(3,Nx,Ny,Nz,length(time)-1);
    % 2) RECONSTRUCTION
    for i=1:length(IND_s)
        for j=1:length(time)-1           
            % USING THE NEW AMPLTIDUES
%             if ExpNorm==1
                % Normalize with exponential term
                COEFF=DMDmode(1:3,:,:,:,IND_s(i))*exp((DD(IND_s(i),2) + ii*DD(IND_s(i),3))*(time(j)-time(1)));
                UUrec_modes(:,:,:,:,j)= UUrec_modes(:,:,:,:,j) + ...
                    + a(i)*COEFF/norm(COEFF(:),2);
%             else
%                 % Normalize without exponential term
%                 COEFF2=DMDmode(1:3,:,:,:,IND_s(i));%*exp((DD(IND_s(i),2) + ii*DD(IND_s(i),3))*(time(j)-time(1)));
%                 UUrec_6modes(:,:,:,:,j)= UUrec_6modes(:,:,:,:,j) + ...
%                     + a(i)*COEFF2/norm(COEFF2(:),2)*exp((DD(IND_s(i),2) + ii*DD(IND_s(i),3))*(time(j)-time(1)));
%             end
        end
    end
    
    UUrec_modes=real(UUrec_modes);