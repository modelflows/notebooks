
 load DMD_solution_d12_tol1e-04_L2/dataDeltasOmegasAmplTemporal.mat
 load DMD_solution_d12_tol1e-04_L2/DMDmode_tensor.mat

freq=[0.34 0.085 0.15 0.45 0.51 0.017 0.035 0.11 0.39] %%0.074
ind=       [6 25 39 23 14 2 4 29 12 ] %%8

for i=1:length(ind)
Indmode=ind(i)
figure(1)
contourf(squeeze(real(DMDmode(1,:,:,20,Indmode)))'/max(max(real(DMDmode(1,:,:,20,Indmode)))))
caxis([-0.7 0.7])
pause

figure(2)
contourf(squeeze(imag(DMDmode(1,:,:,20,Indmode)))'/max(max(imag(DMDmode(1,:,:,20,Indmode)))))
caxis([-0.7 0.7])
pause

figure(3)
contourf(squeeze(real(DMDmode(1,:,:,45,Indmode)))'/max(max(real(DMDmode(1,:,:,45,Indmode)))))
caxis([-0.7 0.7])
pause

figure(4)
contourf(squeeze(imag(DMDmode(1,:,:,45,Indmode)))'/max(max(imag(DMDmode(1,:,:,45,Indmode)))))
caxis([-0.7 0.7])
pause

% figure(5)
% contourf(squeeze(imag(DMDmode(1,:,110,:,Indmode)))'/max(max(imag(DMDmode(1,:,110,:,Indmode)))))
% caxis([-0.7 0.7])
% pause
% 
% figure(6)
% contourf(squeeze(imag(DMDmode(1,:,80,:,Indmode)))'/max(max(imag(DMDmode(1,:,80,:,Indmode)))))
% caxis([-0.7 0.7])
% pause
% 
% figure(7)
% contourf(squeeze(imag(DMDmode(1,:,40,:,Indmode)))'/max(max(imag(DMDmode(1,:,40,:,Indmode)))))
% caxis([-0.7 0.7])

pause
end
