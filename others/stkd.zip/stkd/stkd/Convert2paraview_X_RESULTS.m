
clc
clear all
close all

freq=[0.018 0.035 0.15 0.34 0.39 0.074 0.085 0.11 0.44 0.51];

for i=1:length(freq)
    i
    freq=[0.018 0.035 0.15 0.34 0.39 0.074 0.085 0.11 0.44 0.51];
    a=sprintf('DMD_solutionX_d1_L2_%2.2i_L1',freq(i))
    cd(a)
    Convert2Paraview
    cd ..
end

freq=[0.018 0.035 0.15 0.34 0.39 0.074 0.085 0.11 0.44 0.51];

for i=1:length(freq)
    i
    freq=[0.018 0.035 0.15 0.34 0.39 0.074 0.085 0.11 0.44 0.51];
    a=sprintf('DMD_solutionX_d1_L2_%2.2i_L0',freq(i))
    cd(a)
    Convert2Paraview
    cd ..
end