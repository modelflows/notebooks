clear all
close all

 
%  freq=[0.017 0.036 0.075 0.085 0.11 0.15 0.34 0.39 0.45 ...
%      0.25 0.22 0.47 0.43 0.37 0.31]
%  IND=[2 4 10 14 30 34 8 12 32 44 40 20 42 26 6]

freq=[0.017 0.036 0.11 0.25 0.34 0.47 ]
 IND=[2 4 30 44 8 20 ]
beta=3



figure1 = figure;

% Create axes
axes1 = axes('Parent',figure1);
hold(axes1,'on');
box on
set(axes1,'FontSize',18,'YMinorTick','on','YScale','log');
for i=1:length(freq)
a=sprintf('DMD_solutionZX_d1_L2_%2.2i_B%1.1i/dataDeltasOmegasAmplTemporal.mat',freq(i),beta)
m=load(a);

d=[m.DeltasOmegAmplTemporal(:,3) m.DeltasOmegAmplTemporal(:,4)];
f=sortrows(d,1);
plot(f(:,1),f(:,2),'*-')
%plot(m.DeltasOmegAmplTemporal(:,3),m.DeltasOmegAmplTemporal(:,4),'*')
xlim([0 12])
end

xlabel('\alpha_r')
ylabel('a_{r}')
ylim([5e-4 30])
legend('\omega=0.017', '\omega=0.036','\omega=0.11','\omega=0.25','\omega=0.34','\omega=0.47','Orientation','horizontal')
set(axes1,'FontSize',18,'YMinorTick','on','YScale','log');
set(gcf, 'Position', [100, 100, 1000, 300])
