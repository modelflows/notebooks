clc
clear all
close all

freq=[0 0.43 0.70 0.97 1.95 2.03 3.00]
IND=[1 2 5 10]

beta=0%6%2%3%

tol=0.2%0.1
alpha=0.5%0%5.5

count=1
for i=1:length(freq)
    a=sprintf('DMD_solutionZX_d1_L2_%2.2i_B%1.1i/dataDeltasOmegasAmplTemporal.mat',freq(i),beta)
    m=load(a);
    if i==2 & alpha==0.5 & beta==0
        tol=0.5
    elseif i==3 & alpha==0.5 & beta==0
        tol=0.2
    elseif i==6 & alpha==0.5 & beta==0
        tol=0.4
    elseif i==7 & alpha==0.5 & beta==0
        tol=0.2
    end
    II=find(abs(m.DeltasOmegAmplTemporal(:,3))<alpha+tol & abs(m.DeltasOmegAmplTemporal(:,3))>alpha-tol);
     if i==4 & alpha==5 & beta==6
         II=II(2:3);
     elseif i==11 & alpha==0.5 & beta==6
         II=II(1:2:3);
     elseif i==8 & alpha==0 & beta==3
         II=II(2); 
     elseif i==2 & alpha==0.5 & beta==3
         II=II(2:3);
     elseif i==10 & alpha==0.5 & beta==6
         II=II(1:2);
     elseif i==2 & alpha==0.5 & beta==0
         %II=II(2:3);
    end
    if alpha==0 
        Index(count)=II;
        count=count+1;
    else
        Index(count:count+1)=II;
        count=count+2;
    end
end

b=sprintf('Index_ModesZX_beta%1.1i_alpha%1.1i.mat',beta,alpha)
save(b,'Index')
           
                          