 %% CREATE TENSOR ALL
 
clc
clear all
close all

 tolit=[1e-4 1e-5 1e-7 1e-8]
 ddit=[10 20 30 40]
 %ddit=[20 25 30 35 40]
 normit=[0 1]
 
 n1=length(tolit);
 n2=length(ddit);
 n3=length(normit);
 
 N=n1*n2*n3;
 
 TensorALL=zeros(N*3,100,40,64,99);
 
 count=1;
 for i=1:length(tolit)
     if i==3
         aaa=4
     else
         aaa=1
     end
     for j=aaa:length(ddit)
         for k=1:length(normit)
             L2=normit(k)
             d=ddit(j)
             varepsilon1=tolit(i)
             count=count+1;
             
             if L2==1
                 a=sprintf('DMD_solution_d%0.0i_tol%0.0e_L2_ALL/dataTensorReconst.mat',d,varepsilon1)
                 m=load(a);
             else
                 a=sprintf('DMD_solution_d%0.0i_tol%0.0e_Inf_ALL/dataTensorReconst.mat',d,varepsilon1)
                 m=load(a);
             end
             
            TensorALL(count,:,:,:,:)=m.TensorReconst(1,:,:,:,:);
            TensorALL(count+1,:,:,:,:)=m.TensorReconst(2,:,:,:,:);
            TensorALL(count+2,:,:,:,:)=m.TensorReconst(3,:,:,:,:);            
            count=count+2;
             
         end
     end
 end
 
 save TensorALL_dt5_1m5_d12_15_18_20.mat TensorALL -v7.3
 