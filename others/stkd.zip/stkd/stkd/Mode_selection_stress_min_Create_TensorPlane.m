clc
clear all
close all


% load DMD_solution_d15_tol1e-05_L2_ALL/dataDeltasOmegasAmplTemporal.mat
load DMD_solution_d15_tol1e-05_L2_ALL/dataTensorReconst.mat

% load ./../y3_drag_reducing/Tensor.mat
% TT=squeeze(Tensor(:,1:4:end,31:end-30,1:4:end,:));


TensorPlane=squeeze(TensorReconst(:,:,8:9,:,:));

save TensorPlane.mat TensorPlane

