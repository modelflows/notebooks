clc
clear all
close all

 tolit=[1e-3 1e-4]
 ddit=[12 15]
 %ddit=[20 25 30 35 40]
 normit=[0 1]
 
 figure1 = figure;
axes1 = axes('Parent',figure1);
hold(axes1,'on');
box on
 set(axes1,'YMinorTick','on','YScale','log');
 xlim([-0.01 0.7])
 for i=1:length(tolit)
     if i==3
         aaa=4
     else
         aaa=1
     end
     for j=aaa:length(ddit)
         for k=1:length(normit)
             L2=normit(k)
             d=ddit(j)
             varepsilon1=tolit(i)
             
             if L2==1
                 a=sprintf('DMD_solution_d%0.0i_tol%0.0e_L2_Plane/dataDeltasOmegasAmplTemporal.mat',d,varepsilon1)
                 m=load(a);
                 if i==1
                      plot(m.DeltasOmegAmplTemporal(:,3),m.DeltasOmegAmplTemporal(:,4)/(max(m.DeltasOmegAmplTemporal(:,4))),'s')
                 elseif i==2
                     plot(m.DeltasOmegAmplTemporal(:,3),m.DeltasOmegAmplTemporal(:,4)/(max(m.DeltasOmegAmplTemporal(:,4))),'^')
                  else
                      %plot(m.DeltasOmegAmplTemporal(:,3),m.DeltasOmegAmplTemporal(:,4)/(max(m.DeltasOmegAmplTemporal(:,4))),'o')
                  end
             else
                 a=sprintf('DMD_solution_d%0.0i_tol%0.0e_Inf_Plane/dataDeltasOmegasAmplTemporal.mat',d,varepsilon1)
                 m=load(a);
                 if i==1
                     plot(m.DeltasOmegAmplTemporal(:,3),m.DeltasOmegAmplTemporal(:,4)/(max(m.DeltasOmegAmplTemporal(:,4))),'x')
                 elseif i==2
                      plot(m.DeltasOmegAmplTemporal(:,3),m.DeltasOmegAmplTemporal(:,4)/(max(m.DeltasOmegAmplTemporal(:,4))),'+')
                 else
                     %plot(m.DeltasOmegAmplTemporal(:,3),m.DeltasOmegAmplTemporal(:,4)/(max(m.DeltasOmegAmplTemporal(:,4))),'*')
                 end
             end
         end
     end
 end