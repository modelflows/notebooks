clc
clear all
close all

%% WE USE THIS SCRIPT IN THE CANOPY FLOW TO SET THE CORRECT d IN THE SPATIAL ANALYSIS
% WE COMPARE THE DIFFERENT RESULTS AND SET THE CORRECT VALUES FOR BETA (AS
% IN THE FILE 2_*, WHERE WE SELECT THE CALIBRATION AND OMEGA

 tolit=[1]
 ddit=[1]% 15 30]
 normit=[1]
 
 
load Freq_Forward_Dt1_tol1m4_1m5_d30_40_50_60.mat
freq=freq';
tolit=freq;

load IndexOK_test_temporal_compare_Forward_Dt1_tol1m4_d50.mat
IND=Index2;


 %% DELTA T PARAMETER: ADJUST FOR CASES in folder: Cases_10T/*_ALL : DeltaTparam=10
 DeltaTparam=1
 
 figure1 = figure;
axes1 = axes('Parent',figure1);
hold(axes1,'on');
box on
 set(axes1,'YMinorTick','on','YScale','log');
% xlim([-0.01 0.7])%
 for i=1:length(tolit)
     
%      if i==3
%          aaa=4
%      else
          aaa=1
%      end
     for j=aaa:length(ddit)
         for k=1:length(normit)
             L2=normit(k)
             d=ddit(j)
             %varepsilon1=tolit(i)
             
             if L2==1
                 a=sprintf('ABS_FIBERS/DMD_solutionZ_d%0.0i_L2_%2.2i/dataDeltasOmegasAmplTemporal.mat',d,freq(i))
                 m=load(a);
                 if i==1
                      plot(m.DeltasOmegAmplTemporal(:,3)/DeltaTparam,m.DeltasOmegAmplTemporal(:,4)/(max(m.DeltasOmegAmplTemporal(:,4))),'sr')
                 elseif i==2
                     plot(m.DeltasOmegAmplTemporal(:,3)/DeltaTparam,m.DeltasOmegAmplTemporal(:,4)/(max(m.DeltasOmegAmplTemporal(:,4))),'^r')
                 elseif i==3
                      plot(m.DeltasOmegAmplTemporal(:,3)/DeltaTparam,m.DeltasOmegAmplTemporal(:,4)/(max(m.DeltasOmegAmplTemporal(:,4))),'or')
                 elseif i==4
                      plot(m.DeltasOmegAmplTemporal(:,3)/DeltaTparam,m.DeltasOmegAmplTemporal(:,4)/(max(m.DeltasOmegAmplTemporal(:,4))),'sb')
                 elseif i==5
                     plot(m.DeltasOmegAmplTemporal(:,3)/DeltaTparam,m.DeltasOmegAmplTemporal(:,4)/(max(m.DeltasOmegAmplTemporal(:,4))),'^b')
                 elseif i==6
                      plot(m.DeltasOmegAmplTemporal(:,3)/DeltaTparam,m.DeltasOmegAmplTemporal(:,4)/(max(m.DeltasOmegAmplTemporal(:,4))),'ob')
                 elseif i==7
                      plot(m.DeltasOmegAmplTemporal(:,3)/DeltaTparam,m.DeltasOmegAmplTemporal(:,4)/(max(m.DeltasOmegAmplTemporal(:,4))),'sk')
                 end
               
             end
         end
     end
 end
 
 
xlabel('\omega_m')
ylabel('a_{m}')
ylim([1e-2 3])
xlim([-0.01 50])
%legend('d12-Inf','d12-L2','d15-Inf','d15-L2','d18-Inf','d18-L2','d20-Inf','d20-L2')
set(axes1,'FontSize',18,'YMinorTick','on','YScale','log');
set(gcf, 'Position', [100, 100, 1000, 300])
 
