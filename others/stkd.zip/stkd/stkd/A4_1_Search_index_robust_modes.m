clear all
clc

% set up calibrations
ddit   = [10, 20, 30, 40]
tolit  = [1e-4, 1e-5, 1e-7, 1e-9]
normit = [0, 1]

MAC = 0.9 % tunable tolerance over cos(DMD1,DMD2), set 0.8 <= MAC < 1

%%

% load desired calibration from HODMD
dr = 40
varepsilonr = 1e-9
normr = 0
if normr == 1
    a = sprintf('./RECOPILACION_RESULTADOS_CANOPY_PAPER/VERTICAL/HODMD_CALIB/DMD_solution_d%0.0i_tol%0.0e_L2_ALL/dataDeltasOmegasAmplTemporal.mat',dr,varepsilonr);
    aa = sprintf('./RECOPILACION_RESULTADOS_CANOPY_PAPER/VERTICAL/HODMD_CALIB/DMD_solution_d%0.0i_tol%0.0e_L2_ALL/DMDmode_tensor.mat',dr,varepsilonr);
elseif normr == 0
    a = sprintf('./RECOPILACION_RESULTADOS_CANOPY_PAPER/VERTICAL/HODMD_CALIB/DMD_solution_d%0.0i_tol%0.0e_Inf_ALL/dataDeltasOmegasAmplTemporal.mat',dr,varepsilonr);
    aa = sprintf('./RECOPILACION_RESULTADOS_CANOPY_PAPER/VERTICAL/HODMD_CALIB/DMD_solution_d%0.0i_tol%0.0e_Inf_ALL/DMDmode_tensor.mat',dr,varepsilonr);
end

mm = load(a);
mm = mm.DeltasOmegAmplTemporal;
freq1 = mm(:,3);

nn = load(aa);
DMDmode1 = nn.DMDmode;

% load frequency vector of suspected robust DMD modes (go to A3)
pp = load('./NEW_FIGS_HODMD_PAPER/HODMD_CALIB/Freq_Vertical_Norminf_tol1m4_d50.mat');
pp = pp.freq;
freqr = pp';

%%
    
% compare [dr, varepsilonr, normr] calibration with the others

tol = 0.05 % tunable tolerance over frequencies, set tol <= 0.08

% initialize data matrices
freqrec = ones(length(freqr),length(ddit)*length(tolit)*length(normit)+1);
freqrec(:,1) = freqr;
robrec  = ones(length(freqr),length(ddit)*length(tolit)*length(normit)+1);
robrec(:,1) = freqr;
macrec  = ones(length(freqr),length(ddit)*length(tolit)*length(normit)+1);
macrec(:,1) = freqr;

calib = 0;
for i = 1:length(tolit)
    
    for j = 1:length(ddit)
        
        for k = 1:length(normit)
            
             calib = calib + 1
            
             varepsilon = tolit(i);
             d = ddit(j);
             L2 = normit(k);
             if d == dr && varepsilon == varepsilonr && L2 == normr
                 % if calib-th is the same as 'r', skips the iteration
                 continue 
             end            
             
             if L2 == 1 
                 b = sprintf('./RECOPILACION_RESULTADOS_CANOPY_PAPER/VERTICAL/HODMD_CALIB/DMD_solution_d%0.0i_tol%0.0e_L2_ALL/dataDeltasOmegasAmplTemporal.mat',d,varepsilon);
                 bb = sprintf('./RECOPILACION_RESULTADOS_CANOPY_PAPER/VERTICAL/HODMD_CALIB/DMD_solution_d%0.0i_tol%0.0e_L2_ALL/DMDmode_tensor.mat',d,varepsilon);
             elseif L2 == 0
                 b = sprintf('./RECOPILACION_RESULTADOS_CANOPY_PAPER/VERTICAL/HODMD_CALIB/DMD_solution_d%0.0i_tol%0.0e_Inf_ALL/dataDeltasOmegasAmplTemporal.mat',d,varepsilon);
                 bb = sprintf('./RECOPILACION_RESULTADOS_CANOPY_PAPER/VERTICAL/HODMD_CALIB/DMD_solution_d%0.0i_tol%0.0e_Inf_ALL/DMDmode_tensor.mat',d,varepsilon);
             end
             
             pp = load(b);
             pp = pp.DeltasOmegAmplTemporal;
             freq2 = pp(:,3);
             
             qq = load(bb);
             DMDmode2 = qq.DMDmode;
             
             for ii=1:length(freqr)
                 
                 IND1 = find(abs(freq1)<freqr(ii)+tol & abs(freq1)>freqr(ii)-tol);
                 if length(IND1) > 2
                     IND1=IND1(1:2);
                 end
                 
                 IND2 = find(abs(freq2)<freqr(ii)+tol & abs(freq2)>freqr(ii)-tol);
                 if length(IND2) > 2
                     IND2=IND2(1:2);
                 end

                 if isempty(IND1) || isempty(IND2)
                     
                     freqrec(ii,calib+1) = 0; 
                     robrec(ii,calib+1) = NaN; 
                     macrec(ii,calib+1) = NaN;
                     
                     continue % if the mode is not common, it's not considered for robust analysis
                 end
                 
                 % check robustness in common modes
                 DMD1 = DMDmode1(:,IND1(1));
                 DMD2 = DMDmode2(:,IND2(1));
                 
                 cc = abs(dot(DMD1(:),DMD2(:))/(norm(DMD1(:))*norm(DMD2(:))));
                 macrec(ii,calib+1) = cc;
                     
                 if cc >= MAC
                     robrec(ii,calib+1) = 1;
                 else 
                     robrec(ii,calib+1) = 0;
                 end                              
                 
             end
             
        end
        
    end
    
end

%%

tolfreq = 1 % tunable tolerance; mode is considered 'common' if frequency is present in at least (100 * tolfreq)% of calibrations
tolmac = 0.75 % tunable tolerance; mode is considered 'robust' if it fulfills MAC condition in at least (100 * tolmac)% of calibrations

ROB = zeros(length(freqr),3); % C1: frequencies; C2: common (1) or non-common (0) modes; C3: robust (1) or non-robust (0) common modes
ROB(:,1) = freqr;
freq = freqr; % initializes frequency vector
count = 1;
for i = 1:length(freqr)
    
    temp1 = freqrec(i,2:end);
    countfreq = temp1(temp1==1);
    if length(countfreq)/(length(ddit)*length(tolit)*length(normit)) >= tolfreq
        ROB(i,2) = 1; % common mode
        temp2 = robrec(i,2:end);
        countrob = temp2(temp2==1);
        if length(countrob)/(length(ddit)*length(tolit)*length(normit)) >= tolmac
            ROB(i,3) = 1; % robust mode
        end
        
        IND = find(abs(freq1)<freqr(i)+tol & abs(freq1)>freqr(i)-tol); % if common mode, looks for the index
        if length(IND) > 2
            IND=IND(1:2);
        end
        Index(count:count+1) = IND;
        count = count + 2;
    else
        ROB(i,2) = 0; % non-common mode
        ROB(i,3) = NaN; % if non-common mode, it's not considered for robustness analysis
        
        freq = freq(freq ~= freqr(i)); % removes non-common mode from frequency vector
    end
    
end

% save Freq_vector.mat freq
% save Index_vector.mat Index
