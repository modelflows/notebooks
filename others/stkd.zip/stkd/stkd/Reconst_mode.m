clc
close all
clear all

load DMD_solution_d1_Inf/DMDmode_tensor.mat
Tensor=DMDmode;

load DMD_solution_d1_Inf/dataDeltasOmegasAmplTemporal.mat
dd=DeltasOmegAmplTemporal;

Nz=84
[L,I,J,K,M]=size(DMDmode)
 

DMDmodeSet=10;

deltaT=3/(Nz-1)
Tiempos=[0:Nz-1]*deltaT;

ii=sqrt(-1);

MM1=squeeze(DMDmode(1,DMDmodeSet,:,:,:));
MM2=squeeze(DMDmode(2,DMDmodeSet,:,:,:));
MM3=squeeze(DMDmode(3,DMDmodeSet,:,:,:));

TensorReconst_B=zeros(3,Nz,J,K,M);

am=dd(DMDmodeSet,4);
vm=dd(DMDmodeSet,2)+ii*dd(DMDmodeSet,3);
t0=Tiempos(1);

for i=1:Nz
    Vm(i)=exp(vm*(Tiempos(i)-t0));
    TensorReconst_B(1,i,:,:,:)=am*MM1*Vm(i);
    TensorReconst_B(2,i,:,:,:)=am*MM2*Vm(i);
    TensorReconst_B(3,i,:,:,:)=am*MM3*Vm(i);
end

%% CHECK THE RECONSTRUCTION
load DMD_solution_d1_Inf_M1/dataTensorReconst.mat
Tensor=TensorReconst;
for i=1:M
     figure(1)
    subplot(2,1,1)
    contourf(squeeze(real(Tensor(2,:,:,20,i))))
    colorbar()
    subplot(2,1,2)
     contourf(squeeze(imag(TensorReconst_B(2,:,:,20,i))))
     colorbar()
     pause(0.2)
end