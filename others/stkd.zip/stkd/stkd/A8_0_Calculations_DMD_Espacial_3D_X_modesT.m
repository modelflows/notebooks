
%function  Calculations_DMD_Temporal_ND
  
 %clearvars -except Asnap_uv TensorMode TensorMatrix sv*
 clear all
 close all
 clc
 

load DMD_solution_d40_tol1e-07_L2_ALL/dataDeltasOmegasAmplTemporal.mat
load DMD_solution_d40_tol1e-07_L2_ALL/DMDmode_tensor.mat


%% IN *_ALL IT IS NOT NECESSARY TO REMOVE Y-LAYER:
% Tensor=DMDmode(:,:,31:end-30,:,:);
% IT IS POSSIBLE TO SELECT ONE GROUP OF MODES FOR THE ANALYSIS (To reduce
% the computational cost: from 1:3, from 4:7, et cetera in the first index 
% of the tensor). IN Convert-PARAVIEW IT IS COMPULSORY TO DO THAT!

% IN PAPER JFM - Outi & JFM - porous we do not use abs(DMDmode).
% IN CANOPY: we use abs(DMDmode)-- too complex the fibers. We can start
% from y - 100:end to improve results, but we loose information.

 Tensor=(DMDmode(1:3,:,1:end,:,:));
 
 
 save_modes=1

%%%%%%%%%%%%%%%%%%%%%% SAVE RESULTS IN FOLDER DMD_solution %%%%%%%%%%%%%%%
mkdir('DMD_solution')
system('rm -r DMD_solution');
mkdir('DMD_solution')
filename = sprintf('./DMD_solution/DMD_history.txt' );
diary(filename)

%mkdir('DMD_solution_tensor')
%system('rm -r DMD_solution_tensor');
%mkdir('DMD_solution_tensor')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
format shorte

tic

%%% Component velocity, span, stream, normal, time
 [L,Nx,Ny,Nz,nt]=size(Tensor)
%%

%Tensor=Tensor(1:3,:,:,1:nt);

 
% DISTANCE IN X POINTS (STREAMWISE COMPONENT)
 deltaT=2*pi/(Nx-1)% notDimension: 6/(Nx-1)
 Tiempos=[0:Nx-1]*deltaT;

 %% Set type of norm. L2=1 norm L2, else L2=0 norm Inf
 L2=1
 
 %% Set if you want to selec some modes for the reconstruction: If setM=1, ind=[mode1 mode2, ...]
 % 1) run this code with setM=0; 
 % create dummy index: Index=1; save Index_ModesX_beta.mat Index
 % 2) Create Index_X --> Run the code A8_1_Create_Index_alpha_X.m
 % 3) run this code: set the index to plot each beta for each mode: setM=1, and beta=?
 setM=1
 %Index=1; 
 %save Index_ModesX_alpha.mat Index
 %
 beta=1
 % CONT_complex=0 for beta=0, otherwise, CONT_complex=1
 CONT_complex=1
 % IN CANOPY: beta=0 not exist is DMD mode is not abs(DMDmode)
 
 if beta==0
     CONT_complex=0;
 end
 if CONT_complex==1
     
     if beta==1
       load Index_ModesX_alpha1.mat
       IIND=Index;
     elseif beta==2
       load Index_ModesX_alpha2.mat
       IIND=Index;
     elseif beta==3
       load Index_ModesX_alpha3.mat
       IIND=Index;
     end
       
     
 elseif CONT_complex==0
       load Index_ModesX_alpha.mat
       IIND=Index;
 end
 

 %% Set CC=1 if you want to obtain real data (mode + conj compl.)
 CC=1
 %%
 
 %% SET DMD mode to perform the analysis
load Freq_Forward_Dt1_tol1m4_1m5_d30_40_50_60.mat
freq=freq';
% IN CANOPY WE REMOVE THE FREQUENCY OMEGA = 0 WHEN BETA>0
%if beta ~=0
%    freq=freq(2:end);
%end

load IndexOK_test_temporal_compare_Forward_Dt1_tol1m4_d50.mat
IND2=Index2;

% Set 1 every 2 modes for the loop
if beta==0
    IND=IND2(1:2:end);
else
    IND=IND2(3:2:end)
end
Tensor2=Tensor;

AAA=length(IND)


counttt=0
 for zzz=1:2:(AAA*2)
        
     counttt=counttt+1
     SetDMD=[IND(counttt)]
     if setM==1
         if CONT_complex==1
             ind=[IIND(zzz) IIND(zzz+1)];
         else
             ind=[IIND(counttt)]
         end
     end     
     
     
mkdir('DMD_solution')
system('rm -r DMD_solution');
mkdir('DMD_solution')
filename = sprintf('./DMD_solution/DMD_history.txt' );
diary(filename)
 
 
 
 %
 Tensor1=squeeze(Tensor2(:,:,:,:,SetDMD));
 clear Tensor
 Tensor=Tensor1;
 %%
 

 varepsilon1=1e-10
 varepsilon2=1e-10 %2e-2
 d=1
 


 tol_svd=varepsilon1

 TiemposClean=Tiempos;
 save ./DMD_solution/dataTiemposClean TiemposClean
 
% 
% load ./DMD_solution_tensor/dataTensorClean TensorClean
% load ./DMD_solution_tensor/dataTiemposClean TiemposClean
% 
%  Tensor=TensorClean;
%  Tiempos=TiemposClean;
%  
 
 

[L,I,J,K]=size(Tensor)
n=[L,I,J,K];

nn1=[L,0,0,0];


%%

toc
Tensor1=Tensor;
for zz=1:1
    zz
    if zz~=1
        clear TensorReconst S* U* deltas* omegas* hat* sv*        
        load ./DMD_solution/dataTensorReconst TensorReconst
        load ./DMD_solution/dataTiemposClean TiemposClean
       %% Tensor1=real(TensorReconst);
        Tensor1=(TensorReconst); %% COMPLEX MODES
        Tiempos=TiemposClean;
        [L,I,J,K]=size(Tensor1)
        n=[L,I,J,K];
    end
    
[TT S U sv n] = hosvd(Tensor1, n);
n

h2=figure;
semilogy(1:I,sv{2},'o','linewidth',1,'color','k')
hold on
semilogy(1:J,sv{3},'+','linewidth',1,'color','r')
hold on
semilogy(1:K,sv{4},'o','linewidth',1,'color','b')



name2 = sprintf('./DMD_solution/SV2' );
saveas(h2,name2,'fig')
close(h2)
 
% return

nn=[L,0,0,0];


for i=2:4
    count=0;
    for j=1:size(sv{i},1)
        if sv{i}(j)/sv{i}(1)>=tol_svd
            count=count+1;
        else
            break
        end
    end
    nn(i)=count;
end
    
    nn
    

    
    %if zz==1
%nn=[L,7,42,7]
    %end
[TT S U sv nn] = hosvd(Tensor1, nn);
%return
nn





for pp=1:4
UT{pp}=U{pp}';
end

%DMDreducido ESPACIAL EN X
for kk=1:nn(2)
    hatT(kk,:)=sv{2}(kk)*UT{2}(kk,:);
end

if d>1
    if L2==0
        if setM==1
            [deltas1,omegas1,hatmodos1,hatamplitudes1] =DMDdOptimReduced_M_select(d,hatT,Tiempos,varepsilon1,varepsilon2,setM,ind);
        else
            [deltas1,omegas1,hatmodos1,hatamplitudes1] =DMDdOptimReduced_max(d,hatT,Tiempos,varepsilon1,varepsilon2,zz);
        end
    elseif L2==1
        if setM==1
            [deltas1,omegas1,hatmodos1,hatamplitudes1] =DMDdOptimReduced_select(d,hatT,Tiempos,varepsilon1,varepsilon2,setM,ind);
        else
            [deltas1,omegas1,hatmodos1,hatamplitudes1] =DMDdOptimReduced(d,hatT,Tiempos,varepsilon1,varepsilon2);
        end
    end
else
    if L2==0
        if setM==1
            [deltas1,omegas1,hatmodos1,hatamplitudes1] =DMD1OptimReduced_M_select(hatT,Tiempos,varepsilon1,varepsilon2,setM,ind);
        else
            [deltas1,omegas1,hatmodos1,hatamplitudes1] =DMD1OptimReduced_max(hatT,Tiempos,varepsilon1,varepsilon2,zz);
        end
    elseif L2==1
        if setM==1
            [deltas1,omegas1,hatmodos1,hatamplitudes1] =DMD1OptimReduced_select(hatT,Tiempos,varepsilon1,varepsilon2,setM,ind);
        else
            [deltas1,omegas1,hatmodos1,hatamplitudes1] =DMD1OptimReduced(hatT,Tiempos,varepsilon1,varepsilon2);
        end
    end
end

[N,K]=size(hatT)

hatTReconst=zeros(N,K);


    
    
for k=1:K
  hatTReconst(:,k)= ContReconst(Tiempos(k),Tiempos(1),hatmodos1,Tiempos,deltas1,omegas1);
end
error1=norm(hatT-hatTReconst,2)/norm(hatT,2);
error1

%Reconstruccion ESPACIAL EN X
UNuevo=U;
for kk=1:nn(2)
UTNuevo{2}(kk,:)=hatTReconst(kk,:)/sv{2}(kk);
end
UNuevo{2}=UTNuevo{2}';

TensorReconst=tprod(S, UNuevo);
%% COMPLEX MODES
% if setM==0 || CC==1
%     TensorReconst=real(TensorReconst);
% end
%%
errorRMSTemporal=norm(Tensor(:)-TensorReconst(:),2)/norm(Tensor(:),2);
errorRMSTemporal

[~,MM]=size(hatmodos1);

DeltasOmegAmplTemporal=[(1:MM)',deltas1',omegas1',hatamplitudes1']
%DeltasOmegAmplTemporal/2/pi

%TensorReconst=real(TensorReconst);
save ./DMD_solution/dataTensorReconst TensorReconst -v7.3
save ./DMD_solution/dataDeltasOmegasAmplTemporal DeltasOmegAmplTemporal


h=figure;
semilogy(omegas1,abs(deltas1),'o','linewidth',2,'color','k');
name1 = sprintf('./DMD_solution/OmegasDeltas_d%03i',d );
saveas(h,name1,'fig')
close(h)

h2=figure;
semilogy(omegas1,hatamplitudes1,'o','linewidth',2,'color','k');
name2 = sprintf('./DMD_solution/OmegasAmplitud_d%03i',d );
saveas(h2,name2,'fig')
close(h2)

    num=0
    for i=2:4
        if nn(i)==nn1(i)
         num=num+1;
        end
    end
    if num==3
        %save ./DMD_solution/dataS S -v7.3
        %save ./DMD_solution/datahatmodos1 hatmodos1 -v7.3
        %save ./DMD_solution/dataK K
        %save ./DMD_solution/dataU U -v7.3
        %save ./DMD_solution/datann nn
        %save ./DMD_solution/dataN N      
        save ./DMD_solution/dataTiempos Tiempos          
        %save ./DMD_solution/dataSV sv  
        break
    end

nn1=nn;
end
toc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if save_modes ==1
    
    % SAVE RESULTS IN FOLDER DMD_modes %
%     mkdir('DMD_modes')
%     system('rm -r DMD_modes');
%     mkdir('DMD_modes')

    
    % SAVE DMD MODES
    % SPATIAL MODES DMD: S*u
    
    
    hatTReconst_modes=zeros(N,K);
    hatmodos1_modes=zeros(N,length(hatamplitudes1));
    
    for ii=1:length(hatamplitudes1)
        hatmodos1_modes(:,ii)=hatmodos1(:,ii)/hatamplitudes1(ii);
    end
    
    Modes=U;
    for kk=1:nn(2)
        Modes_rem{2}(kk,:)=hatmodos1_modes(kk,:);
    end
    Modes{2}=Modes_rem{2}';
    DMDmode=tprod(S,Modes);
    
    save ./DMD_solution/DMDmode_tensor DMDmode -v7.3
       
    
end

toc
diary off
     clear DMDmode TensorReconst DeltasOmeg* hat* Mode* T S UNuevo

     if setM==0
         a=sprintf('DMD_solutionX_d%0.0i_L2_%2.2i',d,freq(counttt))
     else
         if CONT_complex==0
             a=sprintf('DMD_solutionX_d%0.0i_L2_%2.2i_L0',d,freq(counttt))
         else
             a=sprintf('DMD_solutionX_d%0.0i_L2_%2.2i_L%1.1i',d,freq(counttt),beta)
         end
     end
     movefile('DMD_solution',a)

 end