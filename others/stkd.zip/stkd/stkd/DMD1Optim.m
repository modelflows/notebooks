
function  [Vreconst,deltas,omegas,amplitudes] =DMD1Optim(V,Tiempos,varepsilon1,varepsilon)
                

%Efect�a un DMD1, con la notaci�n del paper con Sole
%Entradas:
%V es la matriz de snapshots
%varepsilon1 es el threshold para truncar el primer SVD
%Tiempos es el vector con los tiempos de los snapshots
%Salidas:7
%Vreconst el la matriz de snapshots reconstruida
%deltas y omegas son vectores con los damping rates y las frecuencias
%u es la matriz cuyas columnas son los modos DMD


[J,K]=size(V);
%[U,Sigma,T]=svd(V); %ORIGINAL SIAM  %%%%% AQUI !!!!!
[U,Sigma,T]=svd(V,'econ');
sigmas=diag(Sigma);
%sigmas
Deltat=Tiempos(2)-Tiempos(1);
n=length(sigmas);


aaaaa=norm(sigmas,2);
kk=0;
for k=1:n
    if norm(sigmas(k:n),2)/aaaaa>varepsilon1
        kk=kk+1;
    end
end
kk
close(figure(1))
figure(1)
semilogy(1:length(sigmas),sigmas(1:length(sigmas)),'k','linewidth',2);
%semilogy(1:n,sigmas);
%return

U=U(:,1:kk);

%return
hatT=Sigma(1:kk,1:kk)*T(:,1:kk)';
% K
% return
[N,K]=size(hatT);
%return

[hatU1,hatSigma,hatU2]=svd(hatT(:,1:K-1),'econ');

hatR=hatT(:,2:K)*hatU2*inv(hatSigma)*hatU1';
[Q,MM]=eig(hatR);
% size(Q)
% %return
% for n=1:N
%  pipa=Q(:,n);
%  norm(pipa(:),2)
% end
% return
autovalores=diag(MM);

M=length(autovalores);
cucu=log(autovalores);
deltas=real(cucu)/Deltat;
omegas=imag(cucu)/Deltat;
%omegas

meme=zeros(M*K,M);
bebe=zeros(M*K,1);
for k=1:K
 meme(1+(k-1)*M:k*M,:)=Q*(MM^(k-1)); 
 bebe(1+(k-1)*M:k*M,1)=hatT(:,k);
end

% meme=zeros(NN*K,M);
% bebe=zeros(NN*K,1);
% aa=eye(MMM);
% for k=1:K
%  meme(1+(k-1)*NN:k*NN,:)=Q*aa; 
%  aa=aa*tildeMM;
%  bebe(1+(k-1)*NN:k*NN,1)=hatT(:,k);
% end

% size(meme)
% size(bebe)


[Ur,Sigmar,Vr]=svd(meme,'econ');
% diag(Sigmar)
% return
% size(Ur)
% size(Sigmar)
% size(Vr)
a=Vr*(Sigmar\(Ur'*bebe));
%return

u=zeros(M,M);
for m=1:M
    u(:,m)=a(m)*Q(:,m);
end

amplitudes=zeros(M,1);
% for m=1:M
%     amplitudes(m)=norm(u(:,m),2)/sqrt(M);
% end
for m=1:M
    aca=U*u(:,m);
    amplitudes(m)=norm(aca(:),2)/sqrt(J);    
    %amplitudes(m)=norm(u(:,m),'inf');
end

UU=[u;deltas';omegas';amplitudes']';
UU1=sortrows(UU,-(M+3));

UU=UU1';
u=UU(1:M,:);
deltas=UU(M+1,:);
omegas=UU(M+2,:);
amplitudes=UU(M+3,:);
kk2=0;
%norma=norm(amplitudes,2)/sqrt(M);
for m=1:M
    if amplitudes(m)/amplitudes(1)>varepsilon
        kk2=kk2+1;
    else
    end
end
kk2
u=u(:,1:kk2);
deltas=deltas(1:kk2);
omegas=omegas(1:kk2);
amplitudes=amplitudes(1:kk2);

DeltasOmegAmpl=[deltas',omegas',amplitudes']

%return
hatTreconst=zeros(N,K);
for k=1:K
  hatTreconst(:,k)= ContReconst(Tiempos(k),Tiempos(1),u,Tiempos,deltas,omegas);
end





error1=norm(hatT-hatTreconst,2)/sqrt(N*K);
error1;
Vreconst=U*hatTreconst;
%u=U*u;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% SAVE DMD MODES
%SPATIAL MODES DMD: U*v
clear data
data=zeros(size(U(:,1),1),1);


DMDmode=U(:,:)*real(Q(:,1:kk2));


for i=1:KK3
    filename = sprintf('./DMD_solution/DMD-1_mode_n%02i.txt',i );
    data(:)=DMDmode(:,i);
    save(filename,'data','-ascii')
end





    

