clc;
clear all;
close all;

% Parameters
tolit = [1e-4 1e-5 1e-7 1e-9]; % Tolerance levels
ddit = [10 20 30 40];          % Parameter d values
normit = [0 1];                % Norms: 0 (Inf), 1 (L2)

DeltaTparam = 1; % DELTA T PARAMETER
figure1 = figure;
axes1 = axes('Parent', figure1);
hold(axes1, 'on');
box(axes1, 'on');

% Axes settings
set(axes1, 'YMinorTick', 'on', 'YScale', 'log', 'FontSize', 18);
xlim([-0.01 6]);
ylim([1e-3 1]);
xlabel('\omega_m', 'FontSize', 18);
ylabel('a_{m}', 'FontSize', 18);

% Markers for different cases
markers_L2 = {'s', '^', 'o', 'd'};
markers_Inf = {'x', '+', '*', 'p'};
legendEntries = {};

% Plot all cases
for i = 1:length(tolit) % Loop over tolerances
    varepsilon1 = tolit(i);
    for j = 1:length(ddit) % Loop over d values
        d = ddit(j);
        for k = 1:length(normit) % Loop over norms (L2 and Inf)
            L2 = normit(k);
            
            % Generate file name
            if L2 == 1
                filepath = sprintf('DMD_solution_d%0.0i_tol%0.0e_L2_ALL/dataDeltasOmegasAmplTemporal.mat', d, varepsilon1);
                marker = markers_L2{i};
                legendEntry = sprintf('L2: d=%d, tol=%.0e', d, varepsilon1);
            else
                filepath = sprintf('DMD_solution_d%0.0i_tol%0.0e_Inf_ALL/dataDeltasOmegasAmplTemporal.mat', d, varepsilon1);
                marker = markers_Inf{i};
                legendEntry = sprintf('Inf: d=%d, tol=%.0e', d, varepsilon1);
            end
            
            % Check if file exists and plot
            if exist(filepath, 'file')
                m = load(filepath);
                plot(m.DeltasOmegAmplTemporal(:, 3) / DeltaTparam, ...
                     m.DeltasOmegAmplTemporal(:, 4) / max(m.DeltasOmegAmplTemporal(:, 4)), ...
                     marker, 'DisplayName', legendEntry);
                legendEntries{end + 1} = legendEntry; % Add legend entry dynamically
                % Reduce font sizes for plot element
    
  
            else
                fprintf('File not found: %s\n', filepath);
            end
        end
    end
end

% Add legend

hLegend = legend(legendEntries); % Create the legend
set(hLegend, 'FontSize', 10); % Explicitly set the legend font size  

% Adjust figure properties
set(gcf, 'Position', [100, 100, 1200, 400]);

 
