function A = K1(n,h,a11)
% % PERIODIC BC ??;
% A = spdiags([0 1/2 0;ones(n-2,1)*[-1/2 0 -1/2]; 0 1/2 0],-1:1,n,n)'/h;
% 
% %% SECOND DERIVATIVE
% % a11: Neumann=1, Dirichlet=2, Dirichlet mid=3;
% A = spdiags([-1 a11 0;ones(n-2,1)*[-1 2 -1];0 a11 -1],-1:1,n,n)'/h^2;


%% FIRST DERIVATIVE
% a11: Neumann=1, Dirichlet=2, Dirichlet mid=3;
%A = spdiags([-1 a11 0;ones(n-2,1)*[1/2 0 -1/2];0 a11 -1],-1:1,n,n)'/h;

%% FIRST DERIVATIVE PERIODIC BC
% a11: Neumann=1, Dirichlet=2, Dirichlet mid=3;
A = spdiags([0 -1/2 0;ones(n-2,1)*[1/2 0 -1/2];0 1/2 0],-1:1,n,n)'/h;