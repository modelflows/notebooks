
%function  Calculations_DMD_Temporal_ND
  
 %clearvars -except Asnap_uv TensorMode TensorMatrix sv*
 clear all
 close all
 clc
 
 
 %% INCLUDE FREQ & INDEX FOR EACH CASE
 freq=[0.017 0.036 0.075 0.085 0.11 0.15 0.34 0.39 0.45 ...
     0.25 0.22 0.47 0.43 0.37 0.31]
 IND=[2 4 10 14 30 34 8 12 32 44 40 20 42 26 6]
 
 
 %% DISTANCE IN Z POINTS (SPANWISE COMPONENT)
 Lz=4*pi
 %deltaT=Lz/(Nz-1)
 %Tiempos=[0:Nz-1]*deltaT;
 
 %% INCLUDE BETA
 % beta=0,2,3,6 in DR
 beta=0
 
 %% INCLUDE ALPHA: CHECK THE INDEX FILES IN LINE 75-90
 % for beta=2,3,6, alpha=0,0.5,5.5
 alpha=0.5
 
 %% Set type of norm. L2=1 norm L2, else L2=0 norm Inf
 L2=0
 
 %% Set if you want to selec some modes for the reconstruction: If setM=1, ind=[mode1 mode2, ...]
 setM=1
 % CONT_COMPLEX=1: reconstruct with frequency =/0,
 % CONT_COMPLEX=0, reconstruct with frequency =0
 
 if alpha==0
     CONT_complex=0
 else
     CONT_complex=1
 end
 
 %% SET DMD PARAMETERS
 varepsilon1=1e-4
 varepsilon2=1e-2
 d=1
 
 
 %% SET ANALYSIS COMPONENT: 2-X, 3-Y, 4-Z, 5-T
 %(this depends on the tensor or each problem)
 component=2
 
 %% PROGRAM STARTS
 counttt=0
 count2=1
 for i=1:length(freq)
     
     counttt=counttt+1
     
     
     a=sprintf('DMD_solutionZ_d1_L2_%2.2i_B%1.1i/dataTensorReconst.mat',freq(i),beta)
     m=load(a);
     
     
     %% IN *_ALL & DMD_solutionX* IT IS NOT NECESSARY TO REMOVE Y-LAYER:
     % Tensor=DMDmode(:,:,31:end-30,:,:);
     % IT IS POSSIBLE TO SELECT ONE GROUP OF MODES FOR THE ANALYSIS (To reduce
     % the computational cost: from 1:3, from 4:7, et cetera in the first index
     % of the tensor). IN Convert-PARAVIEW IT IS COMPULSORY TO DO THAT!
     
     Tensor=m.TensorReconst(1:3,:,:,:);
     
     save_modes=1
     
     %%%%%%%%%%%%%%%%%%%%%% SAVE RESULTS IN FOLDER DMD_solution %%%%%%%%%%%%%%%
     mkdir('DMD_solution')
     system('rm -r DMD_solution');
     mkdir('DMD_solution')
     filename = sprintf('./DMD_solution/DMD_history.txt' );
     diary(filename)
     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     format shorte
     
     tic
     
     %%% Component velocity, span, stream, normal, time
     [L,Nx,Ny,Nz,nt]=size(Tensor)
     %%
     deltaT=Lz/(Nz-1)
     Tiempos=[0:Nz-1]*deltaT;
     
     if setM==1
         if CONT_complex==1
             
             %% GENERAL SOLUTION
             %if alpha==1
                 a=sprintf('Index_ModesZX_beta%1.1i_alpha%1.1i.mat',beta,alpha)
                 cc=load(a);
                 IIND=cc.Index;
%              elseif alpha==5
%                  a=sprintf('Index_ModesZX_beta%1.1i_alpha%0.0i.mat',beta,alpha)
%                  cc=load(a);
%                  IIND=cc.Index;
%              end
             
         elseif CONT_complex==0
             a=sprintf('Index_ModesZX_beta%1.1i_alpha.mat',beta)
             cc=load(a);
             IIND=cc.Index;
         end
     end
     
     %% Set CC=1 if you want to obtain real data (mode + conj compl.)
     CC=0
     %%
     

          if setM==1
              if CONT_complex==1
                  ind=[IIND(count2) IIND(count2+1)];
                  count2=count2+2
              else
                  ind=[IIND(i)]
              end
          end
     %
  
     
%%
     
   
     tol_svd=varepsilon1
     
     TiemposClean=Tiempos;
     save ./DMD_solution/dataTiemposClean TiemposClean
     
     
     
     [L,I,J,K]=size(Tensor)
     n=[L,I,J,K];
     
     nn1=[L,0,0,0];
     
     
     %%
     
     toc
     Tensor1=Tensor;
     for zz=1:1%000
         zz
         if zz~=1
             clear TensorReconst S* U* deltas* omegas* hat* sv*
             load ./DMD_solution/dataTensorReconst TensorReconst
             load ./DMD_solution/dataTiemposClean TiemposClean
             %% Tensor1=real(TensorReconst);
             Tensor1=(TensorReconst); %% COMPLEX MODES
             Tiempos=TiemposClean;
             [L,I,J,K]=size(Tensor1)
             n=[L,I,J,K];
         end
         
         [TT S U sv n] = hosvd(Tensor1, n);
         n
         
         h2=figure;
         semilogy(1:I,sv{2},'o','linewidth',1,'color','k')
         hold on
         semilogy(1:J,sv{3},'+','linewidth',1,'color','r')
         hold on
         semilogy(1:K,sv{4},'o','linewidth',1,'color','b')
         
         
         
         name2 = sprintf('./DMD_solution/SV2' );
         saveas(h2,name2,'fig')
         close(h2)
         
         % return
         
         nn=[L,0,0,0];
         
         
         for i=2:4
             count=0;
             for j=1:size(sv{i},1)
                 if sv{i}(j)/sv{i}(1)>=tol_svd
                     count=count+1;
                 else
                     break
                 end
             end
             nn(i)=count;
         end
         
         nn
         
         
         [TT S U sv nn] = hosvd(Tensor1, nn);
         nn
         
         
         
         
         
         for pp=1:4
             UT{pp}=U{pp}';
         end
         
         %DMDreducido ESPACIAL EN X: component=2
         for kk=1:nn(component)
             hatT(kk,:)=sv{component}(kk)*UT{component}(kk,:);
         end
         
         if d>1
             if L2==0
                 if setM==1
                     [deltas1,omegas1,hatmodos1,hatamplitudes1] =DMDdOptimReduced_M_select(d,hatT,Tiempos,varepsilon1,varepsilon2,setM,ind);
                 else
                     [deltas1,omegas1,hatmodos1,hatamplitudes1] =DMDdOptimReduced_max(d,hatT,Tiempos,varepsilon1,varepsilon2,zz);
                 end
             elseif L2==1
                 if setM==1
                     [deltas1,omegas1,hatmodos1,hatamplitudes1] =DMDdOptimReduced_select(d,hatT,Tiempos,varepsilon1,varepsilon2,setM,ind);
                 else
                     [deltas1,omegas1,hatmodos1,hatamplitudes1] =DMDdOptimReduced(d,hatT,Tiempos,varepsilon1,varepsilon2);
                 end
             end
         else
             if L2==0
                 if setM==1
                     [deltas1,omegas1,hatmodos1,hatamplitudes1] =DMD1OptimReduced_M_select(hatT,Tiempos,varepsilon1,varepsilon2,setM,ind);
                 else
                     [deltas1,omegas1,hatmodos1,hatamplitudes1] =DMD1OptimReduced_max(hatT,Tiempos,varepsilon1,varepsilon2,zz);
                 end
             elseif L2==1
                 if setM==1
                     [deltas1,omegas1,hatmodos1,hatamplitudes1] =DMD1OptimReduced_select(hatT,Tiempos,varepsilon1,varepsilon2,setM,ind);
                 else
                     [deltas1,omegas1,hatmodos1,hatamplitudes1] =DMD1OptimReduced(hatT,Tiempos,varepsilon1,varepsilon2);
                 end
             end
         end
         
         [N,K]=size(hatT)
         
         hatTReconst=zeros(N,K);
         
         
         
         
         for k=1:K
             hatTReconst(:,k)= ContReconst(Tiempos(k),Tiempos(1),hatmodos1,Tiempos,deltas1,omegas1);
         end
         error1=norm(hatT-hatTReconst,2)/norm(hatT,2);
         error1
         
         %Reconstruccion ESPACIAL EN X. Component=2
         UNuevo=U;
         for kk=1:nn(component)
             UTNuevo{component}(kk,:)=hatTReconst(kk,:)/sv{component}(kk);
         end
         UNuevo{component}=UTNuevo{component}';
         
         TensorReconst=tprod(S, UNuevo);
         %% COMPLEX MODES
         % if setM==0 || CC==1
         %     TensorReconst=real(TensorReconst);
         % end
         %%
         errorRMSTemporal=norm(Tensor(:)-TensorReconst(:),2)/norm(Tensor(:),2);
         errorRMSTemporal
         
         [~,MM]=size(hatmodos1);
         
         DeltasOmegAmplTemporal=[(1:MM)',deltas1',omegas1',hatamplitudes1']
         %DeltasOmegAmplTemporal/2/pi
         
         %TensorReconst=real(TensorReconst);
         save ./DMD_solution/dataTensorReconst TensorReconst -v7.3
         save ./DMD_solution/dataDeltasOmegasAmplTemporal DeltasOmegAmplTemporal
         
         
         h=figure;
         semilogy(omegas1,abs(deltas1),'o','linewidth',2,'color','k');
         name1 = sprintf('./DMD_solution/OmegasDeltas_d%03i',d );
         saveas(h,name1,'fig')
         close(h)
         
         h2=figure;
         semilogy(omegas1,hatamplitudes1,'o','linewidth',2,'color','k');
         name2 = sprintf('./DMD_solution/OmegasAmplitud_d%03i',d );
         saveas(h2,name2,'fig')
         close(h2)
         
         num=0
         for i=2:4
             if nn(i)==nn1(i)
                 num=num+1;
             end
         end
         if num==3
             %save ./DMD_solution/dataS S -v7.3
             %save ./DMD_solution/datahatmodos1 hatmodos1 -v7.3
             %save ./DMD_solution/dataK K
             %save ./DMD_solution/dataU U -v7.3
             %save ./DMD_solution/datann nn
             %save ./DMD_solution/dataN N
             save ./DMD_solution/dataTiempos Tiempos
             %save ./DMD_solution/dataSV sv
             break
         end
         
         nn1=nn;
     end
     toc
     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     if save_modes ==1
         
         % SAVE RESULTS IN FOLDER DMD_modes %
         %     mkdir('DMD_modes')
         %     system('rm -r DMD_modes');
         %     mkdir('DMD_modes')
         
         
         % SAVE DMD MODES
         % SPATIAL MODES DMD: S*u
         
         
         hatTReconst_modes=zeros(N,K);
         hatmodos1_modes=zeros(N,length(hatamplitudes1));
         
         for ii=1:length(hatamplitudes1)
             hatmodos1_modes(:,ii)=hatmodos1(:,ii)/hatamplitudes1(ii);
         end
         
         Modes=U;
         for kk=1:nn(component)
             Modes_rem{component}(kk,:)=hatmodos1_modes(kk,:);
         end
         Modes{component}=Modes_rem{component}';
         DMDmode=tprod(S,Modes);
         
         save ./DMD_solution/DMDmode_tensor DMDmode -v7.3
         
         
     end
     
     toc
     diary off
     clear DMDmode TensorReconst DeltasOmeg* hat* Mode* T S UNuevo
     
     if setM==0
         a=sprintf('DMD_solutionZX_d1_L2_%2.2i_B%1.1i',freq(counttt),beta);
     else
         if CONT_complex==0
             a=sprintf('DMD_solutionZX_d1_L2_%2.2i_B%1.1i_L0',freq(counttt),beta)
         else
             a=sprintf('DMD_solutionZX_d1_L2_%2.2i_B%1.1i_L%1.1i',freq(counttt),beta,alpha)
         end
     end
     movefile('DMD_solution',a)
     
 end