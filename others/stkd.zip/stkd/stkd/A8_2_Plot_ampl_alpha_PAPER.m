clear all
close all




load Freq_Forward_Dt1_tol1m4_1m5_d30_40_50_60.mat
freq=freq';


load IndexOK_test_temporal_compare_Forward_Dt1_tol1m4_d50.mat
IND=Index2;


figure1 = figure;

% Create axes
axes1 = axes('Parent',figure1);
hold(axes1,'on');
box on
set(axes1,'FontSize',18,'YMinorTick','on','YScale','log');
for i=1:length(freq)
a=sprintf('DMD_solutionX_d1_L2_%2.2i/dataDeltasOmegasAmplTemporal.mat',freq(i))
m=load(a);

d=[m.DeltasOmegAmplTemporal(:,3) m.DeltasOmegAmplTemporal(:,4)];
f=sortrows(d,1);
plot(f(:,1),f(:,2),'*')
%plot(m.DeltasOmegAmplTemporal(:,3),m.DeltasOmegAmplTemporal(:,4),'*-')
xlim([0 25])
end


xlabel('\alpha_{mn}')
ylabel('a_{mn}')
ylim([1e-2 300])
legend('\omega=0','\omega=0.43','\omega=0.70','\omega=0.97','\omega=1.95','\omega=2.03','\omega=3','Orientation','horizontal')
set(axes1,'FontSize',18,'YMinorTick','on','YScale','log');
set(gcf, 'Position', [100, 100, 1000, 300])
