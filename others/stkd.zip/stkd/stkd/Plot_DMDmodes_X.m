
clc
clear all
close all

% load DMD_solution_d12_tol1e-04_L2_ALL/dataDeltasOmegasAmplTemporal.mat
load DMD_solution_d12_tol1e-04_L2_ALL/DMDmode_tensor.mat
freq=[0.017 0.036 0.075 0.085 0.11 0.15 0.34 0.39 0.45 ...
    0.25 0.22 0.47 0.43 0.37 0.31]

IND=[2 4 10 14 30 34 8 12 32 44 40 20 42 26 6]

[L nx ny nz nt]=size(DMDmode)
%%
deltaX=4*pi/(nx-1)
xx=[0:1:nx-1]*deltaX

deltaY=2/(ny-1)
yy=[0:ny-1]*deltaY

deltaZ=2*pi/(nz-1)
zz=[0:nz-1]*deltaZ

[X Y]=meshgrid(xx,yy);
[XX ZZ]=meshgrid(xx,zz);
[YY Z]=meshgrid(yy,zz);

LL2=1

for i=1:length(freq)
    i
freq=[0.017 0.036 0.075 0.085 0.11 0.15 0.34 0.39 0.45 ...
    0.25 0.22 0.47 0.43 0.37 0.31]
    if LL2==0
        a=sprintf('DMD_solutionX_d1_L2_%2.2i_L1/dataTensorReconst.mat',freq(i))
        m=load(a);
        
        h2=figure;
        axes1 = axes('Parent',h2);
        hold(axes1,'on');
        box on
        contourf(XX,ZZ,squeeze(abs(m.TensorReconst(1,1:1:end,8,:)))')
        name2 = sprintf('./DMDmodes_planes/XZ_%2.2i_L1_vx_L38',freq(i) );
        %saveas(h2,name2,'fig')
        xlabel('X')
        ylabel('Z')
        set(axes1,'FontSize',18);
        set(gcf, 'Position', [100, 100, 700, 350])
        saveas(h2,name2,'jpg')
        pause
        close(h2)
        
        h2=figure;
        axes1 = axes('Parent',h2);
        hold(axes1,'on');
        box on
        contourf(XX,ZZ,squeeze(abs(m.TensorReconst(1,1:1:end,9,:)))')
        name2 = sprintf('./DMDmodes_planes/XZ_%2.2i_L1_vx_L39',freq(i) );
        %saveas(h2,name2,'fig')
        xlabel('X')
        ylabel('Z')
        set(axes1,'FontSize',18);
        set(gcf, 'Position', [100, 100, 700, 350])
        saveas(h2,name2,'jpg')
        pause
        close(h2)
        
        %
        h2=figure;
        axes1 = axes('Parent',h2);
        hold(axes1,'on');
        box on
        contourf(X,Y,squeeze(abs(m.TensorReconst(1,1:1:end,:,45)))')
        name2 = sprintf('./DMDmodes_planes/XY_%2.2i_L1_vx',freq(i) );
        % saveas(h2,name2,'fig')
        xlabel('X')
        ylabel('Y')
        set(axes1,'FontSize',18);
        set(gcf, 'Position', [100, 100, 700, 350])
        saveas(h2,name2,'jpg')
        pause
        close(h2)
       
        h2=figure;
                axes1 = axes('Parent',h2);
        hold(axes1,'on');
        box on
        contourf(XX,ZZ,squeeze(abs(m.TensorReconst(1,1:1:end,18,:)))')
        name2 = sprintf('./DMDmodes_planes/XZbottom_%2.2i_L1_vx',freq(i) );
        %saveas(h2,name2,'fig')
        xlabel('X')
        ylabel('Z')
        set(axes1,'FontSize',18);
        set(gcf, 'Position', [100, 100, 700, 350])
        saveas(h2,name2,'jpg')
        close(h2)
        
        h2=figure;
                axes1 = axes('Parent',h2);
        hold(axes1,'on');
        box on
        contourf(XX,ZZ,squeeze(abs(m.TensorReconst(1,1:1:end,73,:)))')
        name2 = sprintf('./DMDmodes_planes/XZtop_%2.2i_L1_vx',freq(i) );
        %saveas(h2,name2,'fig')
        xlabel('X')
        ylabel('Z')
        set(axes1,'FontSize',18);
        set(gcf, 'Position', [100, 100, 700, 350])
        saveas(h2,name2,'jpg')
        close(h2)
        
        %
        
        h2=figure;
                axes1 = axes('Parent',h2);
        hold(axes1,'on');
        box on
        contourf(X,Y,squeeze(abs(m.TensorReconst(2,1:1:end,:,45)))')
        name2 = sprintf('./DMDmodes_planes/XY_%2.2i_L1_vy',freq(i) );
        %saveas(h2,name2,'fig')
        xlabel('X')
        ylabel('Y')
        set(axes1,'FontSize',18);
        set(gcf, 'Position', [100, 100, 700, 350])
        saveas(h2,name2,'jpg')
        close(h2)
        
        h2=figure;
                axes1 = axes('Parent',h2);
        hold(axes1,'on');
        box on
        contourf(XX,ZZ,squeeze(abs(m.TensorReconst(2,1:1:end,18,:)))')
        name2 = sprintf('./DMDmodes_planes/XZbottom_%2.2i_L1_vy',freq(i) );
        %saveas(h2,name2,'fig')
        xlabel('X')
        ylabel('Z')
        set(axes1,'FontSize',18);
        set(gcf, 'Position', [100, 100, 700, 350])
        saveas(h2,name2,'jpg')
        close(h2)
        
        h2=figure;
                axes1 = axes('Parent',h2);
        hold(axes1,'on');
        box on
        contourf(XX,ZZ,squeeze(abs(m.TensorReconst(2,1:1:end,73,:)))')
        name2 = sprintf('./DMDmodes_planes/XZtop_%2.2i_L1_vy',freq(i) );
        %saveas(h2,name2,'fig')
        xlabel('X')
        ylabel('Z')
        set(axes1,'FontSize',18);
        set(gcf, 'Position', [100, 100, 700, 350])
        saveas(h2,name2,'jpg')
        close(h2)
        %pause
        
    elseif LL2==1
        a=sprintf('DMD_solutionX_d1_L2_%2.2i_L2/dataTensorReconst.mat',freq(i))
        m=load(a);
        
        h2=figure;
                axes1 = axes('Parent',h2);
        hold(axes1,'on');
        box on
        contourf(XX,ZZ,squeeze(abs(m.TensorReconst(1,1:1:end,8,:)))')
        name2 = sprintf('./DMDmodes_planes/XZ_%2.2i_L2_vx_L38',freq(i) );
        %saveas(h2,name2,'fig')
        xlabel('X')
        ylabel('Z')
        set(axes1,'FontSize',18);
        set(gcf, 'Position', [100, 100, 700, 350])
        saveas(h2,name2,'jpg')
       % pause
        close(h2)
        
        h2=figure;
                axes1 = axes('Parent',h2);
        hold(axes1,'on');
        box on
        contourf(XX,ZZ,squeeze(abs(m.TensorReconst(1,1:1:end,9,:)))')
        name2 = sprintf('./DMDmodes_planes/XZ_%2.2i_L2_vx_L39',freq(i) );
        %saveas(h2,name2,'fig')
        xlabel('X')
        ylabel('Z')
        set(axes1,'FontSize',18);
        set(gcf, 'Position', [100, 100, 700, 350])
        saveas(h2,name2,'jpg')
       % pause
        close(h2)
        
        %
        h2=figure;
                axes1 = axes('Parent',h2);
        hold(axes1,'on');
        box on
        contourf(X,Y,squeeze(abs(m.TensorReconst(1,1:1:end,:,45)))')
        name2 = sprintf('./DMDmodes_planes/XY_%2.2i_L2_vx',freq(i) );
        % saveas(h2,name2,'fig')
        xlabel('X')
        ylabel('Y')
        set(axes1,'FontSize',18);
        set(gcf, 'Position', [100, 100, 700, 350])
        saveas(h2,name2,'jpg')
        close(h2)
        
        h2=figure;
                axes1 = axes('Parent',h2);
        hold(axes1,'on');
        box on
        contourf(XX,ZZ,squeeze(abs(m.TensorReconst(1,1:1:end,18,:)))')
        name2 = sprintf('./DMDmodes_planes/XZbottom_%2.2i_L2_vx',freq(i) );
        %saveas(h2,name2,'fig')
        xlabel('X')
        ylabel('Z')
        set(axes1,'FontSize',18);
        set(gcf, 'Position', [100, 100, 700, 350])
        saveas(h2,name2,'jpg')
        close(h2)
        
        h2=figure;
                axes1 = axes('Parent',h2);
        hold(axes1,'on');
        box on
        contourf(XX,ZZ,squeeze(abs(m.TensorReconst(1,1:1:end,73,:)))')
        name2 = sprintf('./DMDmodes_planes/XZtop_%2.2i_L2_vx',freq(i) );
        %saveas(h2,name2,'fig')
        xlabel('X')
        ylabel('Z')
        set(axes1,'FontSize',18);
        set(gcf, 'Position', [100, 100, 700, 350])
        saveas(h2,name2,'jpg')
        close(h2)
        
        %
        
        h2=figure;
                axes1 = axes('Parent',h2);
        hold(axes1,'on');
        box on
        contourf(X,Y,squeeze(abs(m.TensorReconst(2,1:1:end,:,45)))')
        name2 = sprintf('./DMDmodes_planes/XY_%2.2i_L2_vy',freq(i) );
        %saveas(h2,name2,'fig')
        xlabel('X')
        ylabel('Y')
        set(axes1,'FontSize',18);
        set(gcf, 'Position', [100, 100, 700, 350])
        saveas(h2,name2,'jpg')
        close(h2)
        
        h2=figure;
                axes1 = axes('Parent',h2);
        hold(axes1,'on');
        box on
        contourf(XX,ZZ,squeeze(abs(m.TensorReconst(2,1:1:end,18,:)))')
        name2 = sprintf('./DMDmodes_planes/XZbottom_%2.2i_L2_vy',freq(i) );
        %saveas(h2,name2,'fig')
        xlabel('X')
        ylabel('Z')
        set(axes1,'FontSize',18);
        set(gcf, 'Position', [100, 100, 700, 350])
        saveas(h2,name2,'jpg')
        close(h2)
        
        h2=figure;
                axes1 = axes('Parent',h2);
        hold(axes1,'on');
        box on
        contourf(XX,ZZ,squeeze(abs(m.TensorReconst(2,1:1:end,73,:)))')
        name2 = sprintf('./DMDmodes_planes/XZtop_%2.2i_L2_vy',freq(i) );
        %saveas(h2,name2,'fig')
        xlabel('X')
        ylabel('Z')
        set(axes1,'FontSize',18);
        set(gcf, 'Position', [100, 100, 700, 350])
        saveas(h2,name2,'jpg')
        close(h2)
        
    end
    
end
 